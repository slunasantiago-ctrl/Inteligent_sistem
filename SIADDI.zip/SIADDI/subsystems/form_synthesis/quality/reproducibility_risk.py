"""Índice heurístico de riesgo de reproducibilidad, nivel 1 (C31.2). Se rotula siempre «no es Cpk»."""
from __future__ import annotations

from .indicators import risk_index

__all__ = ["risk_index"]
