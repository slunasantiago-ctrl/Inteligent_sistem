"""Series de números preferidos cargadas desde datos (C29.4).

SIADEF no calcula las series de memoria: los valores redondeados son los normativos y
vienen de data/standards/preferred_numbers.json con su norma, edición y fuente.
"""
from __future__ import annotations

import math


class PreferredNumbers:
    def __init__(self, data: dict, visible: bool):
        self.data = data or {}
        self.available = bool(visible and self.data.get("series"))
        self.series = self.data.get("series", {}) if self.available else {}

    def snap(self, value: float, series_id: str):
        """Valor de la serie más cercano en escala logarítmica (extensión por décadas)."""
        base = self.series.get(series_id)
        if not base or value is None or value <= 0:
            return None
        exp = math.floor(math.log10(value))
        best = None
        for e in (exp - 1, exp, exp + 1):
            for b in base + [10.0]:
                cand = round(b * 10 ** e, 10)
                d = abs(math.log10(cand) - math.log10(value))
                if best is None or d < best[0] - 1e-15:
                    best = (d, cand)
        return best[1]

    def in_series(self, value: float, series_id: str, rel_tol: float = 1e-6) -> bool:
        s = self.snap(value, series_id)
        return s is not None and abs(s - value) <= rel_tol * max(1.0, abs(value))

    def snapper(self, series_default: str = None):
        if not self.available:
            return None
        return lambda v, sid: self.snap(v, sid or series_default)
