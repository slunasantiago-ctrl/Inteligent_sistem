"""La forma como característica de calidad: nomenclatura de indicadores (C30, C.6).

Cada indicador devuelve (valor bruto, q normalizado en [0, 1]) o None si falta el dato.
Solo se calculan los indicadores visibles (aprobados, o borrador rotulado en --draft/--demo).
"""
from __future__ import annotations

from ..grammar import geometry as geo
from ..grammar import similarity


def ctq_candidates_abstract(shape):
    """Cotas críticas candidatas en la forma abstracta (uniones, articulaciones, encajes)."""
    out = []
    for e in shape.elements:
        if "joint" in e.labels:
            out.append(("axis", e.eid))
        if "segment" in e.labels:
            out.append(("segment_length", e.eid))
        if e.holes:
            out.append(("hole", e.eid))
        if "nested" in e.labels or "shell" in e.labels:
            out.append(("fit", e.eid))
    return out


def complexity(shape, coeffs):
    n_el = len(shape.elements)
    n_v = sum(len(e.points) + sum(len(h) for h in e.holes) for e in shape.elements)
    n_ctq = len(ctq_candidates_abstract(shape))
    raw = (coeffs["elements"][0] * min(1, n_el / coeffs["elements"][1]) +
           coeffs["vertices"][0] * min(1, n_v / coeffs["vertices"][1]) +
           coeffs["ctq"][0] * min(1, n_ctq / coeffs["ctq"][1]))
    return round(raw, 4), round(1 - raw, 4)


def conformity(guard_results: dict):
    if not guard_results:
        return None
    passed = sum(1 for v in guard_results.values() if v)
    return (f"{passed}/{len(guard_results)}", round(passed / len(guard_results), 4))


def novelty(shape, reference_shapes):
    if not reference_shapes:
        return None
    ras = similarity.raster(shape)
    q = similarity.novelty(ras, [similarity.raster(r) for r in reference_shapes])
    return (q, q)


def risk_index(shape, spec):
    """Índice heurístico de riesgo de reproducibilidad (nivel 1). NO es Cpk (C31.2)."""
    w, lim = spec["weights"], spec["limits"]
    n_ctq = len(ctq_candidates_abstract(shape))
    radii = [e.attrs.get("fillet_radius") for e in shape.elements if e.attrs.get("fillet_radius")]
    radii += [e.attrs.get("radius") for e in shape.elements if e.attrs.get("radius")]
    small = sum(1 for r in radii if r < lim["small_radius"]) / len(radii) if radii else 0.0
    widths = [geo.min_width(e.points) for e in shape.elements if "joint" not in e.labels]
    walls = [e.attrs.get("wall") for e in shape.elements if e.attrs.get("wall")]
    thin = sum(1 for x in widths + walls if x < lim["thin_wall"]) / max(1, len(widths + walls))
    chains = sum(1 for e in shape.elements if e.labels & {"segment", "joint"})
    f = {"ctq": min(1, n_ctq / lim["ctq"]), "small_radii": small, "thin_walls": thin, "chains": min(1, chains / lim["chains"])}
    value = sum(w[k] * f[k] for k in w)
    return round(value, 4), {k: round(v, 4) for k, v in f.items()}


def unification(ctqs, shape, preferred, series_id):
    if not ctqs:
        return None
    in_series = sum(1 for c in ctqs if preferred.available and preferred.in_series(c.nominal_mm, series_id))
    a = in_series / len(ctqs)
    groups = {}
    for e in shape.elements:
        key = (round(geo.area(e.points), 4), len(e.points))
        groups[key] = groups.get(key, 0) + 1
    repeated = sum(n for n in groups.values() if n > 1)
    b = repeated / len(shape.elements) if shape.elements else 0
    q = 0.5 * a + 0.5 * b
    return (f"{in_series}/{len(ctqs)} · {repeated}/{len(shape.elements)}", round(q, 4))


def reproducibility(results, ctqs, threshold):
    sims = [results[c.ctq_id] for c in ctqs if c.ctq_id in results]
    if not ctqs or len(sims) < len(ctqs):
        return None   # alguna cota sin σ: no se inventa
    m = min(r.cpk_estimate for r in sims)
    return (round(m, 3), round(min(1.0, max(0.0, m / threshold)), 4))
