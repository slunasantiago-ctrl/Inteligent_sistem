"""Base de capacidades de proceso (C32): σ típica por proceso, material, tipo de cota y rango."""
from __future__ import annotations

LEVELS = ("A_measured", "B_literature", "C_derived_from_IT_grade")


class CapabilityDB:
    def __init__(self, data: dict, mode):
        self.mode = mode
        self.records = [r for r in (data or {}).get("records", []) if mode.visible(r)]

    def validate(self):
        errors = []
        for r in self.records:
            if not r.get("source"):
                errors.append(f"{r.get('capability_id')}: sin source")
            if r.get("data_quality") not in LEVELS:
                errors.append(f"{r.get('capability_id')}: nivel de calidad del dato inválido")
            lo, hi = r.get("range_mm", [None, None])
            if lo is None or hi is None or lo >= hi:
                errors.append(f"{r.get('capability_id')}: rango inválido")
        keyed = {}
        for r in self.records:
            key = (r["process_id"], r.get("material_id"), r["feature_type"])
            for other in keyed.get(key, []):
                if r["range_mm"][0] < other["range_mm"][1] and other["range_mm"][0] < r["range_mm"][1] \
                        and r.get("sigma_mm") != other.get("sigma_mm"):
                    errors.append(f"{r.get('capability_id')}: rango solapado contradictorio con {other.get('capability_id')}")
            keyed.setdefault(key, []).append(r)
        return errors

    def lookup(self, process_id, material_id, feature_type, nominal_mm):
        """Registro aplicable o None (sin dato de capacidad, C31.3 y C32.4)."""
        cands = []
        for r in self.records:
            if r["process_id"] != process_id or r["feature_type"] != feature_type:
                continue
            if r.get("material_id") not in (None, material_id):
                continue
            lo, hi = r["range_mm"]
            if lo <= nominal_mm <= hi and r.get("sigma_mm") is not None:
                cands.append(r)
        if not cands:
            return None
        exact = [r for r in cands if r.get("material_id") == material_id]
        return (exact or cands)[0]

    def processes(self):
        return sorted({r["process_id"] for r in self.records})
