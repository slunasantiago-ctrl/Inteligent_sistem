"""Aprendizaje: propuesta de ajuste de pesos de las reglas (C34, posterior al MVP).

SIADEF propone; el estudiante o el profesor aprueban. Fórmula declarada y acotada:
  peso' = clip(peso + δ·(adopciones) − δ·(apariciones con Cpk previsto < umbral), [mín, máx])
Ninguna regla se elimina; los pesos originales se conservan y cada cambio queda en el historial.
"""
from __future__ import annotations

import datetime as dt
import os

from isppr_platform.datastore import load_json, save_json


def propose(base_weights: dict, evaluated: list, threshold: float, spec: dict):
    delta, lo, hi = spec.get("delta", 0.1), spec.get("min_weight", 0.2), spec.get("max_weight", 3.0)
    up, down = {}, {}
    for alt in evaluated:
        rules = set(alt["rules"])
        if alt.get("adopted"):
            for r in rules:
                up[r] = up.get(r, 0) + 1
        cpk = alt.get("min_cpk")
        if cpk is not None and cpk < threshold:
            for r in rules:
                down[r] = down.get(r, 0) + 1
    proposal = {}
    for r, w in sorted(base_weights.items()):
        new = min(hi, max(lo, w + delta * up.get(r, 0) - delta * down.get(r, 0)))
        if abs(new - w) > 1e-12:
            proposal[r] = {"from": w, "to": round(new, 4), "up": up.get(r, 0), "down": down.get(r, 0)}
    return proposal


def apply(proposal: dict, path: str, approved_by: str):
    data = load_json(path, {"weights": {}, "history": []})
    for r, ch in proposal.items():
        data["weights"][r] = ch["to"]
    data["history"].append({"date": dt.datetime.now().isoformat(timespec="seconds"), "approved_by": approved_by,
                            "changes": proposal})
    save_json(path, data)
    return data


def reset(path: str):
    if os.path.exists(path):
        data = load_json(path, {"weights": {}, "history": []})
        data["history"].append({"date": dt.datetime.now().isoformat(timespec="seconds"), "reset": True})
        data["weights"] = {}
        save_json(path, data)


def current(path: str) -> dict:
    return load_json(path, {"weights": {}}).get("weights", {})
