"""Evaluación de la forma por el consumidor: diferencial semántico (C33).

SIADEF genera la plantilla y procesa respuestas reales importadas: nunca simula opiniones.
"""
from __future__ import annotations

import csv
import math
import os
from statistics import mean, stdev

Z95 = 1.959963984540054


def write_template(path, alternatives, scales, lang, scale_range=(1, 7)):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["respondent", "alternative", "scale_id", "value",
                    f"# {scale_range[0]} = left · {scale_range[1]} = right"])
        for a in alternatives:
            for s in scales:
                w.writerow(["R1", a, s["scale_id"], "", f"{s['left'].get(lang) or s['left'].get('es')} — {s['right'].get(lang) or s['right'].get('es')}"])
    return path


class SurveyError(ValueError):
    pass


def read_responses(path, scale_ids, alternatives, scale_range=(1, 7)):
    rows = []
    with open(path, encoding="utf-8-sig", newline="") as fh:
        for i, row in enumerate(csv.DictReader(fh), start=2):
            if not row.get("value"):
                continue
            try:
                v = float(str(row["value"]).replace(",", "."))
            except ValueError:
                raise SurveyError(f"line_{i}_not_numeric")
            if not scale_range[0] <= v <= scale_range[1]:
                raise SurveyError(f"line_{i}_out_of_scale")
            if row["scale_id"] not in scale_ids:
                raise SurveyError(f"line_{i}_unknown_scale")
            if row["alternative"] not in alternatives:
                raise SurveyError(f"line_{i}_unknown_alternative")
            rows.append((row["respondent"], row["alternative"], row["scale_id"], v))
    return rows


def summarize(rows, target: dict, scale_range=(1, 7)):
    """Por alternativa: estadísticos por escala y q = 1 − distancia normalizada al perfil objetivo."""
    out = {}
    span = scale_range[1] - scale_range[0]
    alts = sorted({r[1] for r in rows})
    for a in alts:
        per = {}
        dist2, k = 0.0, 0
        for sid in sorted({r[2] for r in rows if r[1] == a}):
            vals = [r[3] for r in rows if r[1] == a and r[2] == sid]
            m = mean(vals)
            sd = stdev(vals) if len(vals) > 1 else 0.0
            half = Z95 * sd / math.sqrt(len(vals)) if len(vals) > 1 else None
            per[sid] = {"n": len(vals), "mean": m, "sd": sd, "ci95": (m - half, m + half) if half is not None else None}
            if sid in target:
                dist2 += ((m - target[sid]) / span) ** 2
                k += 1
        q = round(1 - math.sqrt(dist2 / k), 4) if k else None
        n_resp = len({r[0] for r in rows if r[1] == a})
        out[a] = {"scales": per, "q": q, "n_respondents": n_resp}
    return out
