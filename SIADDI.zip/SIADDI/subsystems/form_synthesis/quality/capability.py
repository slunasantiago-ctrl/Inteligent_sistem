"""Cp/Cpk analíticos y Cpk previsto por simulación Monte Carlo (C31, C.4).

Solo biblioteca estándar y generador con semilla: el mismo resultado en cualquier equipo.
El resultado se rotula siempre «Cpk previsto (estimación)» (C31.4).
"""
from __future__ import annotations

import math
import random
from dataclasses import asdict, dataclass, field
from statistics import NormalDist

Z95 = 1.959963984540054


@dataclass
class CTQ:
    ctq_id: str
    name: str
    feature_type: str = "linear"        # linear | diameter | radius | angle
    nominal_mm: float = 0.0
    lower: float = 0.0                  # desviación inferior (negativa)
    upper: float = 0.0                  # desviación superior
    tol_source: str = None              # "table:<id>:<clase>" | "student"
    process_id: str = None
    material_id: str = None
    sigma_mm: float = None
    mean_shift_mm: float = 0.0
    distribution: str = "normal"
    sigma_source: str = None
    data_quality: str = None
    capability_id: str = None
    original_nominal: float = None      # antes del ajuste a números preferidos
    origin: str = "system"              # "system" (candidata) | "student"

    @property
    def lsl(self):
        return self.nominal_mm + self.lower

    @property
    def usl(self):
        return self.nominal_mm + self.upper

    def to_dict(self):
        return asdict(self)


@dataclass
class Chain:
    chain_id: str
    name: str
    terms: list                      # [(ctq_id, coeficiente)]
    lower: float = 0.0               # desviación inferior de Y respecto a su nominal
    upper: float = 0.0

    def to_dict(self):
        return asdict(self)


@dataclass
class CapabilityResult:
    target_id: str
    kind: str                        # "ctq" | "chain"
    iterations: int
    seed: int
    mean: float
    std: float
    ppm: float
    ppm_ci95: tuple
    cpk_estimate: float
    cp_analytic: float = None
    cpk_analytic: float = None
    ppm_analytic: float = None
    contribution: dict = field(default_factory=dict)
    nominal: float = None
    lsl: float = None
    usl: float = None
    sigma_sources: dict = field(default_factory=dict)

    def to_dict(self):
        d = asdict(self)
        d["ppm_ci95"] = list(self.ppm_ci95)
        return d


def analytic(lsl, usl, mu, sigma):
    if sigma is None or sigma <= 0:
        return None, None, None
    cp = (usl - lsl) / (6 * sigma)
    cpk = min(usl - mu, mu - lsl) / (3 * sigma)
    nd = NormalDist(mu, sigma)
    p = nd.cdf(lsl) + (1 - nd.cdf(usl))
    return cp, cpk, p * 1e6


def wilson(k, n, z=Z95):
    if n == 0:
        return (0.0, 0.0)
    p = k / n
    den = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, centre - half) * 1e6, min(1.0, centre + half) * 1e6)


def _sample(rng, ctq: CTQ, m: int):
    mu = ctq.nominal_mm + (ctq.mean_shift_mm or 0.0)
    s = ctq.sigma_mm
    if ctq.distribution == "uniform":
        h = math.sqrt(3) * s
        return [rng.uniform(mu - h, mu + h) for _ in range(m)]
    return [rng.gauss(mu, s) for _ in range(m)]


def _stats(values, lsl, usl):
    n = len(values)
    mean = math.fsum(values) / n
    var = math.fsum((v - mean) ** 2 for v in values) / (n - 1)
    sd = math.sqrt(var)
    k = sum(1 for v in values if v < lsl or v > usl)
    cpk = min(usl - mean, mean - lsl) / (3 * sd) if sd > 0 else float("inf")
    return mean, sd, k, cpk


def simulate(ctqs, chains=(), iterations: int = 100_000, seed: int = 1):
    """Simula todas las cotas con σ cargada. Devuelve {id: CapabilityResult}.

    Las cotas sin σ no se simulan (C17: sin dato de capacidad no hay Cpk previsto).
    """
    rng = random.Random(seed)
    samples = {}
    results = {}
    for c in sorted(ctqs, key=lambda x: x.ctq_id):
        if c.sigma_mm is None or c.sigma_mm <= 0:
            continue
        samples[c.ctq_id] = _sample(rng, c, iterations)
        mean, sd, k, cpk = _stats(samples[c.ctq_id], c.lsl, c.usl)
        cp_a, cpk_a, ppm_a = analytic(c.lsl, c.usl, c.nominal_mm + (c.mean_shift_mm or 0), c.sigma_mm) if c.distribution == "normal" else (None, None, None)
        results[c.ctq_id] = CapabilityResult(c.ctq_id, "ctq", iterations, seed, mean, sd, k / iterations * 1e6,
                                             wilson(k, iterations), cpk, cp_a, cpk_a, ppm_a, {}, c.nominal_mm, c.lsl, c.usl,
                                             {c.ctq_id: c.sigma_source})
    total_ppm = sum(r.ppm for r in results.values())
    for r in results.values():
        r.contribution = {r.target_id: (r.ppm / total_ppm) if total_ppm > 0 else 0.0}
    by_id = {c.ctq_id: c for c in ctqs}
    for ch in chains:
        terms = [(cid, a) for cid, a in ch.terms if cid in by_id]
        if not terms or any(cid not in samples for cid, _ in terms):
            continue
        nominal = sum(a * by_id[cid].nominal_mm for cid, a in terms)
        values = [math.fsum(a * samples[cid][i] for cid, a in terms) for i in range(iterations)]
        lsl, usl = nominal + ch.lower, nominal + ch.upper
        mean, sd, k, cpk = _stats(values, lsl, usl)
        var_terms = {cid: (a ** 2) * (by_id[cid].sigma_mm ** 2) for cid, a in terms}
        tot = sum(var_terms.values())
        sigma_y = math.sqrt(tot)
        mu_y = sum(a * (by_id[cid].nominal_mm + (by_id[cid].mean_shift_mm or 0)) for cid, a in terms)
        cp_a, cpk_a, ppm_a = analytic(lsl, usl, mu_y, sigma_y)
        results[ch.chain_id] = CapabilityResult(ch.chain_id, "chain", iterations, seed, mean, sd, k / iterations * 1e6,
                                                wilson(k, iterations), cpk, cp_a, cpk_a, ppm_a,
                                                {cid: v / tot for cid, v in var_terms.items()}, nominal, lsl, usl,
                                                {cid: by_id[cid].sigma_source for cid, _ in terms})
    return results


def robust_fraction(ctqs, threshold: float, sigma_increase: float):
    """Proporción de cotas que mantienen Cpk analítico ≥ umbral con σ × (1 + p) (indicador de robustez)."""
    rows = [c for c in ctqs if c.sigma_mm and (c.lower or c.upper)]
    if not rows:
        return None
    ok = 0
    for c in rows:
        _cp, cpk, _ppm = analytic(c.lsl, c.usl, c.nominal_mm + (c.mean_shift_mm or 0), c.sigma_mm * (1 + sigma_increase))
        if cpk is not None and cpk >= threshold:
            ok += 1
    return ok / len(rows)
