import json
import math
import os
import tempfile
import unittest

from tests import _helpers  # noqa: F401
from isppr_platform.datastore import DataMode
from subsystems.form_synthesis import setup_data
from subsystems.form_synthesis.core.knowledge import FormKnowledge
from subsystems.form_synthesis.core.synthesis_problem import SynthesisProblem
from subsystems.form_synthesis.grammar import geometry as geo
from subsystems.form_synthesis.grammar import guards as G
from subsystems.form_synthesis.grammar.derivation import derive, replay
from subsystems.form_synthesis.grammar.operations import OPERATIONS
from subsystems.form_synthesis.quality import capability as CAP


class GeometryTests(unittest.TestCase):
    def test_square(self):
        sq = geo.rect(0, 0, 2, 1)
        self.assertAlmostEqual(geo.area(sq), 2.0)
        self.assertAlmostEqual(geo.perimeter(sq), 6.0)
        cx, cy = geo.centroid(sq)
        self.assertAlmostEqual(cx, 1.0)
        self.assertAlmostEqual(cy, 0.5)
        self.assertTrue(geo.is_simple(sq))

    def test_bowtie_not_simple(self):
        self.assertFalse(geo.is_simple([(0, 0), (1, 1), (1, 0), (0, 1)]))

    def test_point_in_polygon_and_offset(self):
        sq = geo.rect(0, 0, 1, 1)
        self.assertTrue(geo.point_in_polygon((0.5, 0.5), sq))
        self.assertFalse(geo.point_in_polygon((1.5, 0.5), sq))
        inner = geo.offset(sq, -0.1)
        self.assertAlmostEqual(geo.area(inner), 0.64, places=6)

    def test_clip_halfplane(self):
        half = geo.clip_halfplane(geo.rect(0, 0, 2, 2), 1, 0, 1)   # x <= 1
        self.assertAlmostEqual(geo.area(half), 2.0, places=6)

    def test_closed_operation_catalogue(self):
        self.assertEqual(len(OPERATIONS), 13)


class GuardSafetyTests(unittest.TestCase):
    def test_valid_expression(self):
        self.assertTrue(G.evaluate("n_elements <= 16 and overlaps == 0", {"n_elements": 3, "overlaps": 0}))

    def test_injection_rejected(self):
        for expr in ("__import__('os').system('ls')", "open('x')", "n_elements.__class__", "[x for x in ()]",
                     "lambda: 1", "unknown_var > 1", "'texto' == 'texto'"):
            with self.assertRaises(G.GuardSyntaxError, msg=expr):
                G.parse(expr)

    def test_division_by_zero_is_safe(self):
        self.assertTrue(G.evaluate("bbox_w / 0 > 1", {"bbox_w": 1}))


class DerivationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.kb = FormKnowledge(DataMode(demo=True))

    def problem(self, seed=4821):
        g = self.kb.grammar
        return SynthesisProblem(initial_shape_id="shape_lamp", active_rules=sorted(g.rules),
                                active_guards=sorted(g.guards), n_alternatives=6, seed=seed)

    def test_deterministic_with_seed(self):
        snap = self.kb.preferred.snapper("R10")
        a = derive(self.kb.grammar, self.problem(), snap)
        b = derive(self.kb.grammar, self.problem(), snap)
        self.assertTrue(a.alternatives)
        self.assertEqual([x.recipe() for x in a.alternatives], [x.recipe() for x in b.alternatives])
        self.assertEqual(json.dumps(a.alternatives[0].shape.to_dict(), sort_keys=True),
                         json.dumps(b.alternatives[0].shape.to_dict(), sort_keys=True))

    def test_replay_reproduces_shape(self):
        res = derive(self.kb.grammar, self.problem(77), self.kb.preferred.snapper("R10"))
        for alt in res.alternatives:
            again = replay(self.kb.grammar, self.kb.grammar.shape("shape_lamp"), [s.to_dict() for s in alt.steps])
            for e1, e2 in zip(alt.shape.elements, again.elements):
                for p, q in zip(e1.points, e2.points):
                    self.assertAlmostEqual(p[0], q[0], places=9)
                    self.assertAlmostEqual(p[1], q[1], places=9)

    def test_alternatives_pass_global_guards(self):
        res = derive(self.kb.grammar, self.problem(5), self.kb.preferred.snapper("R10"))
        for alt in res.alternatives:
            env = G.measure(alt.shape, {"wall_thickness": 0.02})
            self.assertEqual(env["self_intersections"], 0)
            self.assertEqual(env["overlaps"], 0)

    def test_normal_mode_hides_draft_grammar(self):
        kb = FormKnowledge(DataMode())
        self.assertFalse(kb.grammar.visible_rules())

    def test_data_validates(self):
        self.assertEqual(self.kb.validate(), [])
        self.assertEqual(FormKnowledge(DataMode()).validate(), [])


class CapabilityTests(unittest.TestCase):
    def test_monte_carlo_converges_to_analytic(self):
        c = CAP.CTQ("c1", "x", nominal_mm=100, lower=-0.1, upper=0.1, sigma_mm=0.03)
        r = CAP.simulate([c], iterations=200_000, seed=3)["c1"]
        self.assertAlmostEqual(r.cpk_analytic, 0.1 / 0.09, places=6)
        self.assertLess(abs(r.cpk_estimate - r.cpk_analytic), 0.02)
        self.assertLessEqual(r.ppm_ci95[0], r.ppm_analytic * 1.2)
        self.assertGreaterEqual(r.ppm_ci95[1], r.ppm_analytic * 0.8)

    def test_same_seed_same_result(self):
        c = CAP.CTQ("c1", "x", nominal_mm=10, lower=-0.05, upper=0.05, sigma_mm=0.02)
        a = CAP.simulate([c], iterations=20_000, seed=9)["c1"]
        b = CAP.simulate([c], iterations=20_000, seed=9)["c1"]
        self.assertEqual(a.ppm, b.ppm)

    def test_no_sigma_no_cpk(self):
        c = CAP.CTQ("c1", "x", nominal_mm=10, lower=-0.05, upper=0.05)
        self.assertEqual(CAP.simulate([c], iterations=1000), {})

    def test_chain_variance_contribution(self):
        a = CAP.CTQ("a", "a", nominal_mm=50, lower=-0.2, upper=0.2, sigma_mm=0.03)
        b = CAP.CTQ("b", "b", nominal_mm=30, lower=-0.2, upper=0.2, sigma_mm=0.04)
        ch = CAP.Chain("ch1", "gap", [("a", 1), ("b", -1)], -0.3, 0.3)
        r = CAP.simulate([a, b], [ch], iterations=50_000, seed=1)["ch1"]
        self.assertAlmostEqual(r.nominal, 20)
        self.assertAlmostEqual(r.contribution["b"], 0.0016 / 0.0025, places=6)

    def test_wilson_bounds(self):
        lo, hi = CAP.wilson(0, 1000)
        self.assertAlmostEqual(lo, 0.0, places=6)
        self.assertGreater(hi, 0)


class PreferredNumberTests(unittest.TestCase):
    def test_demo_series(self):
        kb = FormKnowledge(DataMode(demo=True))
        self.assertTrue(kb.preferred.available)
        self.assertEqual(kb.preferred.snap(330, "R10"), 315)
        self.assertEqual(kb.preferred.snap(1.02, "R5"), 1.0)
        self.assertTrue(kb.preferred.in_series(25, "R10"))

    def test_normal_mode_draft_series_unavailable(self):
        self.assertFalse(FormKnowledge(DataMode()).preferred.available)
        self.assertTrue(FormKnowledge(DataMode(draft=True)).preferred.available)


class ImportTests(unittest.TestCase):
    def test_capability_csv_validation(self):
        with tempfile.TemporaryDirectory() as d:
            csv_path = os.path.join(d, "cap.csv")
            with open(csv_path, "w", encoding="utf-8") as fh:
                fh.write("capability_id,process_id,material_id,feature_type,range_min_mm,range_max_mm,sigma_mm,"
                         "mean_shift_mm,distribution,data_quality,sample_size,derivation_note\n"
                         "k1,injection_molding,pp,linear,0,50,0.02,0,normal,X_bad,,\n")
            with self.assertRaises(setup_data.ImportFailed):
                setup_data.import_capability(csv_path, "prueba", data_dir=d)

    def test_guard_import_rejects_code(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "g.json")
            with open(p, "w", encoding="utf-8") as fh:
                json.dump({"guards": [{"guard_id": "g1", "expr": "__import__('os')", "type": "geometric"}]}, fh)
            with self.assertRaises(setup_data.ImportFailed):
                setup_data.import_guards(p, "prueba", data_dir=d)


if __name__ == "__main__":
    unittest.main()
