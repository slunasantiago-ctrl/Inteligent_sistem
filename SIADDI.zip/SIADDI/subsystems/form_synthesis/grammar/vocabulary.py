"""Vocabulario de la gramática: elementos etiquetados y anclas (C9.1, C9.3).

Gramática paramétrica y etiquetada sobre conjuntos de elementos: las reglas se aplican
a elementos o anclas con etiquetas, no a cualquier sub-forma visible (C9.2).
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, field

from . import geometry as geo


@dataclass
class Element:
    eid: str
    points: list
    labels: set = field(default_factory=set)
    role: str = "body"
    holes: list = field(default_factory=list)
    attrs: dict = field(default_factory=dict)

    def to_dict(self):
        return {"eid": self.eid, "points": [list(p) for p in self.points], "labels": sorted(self.labels),
                "role": self.role, "holes": [[list(p) for p in h] for h in self.holes], "attrs": self.attrs}

    @staticmethod
    def from_dict(d):
        return Element(d["eid"], [tuple(p) for p in d["points"]], set(d.get("labels", [])), d.get("role", "body"),
                       [[tuple(p) for p in h] for h in d.get("holes", [])], dict(d.get("attrs", {})))

    @property
    def area(self):
        return geo.area(self.points) - sum(geo.area(h) for h in self.holes)


@dataclass
class Anchor:
    aid: str
    point: tuple
    labels: set = field(default_factory=set)
    attrs: dict = field(default_factory=dict)

    def to_dict(self):
        return {"aid": self.aid, "point": list(self.point), "labels": sorted(self.labels), "attrs": self.attrs}

    @staticmethod
    def from_dict(d):
        return Anchor(d["aid"], tuple(d["point"]), set(d.get("labels", [])), dict(d.get("attrs", {})))


@dataclass
class Shape:
    elements: list = field(default_factory=list)
    anchors: list = field(default_factory=list)
    counter: int = 0

    def copy(self) -> "Shape":
        return copy.deepcopy(self)

    def new_id(self, prefix: str = "e") -> str:
        self.counter += 1
        return f"{prefix}{self.counter}"

    def element(self, eid):
        for e in self.elements:
            if e.eid == eid:
                return e
        return None

    def anchor(self, aid):
        for a in self.anchors:
            if a.aid == aid:
                return a
        return None

    def all_points(self):
        pts = []
        for e in self.elements:
            pts += e.points
        pts += [a.point for a in self.anchors]
        return pts

    def bbox(self):
        pts = [p for e in self.elements for p in e.points] or [a.point for a in self.anchors] or [(0, 0)]
        return geo.bbox(pts)

    def to_dict(self):
        return {"elements": [e.to_dict() for e in self.elements], "anchors": [a.to_dict() for a in self.anchors],
                "counter": self.counter}

    @staticmethod
    def from_dict(d):
        s = Shape([Element.from_dict(e) for e in d.get("elements", [])],
                  [Anchor.from_dict(a) for a in d.get("anchors", [])], d.get("counter", 0))
        if not s.counter:
            s.counter = len(s.elements) + len(s.anchors) + 1
        return s

    def raster(self, grid: int = 32, box=None):
        return geo.rasterize([(e.points, e.holes) for e in self.elements], grid, box or self.bbox())
