"""Guardas: lenguaje de expresiones seguro y medición de la forma (C29.2, C19).

Prohibido usar eval/exec sobre datos: las expresiones se analizan con `ast` y solo se
admiten comparaciones, operadores lógicos y aritméticos, números y variables de la lista blanca.
"""
from __future__ import annotations

import ast
import math

from . import geometry as geo

VARIABLES = {
    "self_intersections": "número de autointersecciones de los contornos",
    "min_feature_width": "anchura mínima de un elemento (unidades abstractas)",
    "n_elements": "número de elementos",
    "n_joints": "número de articulaciones",
    "bbox_w": "ancho total", "bbox_h": "alto total", "height": "alto total", "width": "ancho total",
    "area_total": "área total",
    "fillet_radius": "radio de redondeo aplicado por la regla (0 si no hay)",
    "min_fillet_radius": "radio de redondeo mínimo en la forma (0 si no hay)",
    "wall_thickness": "espesor de pared de referencia (del contexto, relativo)",
    "min_wall": "espesor mínimo de pared de los elementos anidados (0 si no hay)",
    "overlaps": "pares de elementos que se solapan sin estar unidos por una articulación",
    "scale_mm": "escala en mm por unidad abstracta (0 si la forma no está dimensionada)",
    "max_height": "altura máxima declarada por el estudiante (relativa)",
    "max_width": "anchura máxima declarada por el estudiante (relativa)",
    "min_feature_width_mm": "anchura mínima en mm (solo si está dimensionada)",
    "min_fillet_radius_mm": "radio mínimo en mm (solo si está dimensionada)",
    "min_wall_mm": "espesor mínimo en mm (solo si está dimensionada)",
}

_ALLOWED_NODES = (ast.Expression, ast.BoolOp, ast.And, ast.Or, ast.UnaryOp, ast.Not, ast.USub, ast.UAdd,
                  ast.Compare, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.Eq, ast.NotEq, ast.BinOp, ast.Add,
                  ast.Sub, ast.Mult, ast.Div, ast.Name, ast.Load, ast.Constant)


class GuardSyntaxError(ValueError):
    pass


def parse(expr: str):
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as exc:
        raise GuardSyntaxError(f"syntax:{exc.msg}")
    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_NODES):
            raise GuardSyntaxError(f"not_allowed:{type(node).__name__}")
        if isinstance(node, ast.Name) and node.id not in VARIABLES:
            raise GuardSyntaxError(f"unknown_variable:{node.id}")
        if isinstance(node, ast.Constant) and not isinstance(node.value, (int, float)) or isinstance(node, ast.Constant) and isinstance(node.value, bool):
            raise GuardSyntaxError("only_numbers")
    return tree


def _eval(node, env):
    if isinstance(node, ast.Expression):
        return _eval(node.body, env)
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        return env[node.id]
    if isinstance(node, ast.UnaryOp):
        v = _eval(node.operand, env)
        return (not v) if isinstance(node.op, ast.Not) else (-v if isinstance(node.op, ast.USub) else +v)
    if isinstance(node, ast.BoolOp):
        vals = (_eval(v, env) for v in node.values)
        return all(vals) if isinstance(node.op, ast.And) else any(vals)
    if isinstance(node, ast.BinOp):
        a, b = _eval(node.left, env), _eval(node.right, env)
        if isinstance(node.op, ast.Add):
            return a + b
        if isinstance(node.op, ast.Sub):
            return a - b
        if isinstance(node.op, ast.Mult):
            return a * b
        return a / b if b else math.inf
    if isinstance(node, ast.Compare):
        left = _eval(node.left, env)
        for op, comp in zip(node.ops, node.comparators):
            right = _eval(comp, env)
            ok = {ast.Lt: left < right, ast.LtE: left <= right, ast.Gt: left > right, ast.GtE: left >= right,
                  ast.Eq: abs(left - right) < 1e-9, ast.NotEq: abs(left - right) >= 1e-9}[type(op)]
            if not ok:
                return False
            left = right
        return True
    raise GuardSyntaxError("bad_node")


def evaluate(expr: str, env: dict) -> bool:
    return bool(_eval(parse(expr), env))


def _proper_cross(p1, p2, p3, p4) -> bool:
    """Cruce propio de segmentos: las aristas compartidas o tangentes no cuentan."""
    def orient(a, b, c):
        return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
    d1, d2 = orient(p1, p2, p3), orient(p1, p2, p4)
    d3, d4 = orient(p3, p4, p1), orient(p3, p4, p2)
    tol = 1e-10
    return d1 * d2 < -tol and d3 * d4 < -tol


def _strictly_inside(pt, poly) -> bool:
    if not geo.point_in_polygon(pt, poly):
        return False
    for i in range(len(poly)):
        a, b = poly[i], poly[(i + 1) % len(poly)]
        L = ((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2) ** 0.5
        if L < 1e-12:
            continue
        d = abs((b[0] - a[0]) * (a[1] - pt[1]) - (a[0] - pt[0]) * (b[1] - a[1])) / L
        if d < 1e-7:
            return False
    return True


def _overlaps(shape) -> int:
    count = 0
    els = [e for e in shape.elements if "joint" not in e.labels]
    for i in range(len(els)):
        for j in range(i + 1, len(els)):
            a, b = els[i], els[j]
            if a.attrs.get("parent") == b.eid or b.attrs.get("parent") == a.eid:
                continue  # elemento anidado dentro de su contenedor
            ba, bb = geo.bbox(a.points), geo.bbox(b.points)
            if ba[2] < bb[0] or bb[2] < ba[0] or ba[3] < bb[1] or bb[3] < ba[1]:
                continue
            inside = any(_strictly_inside(p, b.points) for p in a.points) or \
                any(_strictly_inside(p, a.points) for p in b.points)
            crossing = any(_proper_cross(a.points[k], a.points[(k + 1) % len(a.points)],
                                         b.points[m], b.points[(m + 1) % len(b.points)])
                           for k in range(len(a.points)) for m in range(len(b.points)))
            if inside or crossing:
                count += 1
    return count


def measure(shape, ctx: dict = None, rule_params: dict = None) -> dict:
    """Variables medibles de la forma para evaluar guardas e indicadores."""
    ctx = ctx or {}
    x0, y0, x1, y1 = shape.bbox()
    widths = [geo.min_width(e.points) for e in shape.elements if "joint" not in e.labels] or [0.0]
    fillets = [e.attrs.get("fillet_radius") for e in shape.elements if e.attrs.get("fillet_radius")]
    walls = [e.attrs.get("wall") for e in shape.elements if e.attrs.get("wall")]
    si = sum(geo.self_intersections(e.points) for e in shape.elements)
    for e in shape.elements:
        si += sum(geo.self_intersections(h) for h in e.holes)
    scale_mm = float(ctx.get("scale_mm") or 0.0)
    env = {
        "self_intersections": si,
        "min_feature_width": min(widths),
        "n_elements": len(shape.elements),
        "n_joints": sum(1 for e in shape.elements if "joint" in e.labels),
        "bbox_w": x1 - x0, "bbox_h": y1 - y0, "width": x1 - x0, "height": y1 - y0,
        "area_total": sum(e.area for e in shape.elements),
        "fillet_radius": float((rule_params or {}).get("radius", 0.0)) if (rule_params or {}).get("_op") == "fillet" else 0.0,
        "min_fillet_radius": min(fillets) if fillets else 0.0,
        "wall_thickness": float(ctx.get("wall_thickness", 0.0)),
        "min_wall": min(walls) if walls else 0.0,
        "overlaps": _overlaps(shape),
        "scale_mm": scale_mm,
        "max_height": float(ctx.get("max_height", 1e9)),
        "max_width": float(ctx.get("max_width", 1e9)),
    }
    env["min_feature_width_mm"] = env["min_feature_width"] * scale_mm
    env["min_fillet_radius_mm"] = env["min_fillet_radius"] * scale_mm
    env["min_wall_mm"] = env["min_wall"] * scale_mm
    return env


def check(guard: dict, env: dict):
    """(resultado, aplicable). Las guardas absolutas solo se evalúan con forma dimensionada (C9.6)."""
    if guard.get("units") == "mm" and not env.get("scale_mm"):
        return True, False
    return evaluate(guard["expr"], env), True
