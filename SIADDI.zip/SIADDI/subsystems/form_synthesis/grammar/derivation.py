"""Motor de derivación determinista con semilla (C10).

Mismo perfil + misma gramática + misma semilla = mismas alternativas, en cualquier idioma
y sistema operativo. Cada alternativa conserva su receta y se reconstruye con replay().
"""
from __future__ import annotations

import random
from collections import Counter
from dataclasses import dataclass, field

from . import guards as G
from . import similarity
from .operations import TARGET_KIND, OperationError, apply

GLOBAL_GUARDS = ("g_no_self_intersection",)


@dataclass
class Step:
    rule_id: str
    target: str
    params: dict
    snapped: dict = field(default_factory=dict)   # param -> (original, ajustado)
    guards: dict = field(default_factory=dict)    # guard_id -> resultado

    def to_dict(self):
        return {"rule_id": self.rule_id, "target": self.target, "params": self.params,
                "snapped": {k: list(v) for k, v in self.snapped.items()}, "guards": self.guards}


@dataclass
class Alternative:
    alternative_id: str
    shape: object
    steps: list
    seed: int
    index: int
    initial_shape: str

    def recipe(self):
        return {"initial_shape": self.initial_shape, "seed": self.seed, "index": self.index,
                "steps": [s.to_dict() for s in self.steps]}

    def families(self, grammar):
        return sorted({grammar.rules[s.rule_id]["family_id"] for s in self.steps if s.rule_id in grammar.rules})


@dataclass
class DerivationResult:
    alternatives: list
    rejections: Counter
    duplicates: int
    attempts: int
    exhausted: bool


def _targets(shape, rule):
    lhs = rule.get("lhs") or {}
    need = set(lhs.get("labels", []))
    excl = set(lhs.get("exclude", []))
    kind = TARGET_KIND.get(rule["operation"], "element")
    pool = shape.anchors if kind == "anchor" else shape.elements
    out = []
    for item in pool:
        if need <= item.labels and not (excl & item.labels):
            out.append(item)
    return out


def _sample_params(rule, rng, overrides, snapper):
    params, snapped = {}, {}
    for name, spec in (rule.get("parameters") or {}).items():
        spec = {**spec, **(overrides.get(rule["rule_id"], {}).get(name, {}))}
        t = spec.get("type", "float")
        if t == "int":
            v = rng.randint(int(spec["min"]), int(spec["max"]))
        elif t == "choice":
            v = rng.choice(spec["choices"])
        elif t == "const":
            v = spec["value"]
        else:
            v = rng.uniform(float(spec["min"]), float(spec["max"]))
            v = round(v, 6)
            series = spec.get("series")
            if series and snapper:
                s = snapper(v, series)
                if s is not None and abs(s - v) > 1e-12:
                    snapped[name] = (v, s)
                    v = s
        params[name] = v
    params["_op"] = rule["operation"]
    return params, snapped


def check_guards(guard_ids, grammar, shape, ctx, params):
    env = G.measure(shape, ctx, params)
    results, failed = {}, None
    for gid in guard_ids:
        g = grammar.guards.get(gid)
        if not g or not grammar.visible(g):
            continue
        ok, applicable = G.check(g, env)
        if applicable:
            results[gid] = bool(ok)
            if not ok and failed is None:
                failed = gid
    return results, failed


def apply_step(shape, rule, target_id, params):
    work = shape.copy()
    kind = TARGET_KIND.get(rule["operation"], "element")
    target = work.anchor(target_id) if kind == "anchor" else work.element(target_id)
    if target is None:
        raise OperationError("target_not_found")
    clean = {k: v for k, v in params.items() if not k.startswith("_")}
    return apply(rule["operation"], work, target, clean, {})


def derive(grammar, problem, snapper=None, max_attempts: int = None, pick_tries: int = 8):
    """problem: SynthesisProblem (core/synthesis_problem.py)."""
    rng = random.Random(problem.seed)
    rules = {rid: grammar.rules[rid] for rid in problem.active_rules if rid in grammar.rules}
    weights = {rid: float(problem.rule_weights.get(rid, rules[rid].get("weight", 1.0))) for rid in rules}
    guard_ids = list(dict.fromkeys(list(GLOBAL_GUARDS) + list(problem.active_guards)))
    ctx = problem.context()
    initial = problem.initial_shape(grammar)
    max_attempts = max_attempts or problem.n_alternatives * 8
    alternatives, rasters = [], []
    rejections, duplicates, attempts = Counter(), 0, 0
    while len(alternatives) < problem.n_alternatives and attempts < max_attempts:
        attempts += 1
        shape = initial.copy()
        steps, used = [], set()
        depth = rng.randint(max(1, problem.min_depth), max(1, problem.max_depth))
        for _ in range(depth):
            matches = []
            for rid in sorted(rules):
                r = rules[rid]
                for tgt in _targets(shape, r):
                    tid = getattr(tgt, "eid", None) or getattr(tgt, "aid", None)
                    if (rid, tid) in used:
                        continue
                    pre, failed = check_guards(r.get("guards_pre", []), grammar, shape, ctx, {})
                    if failed:
                        rejections[failed] += 1
                        continue
                    matches.append((rid, tid))
            if not matches:
                break
            accepted = False
            for _try in range(pick_tries):
                if not matches:
                    break
                ws = [weights[m[0]] for m in matches]
                if sum(ws) <= 0:
                    break
                idx = rng.choices(range(len(matches)), weights=ws, k=1)[0]
                rid, tid = matches[idx]
                rule = rules[rid]
                params, snapped = _sample_params(rule, rng, problem.param_overrides, snapper)
                try:
                    new_shape = apply_step(shape, rule, tid, params)
                except OperationError as exc:
                    rejections["op:" + str(exc).split(":")[0]] += 1
                    matches.pop(idx)
                    continue
                post_ids = guard_ids + [g for g in rule.get("guards_post", []) if g not in guard_ids]
                results, failed = check_guards(post_ids, grammar, new_shape, ctx, params)
                if failed:
                    rejections[failed] += 1
                    matches.pop(idx)
                    continue
                shape = new_shape
                used.add((rid, tid))
                steps.append(Step(rid, tid, {k: v for k, v in params.items() if not k.startswith("_")}, snapped, results))
                accepted = True
                break
            if not accepted:
                break
        if not steps:
            continue
        ras = similarity.raster(shape)
        if any(similarity.similarity(ras, r) >= problem.duplicate_threshold for r in rasters):
            duplicates += 1
            continue
        rasters.append(ras)
        alternatives.append(Alternative(f"A{len(alternatives) + 1:02d}", shape, steps, problem.seed,
                                        len(alternatives), problem.initial_shape_id))
    return DerivationResult(alternatives, rejections, duplicates, attempts,
                            exhausted=len(alternatives) < problem.n_alternatives)


def replay(grammar, initial_shape, steps):
    """Reconstruye exactamente una alternativa a partir de su receta (C10.3)."""
    shape = initial_shape.copy()
    for s in steps:
        rule = grammar.rules[s["rule_id"] if isinstance(s, dict) else s.rule_id]
        params = s["params"] if isinstance(s, dict) else s.params
        target = s["target"] if isinstance(s, dict) else s.target
        shape = apply_step(shape, rule, target, {**params, "_op": rule["operation"]})
    return shape
