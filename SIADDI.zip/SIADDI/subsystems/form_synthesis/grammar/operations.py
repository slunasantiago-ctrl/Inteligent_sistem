"""Catálogo cerrado de operaciones (C9.5).

Las reglas (datos) solo eligen entre estas operaciones. Añadir una operación exige
código, pruebas y aprobación; añadir una regla solo exige datos aprobados.
Cada operación recibe una copia de la forma y devuelve la forma modificada o lanza
OperationError con el motivo.
"""
from __future__ import annotations

import math

from . import geometry as geo
from .vocabulary import Anchor, Element


class OperationError(Exception):
    pass


def _frame(e: Element):
    return geo.principal_frame(e.points)


def op_divide(shape, target, params, ctx):
    e = target
    n = int(params.get("n_parts", 2))
    gap = float(params.get("gap", 0.04))
    frame = _frame(e)
    length, width, b = geo.extent_along(e.points, frame)
    if n < 2:
        raise OperationError("n_parts<2")
    g = gap * length
    part = (length - (n - 1) * g) / n
    if part <= 0:
        raise OperationError("gap_too_large")
    loc = geo.to_local(e.points, frame)
    x0 = b[0]
    new_elements, new_anchors = [], []
    for k in range(n):
        lo = x0 + k * (part + g)
        hi = lo + part
        piece = geo.clip_halfplane(loc, -1, 0, -lo)
        piece = geo.clip_halfplane(piece, 1, 0, hi)
        if len(piece) < 3:
            raise OperationError("empty_piece")
        pts = geo.ensure_ccw(geo.from_local(piece, frame))
        labels = (set(e.labels) - {"divisible"}) | {"segment"}
        ne = Element(shape.new_id(), pts, labels, e.role, [], {**e.attrs, "seg_index": k, "parent": e.eid})
        new_elements.append(ne)
        if k < n - 1:
            mid = geo.from_local([(hi + g / 2, (b[1] + b[3]) / 2)], frame)[0]
            new_anchors.append(Anchor(shape.new_id("a"), mid, {"joint_candidate"}, {"between": k}))
    idx = shape.elements.index(e)
    shape.elements[idx:idx + 1] = new_elements
    shape.anchors += new_anchors
    return shape


def op_offset_nest(shape, target, params, ctx):
    e = target
    w = geo.min_width(e.points)
    t = float(params.get("thickness", 0.15)) * w
    g = float(params.get("gap", 0.05)) * w
    inner = geo.offset(e.points, -t)
    if inner is None:
        raise OperationError("offset_failed")
    insert = str(params.get("insert", "yes")) not in ("no", "false", "0")
    nested = geo.offset(e.points, -(t + g)) if insert else None
    if insert and nested is None:
        raise OperationError("nested_offset_failed")
    e.holes = [inner]
    e.labels = (set(e.labels) | {"shell"}) - {"divisible"}
    e.attrs["wall"] = t
    if insert:
        shape.elements.append(Element(shape.new_id(), nested, {"nested"}, e.role, [], {"parent": e.eid}))
    return shape


def op_fillet(shape, target, params, ctx):
    e = target
    r = float(params.get("radius", 0.02))
    pts, applied = geo.fillet(e.points, r, segments=int(params.get("segments", 6)), only_convex=bool(params.get("only_convex", False)))
    if len(pts) < 3:
        raise OperationError("fillet_failed")
    e.points = pts
    e.attrs["fillet_radius"] = round(applied, 6)
    e.attrs["fillet_requested"] = r
    e.labels = set(e.labels) | {"rounded"}
    return shape


def op_chamfer(shape, target, params, ctx):
    e = target
    e.points = geo.chamfer(e.points, float(params.get("distance", 0.02)))
    e.labels = set(e.labels) | {"chamfered"}
    return shape


def op_scale(shape, target, params, ctx):
    e = target
    f = float(params.get("factor", 1.0))
    c = geo.centroid(e.points)
    e.points = geo.scale(e.points, f, f, c)
    e.holes = [geo.scale(h, f, f, c) for h in e.holes]
    return shape


def _pivot(shape, e, params):
    if params.get("pivot") == "joint":
        best = None
        cx, cy = geo.centroid(e.points)
        for a in shape.anchors:
            if a.labels & {"joint", "joint_candidate"}:
                d = math.dist(a.point, (cx, cy))
                if best is None or d < best[0]:
                    best = (d, a.point)
        if best:
            return best[1]
    return geo.centroid(e.points)


def op_rotate(shape, target, params, ctx):
    e = target
    ang = float(params.get("angle", 0))
    pv = _pivot(shape, e, params)
    e.points = geo.ensure_ccw(geo.rotate(e.points, ang, pv))
    e.holes = [geo.rotate(h, ang, pv) for h in e.holes]
    e.attrs["rotation"] = e.attrs.get("rotation", 0) + ang
    return shape


def op_mirror(shape, target, params, ctx):
    e = target
    x0 = (shape.bbox()[0] + shape.bbox()[2]) / 2 if params.get("axis", "shape") == "shape" else geo.centroid(e.points)[0]
    e.points = geo.mirror_x(e.points, x0)
    e.holes = [geo.mirror_x(h, x0) for h in e.holes]
    e.labels = set(e.labels) | {"mirrored"}
    return shape


def op_repeat(shape, target, params, ctx):
    e = target
    n = int(params.get("count", 2))
    frame = _frame(e)
    _length, width, _b = geo.extent_along(e.points, frame)
    sp = float(params.get("spacing", 0.3)) * width + width
    dx, dy = -math.sin(frame[2]) * sp, math.cos(frame[2]) * sp
    for k in range(1, n):
        pts = geo.translate(e.points, dx * k, dy * k)
        holes = [geo.translate(h, dx * k, dy * k) for h in e.holes]
        shape.elements.append(Element(shape.new_id(), pts, (set(e.labels) - {"repeatable"}) | {"copy"}, e.role, holes,
                                      {"parent": e.eid}))
    e.labels = set(e.labels) - {"repeatable"}
    return shape


def op_articulate(shape, target, params, ctx):
    a = target
    r = float(params.get("radius", 0.025))
    shape.elements.append(Element(shape.new_id(), geo.circle(a.point, r, 24), {"joint", "axis"}, "joint", [],
                                  {"radius": r, "anchor": a.aid}))
    a.labels = (set(a.labels) - {"joint_candidate"}) | {"joint"}
    a.attrs["axis_radius"] = r
    return shape


def op_deform(shape, target, params, ctx):
    e = target
    k = float(params.get("taper", 0.8))
    frame = _frame(e)
    loc = geo.to_local(e.points, frame)
    b = geo.bbox(loc)
    L = max(b[2] - b[0], geo.EPS)
    out = []
    for x, y in loc:
        f = 1 + (k - 1) * (x - b[0]) / L
        out.append((x, (y - (b[1] + b[3]) / 2) * f + (b[1] + b[3]) / 2))
    e.points = geo.ensure_ccw(geo.from_local(out, frame))
    e.labels = (set(e.labels) | {"asymmetric"}) - {"symmetric"}
    return shape


def op_add(shape, target, params, ctx):
    mode = params.get("mode", "base")
    if mode == "merge":
        e = target
        cx, cy = geo.centroid(e.points)
        others = [o for o in shape.elements if o is not e and "joint" not in o.labels]
        if not others:
            raise OperationError("nothing_to_merge")
        o = min(others, key=lambda x: math.dist(geo.centroid(x.points), (cx, cy)))
        hull = geo.ensure_ccw(geo.convex_hull(e.points + o.points))
        merged = Element(shape.new_id(), hull, (set(e.labels) | set(o.labels) | {"merged"}) - {"segment"}, e.role, [], {"parent": [e.eid, o.eid]})
        shape.elements = [x for x in shape.elements if x is not e and x is not o] + [merged]
        return shape
    x0, y0, x1, y1 = shape.bbox()
    w = (x1 - x0) * float(params.get("width_factor", 1.2))
    h = (y1 - y0) * float(params.get("height", 0.06))
    cx = (x0 + x1) / 2
    shape.elements.append(Element(shape.new_id(), geo.rect(cx - w / 2, y0 - h, cx + w / 2, y0), {"base", "edge_ext"}, "base"))
    return shape


def op_subtract(shape, target, params, ctx):
    e = target
    frame = _frame(e)
    length, width, b = geo.extent_along(e.points, frame)
    n = int(params.get("count", 1))
    r = float(params.get("radius", 0.25)) * width / 2
    if r <= 0:
        raise OperationError("radius_zero")
    step = length / (n + 1)
    for k in range(1, n + 1):
        c = geo.from_local([(b[0] + step * k, (b[1] + b[3]) / 2)], frame)[0]
        hole = geo.circle(c, r, 20)
        if not geo.polygon_inside(hole, e.points) or any(geo.polygon_inside(hole, hh) or geo.polygon_inside(hh, hole) for hh in e.holes):
            raise OperationError("hole_outside")
        e.holes.append(hole)
    e.labels = set(e.labels) | {"perforated"}
    e.attrs["hole_radius"] = r
    return shape


def op_replace(shape, target, params, ctx):
    e = target
    frame = _frame(e)
    length, width, _b = geo.extent_along(e.points, frame)
    e.points = geo.ensure_ccw(geo.ellipse_in_frame(frame, length / 2, width / 2))
    e.holes = []
    e.labels = set(e.labels) | {"rounded", "elliptic"}
    return shape


OPERATIONS = {
    "add": op_add, "replace": op_replace, "subtract": op_subtract, "divide": op_divide,
    "offset_nest": op_offset_nest, "fillet": op_fillet, "chamfer": op_chamfer, "scale": op_scale,
    "rotate": op_rotate, "mirror": op_mirror, "repeat": op_repeat, "articulate": op_articulate,
    "deform": op_deform,
}

TARGET_KIND = {"articulate": "anchor"}  # el resto actúa sobre elementos


def apply(op_name, shape, target, params, ctx=None):
    if op_name not in OPERATIONS:
        raise OperationError(f"unknown_operation:{op_name}")
    return OPERATIONS[op_name](shape, target, params, ctx or {})
