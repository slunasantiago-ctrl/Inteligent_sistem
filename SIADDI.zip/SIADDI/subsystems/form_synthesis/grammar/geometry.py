"""Geometría 2D en Python puro (C6, C9.3, C10.1).

Se implementa con la biblioteca estándar para que el subsistema funcione sin
dependencias externas y de forma idéntica en macOS, Linux y Windows (C10.4).
Polígonos: listas de (x, y) en sentido antihorario, sin repetir el primer punto.
Todas las comparaciones usan una tolerancia numérica explícita (C19).
"""
from __future__ import annotations

import math

EPS = 1e-9


# ------------------------------------------------------------------ básicos
def signed_area(poly) -> float:
    s = 0.0
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        s += x1 * y2 - x2 * y1
    return s / 2.0


def area(poly) -> float:
    return abs(signed_area(poly))


def ensure_ccw(poly):
    return list(poly) if signed_area(poly) >= 0 else list(reversed(poly))


def perimeter(poly) -> float:
    return sum(math.dist(poly[i], poly[(i + 1) % len(poly)]) for i in range(len(poly)))


def centroid(poly):
    a = signed_area(poly)
    if abs(a) < EPS:
        xs = [p[0] for p in poly]
        ys = [p[1] for p in poly]
        return (sum(xs) / len(xs), sum(ys) / len(ys))
    cx = cy = 0.0
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        f = x1 * y2 - x2 * y1
        cx += (x1 + x2) * f
        cy += (y1 + y2) * f
    return (cx / (6 * a), cy / (6 * a))


def bbox(points):
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return (min(xs), min(ys), max(xs), max(ys))


def clean(poly, tol: float = 1e-7):
    """Quita puntos duplicados consecutivos y colineales."""
    out = []
    for p in poly:
        if not out or math.dist(out[-1], p) > tol:
            out.append((float(p[0]), float(p[1])))
    if len(out) > 1 and math.dist(out[0], out[-1]) <= tol:
        out.pop()
    changed = True
    while changed and len(out) > 3:
        changed = False
        for i in range(len(out)):
            a, b, c = out[i - 1], out[i], out[(i + 1) % len(out)]
            cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])
            if abs(cross) < tol * max(1e-9, math.dist(a, c)):
                out.pop(i)
                changed = True
                break
    return out


# ------------------------------------------------------------------ transformaciones
def translate(poly, dx, dy):
    return [(x + dx, y + dy) for x, y in poly]


def rotate(poly, angle_deg, origin):
    a = math.radians(angle_deg)
    ca, sa = math.cos(a), math.sin(a)
    ox, oy = origin
    return [(ox + (x - ox) * ca - (y - oy) * sa, oy + (x - ox) * sa + (y - oy) * ca) for x, y in poly]


def scale(poly, fx, fy, origin):
    ox, oy = origin
    return [(ox + (x - ox) * fx, oy + (y - oy) * fy) for x, y in poly]


def mirror_x(poly, x0):
    return ensure_ccw([(2 * x0 - x, y) for x, y in poly])


def circle(center, r, n: int = 32):
    cx, cy = center
    return [(cx + r * math.cos(2 * math.pi * i / n), cy + r * math.sin(2 * math.pi * i / n)) for i in range(n)]


def rect(x0, y0, x1, y1):
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]


# ------------------------------------------------------------------ marco principal
def principal_frame(poly):
    """(cx, cy, ángulo en radianes del eje mayor) por momentos de segundo orden de los vértices."""
    cx, cy = centroid(poly)
    sxx = syy = sxy = 0.0
    for x, y in poly:
        dx, dy = x - cx, y - cy
        sxx += dx * dx
        syy += dy * dy
        sxy += dx * dy
    angle = 0.5 * math.atan2(2 * sxy, sxx - syy)
    # se ajusta al eje del rectángulo envolvente mínimo cuando el polígono es casi rectangular
    hull = convex_hull(poly)
    best = None
    for i in range(len(hull)):
        (x1, y1), (x2, y2) = hull[i], hull[(i + 1) % len(hull)]
        th = math.atan2(y2 - y1, x2 - x1)
        loc = to_local(hull, (cx, cy, th))
        b = bbox(loc)
        a_ = (b[2] - b[0]) * (b[3] - b[1])
        if best is None or a_ < best[0] - EPS:
            best = (a_, th, b[2] - b[0], b[3] - b[1])
    if best:
        th = best[1] if best[2] >= best[3] else best[1] + math.pi / 2
        angle = th
    return (cx, cy, angle)


def to_local(points, frame):
    cx, cy, th = frame
    c, s = math.cos(-th), math.sin(-th)
    return [((x - cx) * c - (y - cy) * s, (x - cx) * s + (y - cy) * c) for x, y in points]


def from_local(points, frame):
    cx, cy, th = frame
    c, s = math.cos(th), math.sin(th)
    return [(cx + x * c - y * s, cy + x * s + y * c) for x, y in points]


# ------------------------------------------------------------------ intersecciones
def _orient(a, b, c):
    v = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
    return 0 if abs(v) < 1e-12 else (1 if v > 0 else -1)


def _on_segment(a, b, c):
    return (min(a[0], b[0]) - EPS <= c[0] <= max(a[0], b[0]) + EPS and
            min(a[1], b[1]) - EPS <= c[1] <= max(a[1], b[1]) + EPS)


def segments_intersect(p1, p2, p3, p4) -> bool:
    o1, o2, o3, o4 = _orient(p1, p2, p3), _orient(p1, p2, p4), _orient(p3, p4, p1), _orient(p3, p4, p2)
    if o1 != o2 and o3 != o4:
        return True
    if o1 == 0 and _on_segment(p1, p2, p3):
        return True
    if o2 == 0 and _on_segment(p1, p2, p4):
        return True
    if o3 == 0 and _on_segment(p3, p4, p1):
        return True
    if o4 == 0 and _on_segment(p3, p4, p2):
        return True
    return False


def self_intersections(poly) -> int:
    n = len(poly)
    if n < 3:
        return 1
    count = 0
    for i in range(n):
        a1, a2 = poly[i], poly[(i + 1) % n]
        for j in range(i + 1, n):
            if abs(i - j) <= 1 or (i == 0 and j == n - 1):
                continue
            b1, b2 = poly[j], poly[(j + 1) % n]
            if segments_intersect(a1, a2, b1, b2):
                count += 1
    return count


def is_simple(poly) -> bool:
    return len(poly) >= 3 and area(poly) > EPS and self_intersections(poly) == 0


def point_in_polygon(pt, poly) -> bool:
    x, y = pt
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y):
            xin = (xj - xi) * (y - yi) / (yj - yi + 1e-300) + xi
            if x < xin:
                inside = not inside
        j = i
    return inside


def polygon_inside(inner, outer) -> bool:
    if not all(point_in_polygon(p, outer) for p in inner):
        return False
    for i in range(len(inner)):
        for j in range(len(outer)):
            if segments_intersect(inner[i], inner[(i + 1) % len(inner)], outer[j], outer[(j + 1) % len(outer)]):
                return False
    return True


# ------------------------------------------------------------------ envolvente y anchura
def convex_hull(points):
    pts = sorted(set((round(x, 12), round(y, 12)) for x, y in points))
    if len(pts) <= 2:
        return pts

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def min_width(poly) -> float:
    """Anchura mínima (calibres rotatorios sobre la envolvente convexa)."""
    hull = convex_hull(poly)
    if len(hull) < 3:
        return 0.0
    best = float("inf")
    for i in range(len(hull)):
        a, b = hull[i], hull[(i + 1) % len(hull)]
        L = math.dist(a, b)
        if L < EPS:
            continue
        far = max(abs((b[0] - a[0]) * (a[1] - p[1]) - (a[0] - p[0]) * (b[1] - a[1])) / L for p in hull)
        best = min(best, far)
    return best if best != float("inf") else 0.0


def extent_along(poly, frame):
    loc = to_local(poly, frame)
    b = bbox(loc)
    return b[2] - b[0], b[3] - b[1], b


# ------------------------------------------------------------------ recorte por semiplano
def clip_halfplane(poly, a, b, c):
    """Conserva la parte con a·x + b·y <= c (Sutherland–Hodgman)."""
    out = []
    n = len(poly)
    for i in range(n):
        p, q = poly[i], poly[(i + 1) % n]
        fp = a * p[0] + b * p[1] - c
        fq = a * q[0] + b * q[1] - c
        if fp <= EPS:
            out.append(p)
        if (fp < -EPS and fq > EPS) or (fp > EPS and fq < -EPS):
            t = fp / (fp - fq)
            out.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])))
    return clean(out)


# ------------------------------------------------------------------ desplazamiento (offset)
def _line_intersection(p1, d1, p2, d2):
    den = d1[0] * d2[1] - d1[1] * d2[0]
    if abs(den) < 1e-12:
        return None
    t = ((p2[0] - p1[0]) * d2[1] - (p2[1] - p1[1]) * d2[0]) / den
    return (p1[0] + t * d1[0], p1[1] + t * d1[1])


def offset(poly, d):
    """Desplaza cada arista hacia fuera (d > 0) o hacia dentro (d < 0) con unión en inglete."""
    poly = ensure_ccw(clean(poly))
    n = len(poly)
    lines = []
    for i in range(n):
        p, q = poly[i], poly[(i + 1) % n]
        L = math.dist(p, q)
        if L < EPS:
            continue
        dx, dy = (q[0] - p[0]) / L, (q[1] - p[1]) / L
        nx, ny = dy, -dx  # normal exterior para polígono antihorario
        lines.append(((p[0] + nx * d, p[1] + ny * d), (dx, dy)))
    out = []
    for i in range(len(lines)):
        p1, d1 = lines[i - 1]
        p2, d2 = lines[i]
        pt = _line_intersection(p1, d1, p2, d2)
        if pt is None:
            pt = p2
        out.append(pt)
    out = clean(out)
    if len(out) < 3 or not is_simple(out) or signed_area(out) <= EPS:
        return None
    if d < 0 and not polygon_inside(out, poly):
        return None
    return out


# ------------------------------------------------------------------ redondeo y chaflán
def _corner(poly, i):
    p = poly[i]
    a = poly[i - 1]
    b = poly[(i + 1) % len(poly)]
    la, lb = math.dist(a, p), math.dist(b, p)
    u = ((a[0] - p[0]) / la, (a[1] - p[1]) / la)
    v = ((b[0] - p[0]) / lb, (b[1] - p[1]) / lb)
    cosang = max(-1.0, min(1.0, u[0] * v[0] + u[1] * v[1]))
    return p, u, v, la, lb, math.acos(cosang)


def fillet(poly, r, segments: int = 6, only_convex: bool = False):
    """Redondea cada esquina con radio r (se limita si las aristas son cortas).

    Devuelve (polígono, radio mínimo efectivamente aplicado).
    """
    poly = ensure_ccw(clean(poly))
    out = []
    applied = []
    n = len(poly)
    for i in range(n):
        p, u, v, la, lb, theta = _corner(poly, i)
        if theta < 1e-3 or abs(theta - math.pi) < 1e-3:
            out.append(p)
            continue
        cross = u[0] * v[1] - u[1] * v[0]
        convex = cross < 0  # en polígono antihorario, esquina convexa
        if only_convex and not convex:
            out.append(p)
            continue
        t = r / math.tan(theta / 2)
        tmax = 0.49 * min(la, lb)
        rr = r
        if t > tmax:
            t = tmax
            rr = t * math.tan(theta / 2)
        applied.append(rr)
        start = (p[0] + u[0] * t, p[1] + u[1] * t)
        end = (p[0] + v[0] * t, p[1] + v[1] * t)
        bis = (u[0] + v[0], u[1] + v[1])
        bl = math.hypot(*bis)
        dist_c = rr / math.sin(theta / 2)
        c = (p[0] + bis[0] / bl * dist_c, p[1] + bis[1] / bl * dist_c)
        a0 = math.atan2(start[1] - c[1], start[0] - c[0])
        a1 = math.atan2(end[1] - c[1], end[0] - c[0])
        da = a1 - a0
        while da > math.pi:
            da -= 2 * math.pi
        while da < -math.pi:
            da += 2 * math.pi
        for k in range(segments + 1):
            ang = a0 + da * k / segments
            out.append((c[0] + rr * math.cos(ang), c[1] + rr * math.sin(ang)))
    out = clean(out)
    return out, (min(applied) if applied else 0.0)


def chamfer(poly, d):
    poly = ensure_ccw(clean(poly))
    out = []
    for i in range(len(poly)):
        p, u, v, la, lb, theta = _corner(poly, i)
        t = min(d, 0.45 * min(la, lb))
        if theta < 1e-3 or abs(theta - math.pi) < 1e-3:
            out.append(p)
            continue
        out.append((p[0] + u[0] * t, p[1] + u[1] * t))
        out.append((p[0] + v[0] * t, p[1] + v[1] * t))
    return clean(out)


def ellipse_in_frame(frame, half_len, half_wid, n: int = 36):
    pts = [(half_len * math.cos(2 * math.pi * i / n), half_wid * math.sin(2 * math.pi * i / n)) for i in range(n)]
    return from_local(pts, frame)


# ------------------------------------------------------------------ rasterizado
def rasterize(polys_with_holes, grid: int, box):
    """Rejilla booleana grid×grid de los polígonos (con agujeros) dentro de box."""
    x0, y0, x1, y1 = box
    w = max(x1 - x0, EPS)
    h = max(y1 - y0, EPS)
    side = max(w, h)
    ox = x0 - (side - w) / 2
    oy = y0 - (side - h) / 2
    cells = [[False] * grid for _ in range(grid)]
    for poly, holes in polys_with_holes:
        bx = bbox(poly)
        for r in range(grid):
            y = oy + (r + 0.5) * side / grid
            if y < bx[1] or y > bx[3]:
                continue
            for c in range(grid):
                x = ox + (c + 0.5) * side / grid
                if x < bx[0] or x > bx[2]:
                    continue
                if point_in_polygon((x, y), poly) and not any(point_in_polygon((x, y), hh) for hh in holes):
                    cells[r][c] = True
    return cells


def iou(a, b) -> float:
    inter = union = 0
    for ra, rb in zip(a, b):
        for ca, cb in zip(ra, rb):
            if ca or cb:
                union += 1
                if ca and cb:
                    inter += 1
    return inter / union if union else 1.0
