"""Diversidad y novedad formal por intersección sobre unión de rejillas normalizadas (C10.2, C30)."""
from __future__ import annotations

from . import geometry as geo

GRID = 32


def raster(shape, grid: int = GRID):
    return shape.raster(grid)


def similarity(a, b) -> float:
    return geo.iou(a, b)


def novelty(raster_alt, reference_rasters) -> float:
    """1 − máxima similitud con las formas de referencia; None si no hay referencias."""
    if not reference_rasters:
        return None
    return round(1 - max(similarity(raster_alt, r) for r in reference_rasters), 4)
