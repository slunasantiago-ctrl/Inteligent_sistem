"""Carga y validación de la gramática: formas iniciales, familias, reglas, guardas, TRIZ → familias (C9, C16, C17, C28)."""
from __future__ import annotations

import os

from isppr_platform.datastore import load_json

from . import guards as G
from .operations import OPERATIONS, TARGET_KIND
from .vocabulary import Shape


class GrammarBase:
    def __init__(self, data_dir: str, mode):
        self.mode = mode
        g = os.path.join(data_dir, "grammar")
        self.initial_shapes = {s["shape_id"]: s for s in load_json(os.path.join(g, "initial_shapes.json"), {"shapes": []})["shapes"]}
        self.families = {f["family_id"]: f for f in load_json(os.path.join(g, "families.json"), {"families": []})["families"]}
        self.rules = {r["rule_id"]: r for r in load_json(os.path.join(g, "rules.json"), {"rules": []})["rules"]}
        self.guards = {x["guard_id"]: x for x in load_json(os.path.join(g, "guards.json"), {"guards": []})["guards"]}
        self.triz_map = load_json(os.path.join(g, "triz_family_map.json"), {"map": []})["map"]

    # ------------------------------------------------------------- visibilidad (C17)
    def visible(self, item):
        return self.mode.visible(item)

    def visible_rules(self):
        return {k: r for k, r in self.rules.items() if self.visible(r)}

    def visible_shapes(self):
        return {k: s for k, s in self.initial_shapes.items() if self.visible(s)}

    def visible_guards(self):
        return {k: g for k, g in self.guards.items() if self.visible(g)}

    def visible_families(self):
        return {k: f for k, f in self.families.items() if self.visible(f)}

    def shape(self, shape_id) -> Shape:
        return Shape.from_dict(self.initial_shapes[shape_id]["shape"])

    def rules_of_family(self, family_id):
        return [r for r in self.visible_rules().values() if r.get("family_id") == family_id]

    # ------------------------------------------------------------- TRIZ (C28)
    def families_for_principles(self, principle_ids):
        """Devuelve ({family_id: [principios]}, principios sin fila aprobada)."""
        out, without = {}, []
        rows = [r for r in self.triz_map if self.visible(r)]
        for pid in principle_ids:
            matched = [r for r in rows if int(r["principle_id"]) == int(pid)]
            if not matched:
                without.append(pid)
            for r in matched:
                for fid in r["family_ids"]:
                    if fid in self.visible_families():
                        out.setdefault(fid, []).append(pid)
        return out, without

    # ------------------------------------------------------------- validación (C19)
    def validate(self):
        errors = []
        for rid, r in self.rules.items():
            if r.get("operation") not in OPERATIONS:
                errors.append(f"rule {rid}: unknown operation {r.get('operation')}")
            if r.get("family_id") not in self.families:
                errors.append(f"rule {rid}: unknown family {r.get('family_id')}")
            for gid in r.get("guards_pre", []) + r.get("guards_post", []):
                if gid not in self.guards:
                    errors.append(f"rule {rid}: unknown guard {gid}")
            if not r.get("source"):
                errors.append(f"rule {rid}: without source")
            kind = (r.get("lhs") or {}).get("kind", "element")
            if TARGET_KIND.get(r.get("operation"), "element") != kind:
                errors.append(f"rule {rid}: lhs kind {kind} does not match operation")
        for gid, g in self.guards.items():
            try:
                G.parse(g["expr"])
            except G.GuardSyntaxError as exc:
                errors.append(f"guard {gid}: {exc}")
            if not g.get("source"):
                errors.append(f"guard {gid}: without source")
        for row in self.triz_map:
            pid = int(row.get("principle_id", 0))
            if not 1 <= pid <= 40:
                errors.append(f"triz map: principle out of range {pid}")
            for fid in row.get("family_ids", []):
                if fid not in self.families:
                    errors.append(f"triz map {pid}: unknown family {fid}")
        return errors
