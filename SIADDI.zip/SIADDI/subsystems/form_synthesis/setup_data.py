"""Carga y verificación de datos del subsistema 3 — SIADEF (C43).

Uso (desde la raíz):
    python3 setup_data.py form_synthesis import-shapes archivo.json --source "..."
    python3 setup_data.py form_synthesis import-rules archivo.json --source "..."
    python3 setup_data.py form_synthesis import-guards archivo.json --source "..."
    python3 setup_data.py form_synthesis import-triz-map archivo.json --source "..."
    python3 setup_data.py form_synthesis import-preferred-numbers archivo.json --standard ... --edition ... --source "..."
    python3 setup_data.py form_synthesis import-tolerances archivo.json --standard ... --edition ... --source "..."
    python3 setup_data.py form_synthesis import-capability archivo.csv --source "..."
    python3 setup_data.py form_synthesis import-indicators archivo.json --source "..."
    python3 setup_data.py form_synthesis import-scales archivo.json --source "..."
    python3 setup_data.py form_synthesis import-concepts archivo.json --source "..."
    python3 setup_data.py form_synthesis import-glossary archivo.json --source "..."
    python3 setup_data.py form_synthesis status
La importación valida formato, IDs únicos y estables, referencias cruzadas y presencia de source.
Si falla, no se escribe nada y se muestra el motivo.
"""
from __future__ import annotations

import argparse
import csv
import os

from isppr_platform.datastore import DataMode, load_json, save_json

from .core.knowledge import SUB_ROOT, FormKnowledge
from .grammar import guards as G
from .grammar.operations import OPERATIONS, TARGET_KIND
from .quality.process_capability_db import LEVELS

DATA = os.path.join(SUB_ROOT, "data")


class ImportFailed(Exception):
    pass


def _records(path, key):
    data = load_json(path)
    recs = data.get(key, data) if isinstance(data, dict) else data
    if not isinstance(recs, list):
        raise ImportFailed(f"formato: lista o {{'{key}': [...]}}")
    return recs


def _check_ids(recs, key):
    ids = [r.get(key) for r in recs]
    if None in ids:
        raise ImportFailed(f"falta '{key}'")
    if len(ids) != len(set(ids)):
        raise ImportFailed(f"'{key}' duplicado")


def _sources(recs, source):
    for r in recs:
        r.setdefault("source", source)
        if not r.get("source"):
            raise ImportFailed("--source es obligatorio")
        r.setdefault("status", "approved")


def _merge(target, key, idkey, recs):
    base = load_json(target, {key: []})
    by = {x[idkey]: x for x in base.get(key, [])}
    for r in recs:
        by[r[idkey]] = r
    base[key] = list(by.values())
    save_json(target, base)


def import_rules(path, source, data_dir=DATA):
    recs = _records(path, "rules")
    _check_ids(recs, "rule_id")
    _sources(recs, source)
    families = {f["family_id"] for f in load_json(os.path.join(data_dir, "grammar", "families.json"), {"families": []})["families"]}
    guards = {g["guard_id"] for g in load_json(os.path.join(data_dir, "grammar", "guards.json"), {"guards": []})["guards"]}
    for r in recs:
        if r.get("operation") not in OPERATIONS:
            raise ImportFailed(f"{r['rule_id']}: operación inexistente {r.get('operation')}")
        if r.get("family_id") not in families:
            raise ImportFailed(f"{r['rule_id']}: familia inexistente {r.get('family_id')}")
        for gid in r.get("guards_pre", []) + r.get("guards_post", []):
            if gid not in guards:
                raise ImportFailed(f"{r['rule_id']}: guarda inexistente {gid}")
        if r.get("status") not in ("draft", "approved"):
            raise ImportFailed(f"{r['rule_id']}: estado inválido")
        kind = (r.get("lhs") or {}).get("kind", "element")
        if TARGET_KIND.get(r["operation"], "element") != kind:
            raise ImportFailed(f"{r['rule_id']}: lhs.kind no corresponde a la operación")
    _merge(os.path.join(data_dir, "grammar", "rules.json"), "rules", "rule_id", recs)
    return len(recs)


def import_guards(path, source, data_dir=DATA):
    recs = _records(path, "guards")
    _check_ids(recs, "guard_id")
    _sources(recs, source)
    for g in recs:
        try:
            G.parse(g["expr"])
        except (G.GuardSyntaxError, KeyError) as exc:
            raise ImportFailed(f"{g['guard_id']}: expresión inválida ({exc})")
        if g.get("type") == "normative" and not (g.get("standard_id") and g.get("edition")):
            raise ImportFailed(f"{g['guard_id']}: una guarda normativa necesita standard_id y edition")
    _merge(os.path.join(data_dir, "grammar", "guards.json"), "guards", "guard_id", recs)
    return len(recs)


def import_shapes(path, source, data_dir=DATA):
    recs = _records(path, "shapes")
    _check_ids(recs, "shape_id")
    _sources(recs, source)
    from .grammar import geometry as geo
    for s in recs:
        for e in s.get("shape", {}).get("elements", []):
            if not geo.is_simple([tuple(p) for p in e["points"]]):
                raise ImportFailed(f"{s['shape_id']}: elemento {e.get('eid')} no es un polígono simple")
    _merge(os.path.join(data_dir, "grammar", "initial_shapes.json"), "shapes", "shape_id", recs)
    return len(recs)


def import_triz_map(path, source, data_dir=DATA):
    recs = _records(path, "map")
    families = {f["family_id"] for f in load_json(os.path.join(data_dir, "grammar", "families.json"), {"families": []})["families"]}
    _sources(recs, source)
    for r in recs:
        pid = r.get("principle_id")
        if not isinstance(pid, int) or not 1 <= pid <= 40:
            raise ImportFailed(f"principio fuera de 1..40: {pid}")
        bad = [f for f in r.get("family_ids", []) if f not in families]
        if bad:
            raise ImportFailed(f"principio {pid}: familias inexistentes {bad}")
    base = load_json(os.path.join(data_dir, "grammar", "triz_family_map.json"), {"map": []})
    by = {r["principle_id"]: r for r in base["map"]}
    for r in recs:
        by[r["principle_id"]] = r
    base["map"] = [by[k] for k in sorted(by)]
    save_json(os.path.join(data_dir, "grammar", "triz_family_map.json"), base)
    return len(recs)


def import_preferred(path, standard, edition, source, data_dir=DATA):
    data = load_json(path)
    series = data.get("series") if isinstance(data, dict) else None
    if not series:
        raise ImportFailed("formato: {'series': {'R10': [...], ...}}")
    for sid, vals in series.items():
        if any(not isinstance(v, (int, float)) or v <= 0 for v in vals) or vals != sorted(vals):
            raise ImportFailed(f"serie {sid}: valores no positivos o no ordenados")
    save_json(os.path.join(data_dir, "standards", "preferred_numbers.json"),
              {"status": "approved", "standard": standard, "edition": edition, "source": source,
               "series": series, "decade_extension": data.get("decade_extension", True)})
    return len(series)


def import_tolerances(path, standard, edition, source, data_dir=DATA):
    recs = _records(path, "tables")
    _check_ids(recs, "table_id")
    for t in recs:
        t.update({"standard": standard, "edition": edition, "source": source, "status": t.get("status", "approved")})
        if not t.get("license"):
            raise ImportFailed(f"{t['table_id']}: indica 'license' (derecho de uso, B30)")
        prev = 0
        for lo, hi, tol in t.get("ranges", []):
            if lo < prev or hi <= lo or tol <= 0:
                raise ImportFailed(f"{t['table_id']}: rangos inválidos")
            prev = hi
    _merge(os.path.join(data_dir, "standards", "tolerance_tables.json"), "tables", "table_id", recs)
    return len(recs)


def import_capability(path, source, data_dir=DATA):
    """CSV: capability_id,process_id,material_id,feature_type,range_min_mm,range_max_mm,sigma_mm,
    mean_shift_mm,distribution,data_quality,sample_size,derivation_note"""
    recs = []
    with open(path, encoding="utf-8-sig", newline="") as fh:
        for i, row in enumerate(csv.DictReader(fh), start=2):
            try:
                rec = {"capability_id": row["capability_id"], "process_id": row["process_id"],
                       "material_id": row.get("material_id") or None, "feature_type": row["feature_type"],
                       "range_mm": [float(row["range_min_mm"]), float(row["range_max_mm"])],
                       "sigma_mm": float(row["sigma_mm"]), "mean_shift_mm": float(row.get("mean_shift_mm") or 0),
                       "distribution": row.get("distribution") or "normal", "data_quality": row["data_quality"],
                       "sample_size": int(row["sample_size"]) if row.get("sample_size") else None,
                       "derivation_note": {"es": row.get("derivation_note") or None, "en": None, "ru": None},
                       "source": source, "verified_on": None, "status": "approved"}
            except (KeyError, ValueError) as exc:
                raise ImportFailed(f"línea {i}: {exc}")
            if rec["data_quality"] not in LEVELS:
                raise ImportFailed(f"línea {i}: data_quality debe ser uno de {LEVELS}")
            if rec["data_quality"] == "C_derived_from_IT_grade" and not rec["derivation_note"]["es"]:
                raise ImportFailed(f"línea {i}: el nivel C exige derivation_note con el supuesto")
            recs.append(rec)
    _check_ids(recs, "capability_id")
    target = os.path.join(data_dir, "process_capability.json")
    base = load_json(target, {"records": []})
    by = {r["capability_id"]: r for r in base.get("records", [])}
    for r in recs:
        by[r["capability_id"]] = r
    from .quality.process_capability_db import CapabilityDB
    test = CapabilityDB({"records": list(by.values())}, DataMode())
    errs = test.validate()
    if errs:
        raise ImportFailed("; ".join(errs))
    base["records"] = list(by.values())
    base.pop("note", None)
    save_json(target, base)
    return len(recs)


def import_simple(path, source, filename, key, idkey, data_dir=DATA):
    recs = _records(path, key)
    _check_ids(recs, idkey)
    _sources(recs, source)
    _merge(os.path.join(data_dir, filename), key, idkey, recs)
    return len(recs)


def status_report(kb=None):
    kb = kb or FormKnowledge()
    g = kb.grammar
    def count(items):
        st = {}
        for it in items:
            st[it.get("status", "approved")] = st.get(it.get("status", "approved"), 0) + 1
        return ", ".join(f"{k}={v}" for k, v in sorted(st.items())) or "—"
    lines = ["== SIADEF — estado de los datos ==",
             f"Formas iniciales: {count(g.initial_shapes.values())}",
             f"Familias: {count(g.families.values())}",
             f"Reglas: {count(g.rules.values())}",
             f"Guardas: {count(g.guards.values())}",
             f"Tabla TRIZ → familias: {count(g.triz_map)}; principios sin fila: "
             + ", ".join(str(p) for p in range(1, 41) if p not in {int(r['principle_id']) for r in g.triz_map}),
             f"Números preferidos: estado={kb.preferred_meta.get('status')} series={list((kb.preferred_meta.get('series') or {}).keys())}",
             f"Tablas de tolerancias aprobadas: {len(kb.tolerance_tables)}",
             f"Capacidades de proceso cargadas: {len(kb.capability.records)} (procesos: {', '.join(kb.capability.processes()) or '—'})",
             f"Indicadores: estado={kb.indicators_data.get('status')} ({len(kb.indicators_data.get('indicators', []))})",
             f"Escalas semánticas: estado={kb.scales.get('status')}",
             f"Formas de referencia: estado={load_json(os.path.join(kb.data_dir, 'reference_shapes', 'references.json'), {}).get('status')}"]
    per_family = {}
    for r in g.rules.values():
        per_family[r["family_id"]] = per_family.get(r["family_id"], 0) + 1
    lines.append("Reglas por familia: " + ", ".join(f"{f}={per_family.get(f, 0)}" for f in sorted(g.families)))
    errs = kb.validate()
    lines.append("Validación: " + ("OK" if not errs else "; ".join(errs)))
    return "\n".join(lines)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="setup_data.py form_synthesis")
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("import-shapes", "import-rules", "import-guards", "import-triz-map", "import-capability",
                 "import-indicators", "import-scales", "import-concepts", "import-glossary"):
        s = sub.add_parser(name)
        s.add_argument("file")
        s.add_argument("--source", required=True)
    for name in ("import-preferred-numbers", "import-tolerances"):
        s = sub.add_parser(name)
        s.add_argument("file")
        s.add_argument("--standard", required=True)
        s.add_argument("--edition", required=True)
        s.add_argument("--source", required=True)
    sub.add_parser("status")
    a = p.parse_args(argv)
    try:
        fn = {
            "import-shapes": lambda: import_shapes(a.file, a.source),
            "import-rules": lambda: import_rules(a.file, a.source),
            "import-guards": lambda: import_guards(a.file, a.source),
            "import-triz-map": lambda: import_triz_map(a.file, a.source),
            "import-capability": lambda: import_capability(a.file, a.source),
            "import-indicators": lambda: import_simple(a.file, a.source, "indicators.json", "indicators", "indicator_id"),
            "import-scales": lambda: import_simple(a.file, a.source, "semantic_scales.json", "scales", "scale_id"),
            "import-concepts": lambda: import_simple(a.file, a.source, "concepts.json", "concepts", "concept_id"),
            "import-glossary": lambda: import_simple(a.file, a.source, "glossary.json", "terms", "term_id"),
            "import-preferred-numbers": lambda: import_preferred(a.file, a.standard, a.edition, a.source),
            "import-tolerances": lambda: import_tolerances(a.file, a.standard, a.edition, a.source),
        }.get(a.cmd)
        if fn is None:
            print(status_report())
            return 0
        print(f"registros importados: {fn()}")
    except (ImportFailed, ValueError, FileNotFoundError) as exc:
        print(f"ERROR: {exc} — no se escribió nada")
        return 1
    return 0
