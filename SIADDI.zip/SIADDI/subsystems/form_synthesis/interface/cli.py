"""Interfaz de terminal del subsistema 3 — SIADEF (C7–C11, C21, C22, C26, C27, C28–C35).

Solo presenta y pregunta: la lógica vive en core/, grammar/ y quality/; la salida gráfica en render/.
"""
from __future__ import annotations

import os

from isppr_platform import language_select, mcda, terminal
from isppr_platform.datastore import DataMode
from isppr_platform.dialog import Dialog
from isppr_platform.i18n import number, pick
from isppr_platform.subsystem import RESULT_MENU, ReturnToMenu

from ..core import context as CTX
from ..core import decision_record as REC
from ..core import dimensioning as DIM
from ..core import evaluation as EVAL
from ..core import generation as GEN
from ..core import grammar_analysis as GA
from ..core import handoff as HO
from ..core import interpretation as INT
from ..core.knowledge import FormKnowledge
from ..core.session import EvaluatedAlternative, FormState
from ..core.synthesis_problem import SynthesisProblem, new_seed
from ..grammar import geometry as geo
from ..grammar import guards as G
from ..language.manager import translator
from ..quality import capability as CAP
from ..quality import consumer as CONS
from ..quality import learning as LEARN
from ..render import preview_ascii, terminal_image

SUBSYSTEM_ID = "standardization"
HEADER = ("SIADEF", "Sistema Inteligente de Apoyo a Decisiones", "en la Exploración de la Forma")
LEARN_FILE = os.path.join(GEN.OUTPUT, "rule_weights_learning.json")


class SiadefCLI:
    def __init__(self, session, io, kb: FormKnowledge = None):
        self.session = session
        self.io = io
        self.kb = kb or FormKnowledge(DataMode(session.demo, session.draft))
        self.dlg = Dialog(io, session, translator())
        self.state = session.state_for(SUBSYSTEM_ID, FormState)

    # ------------------------------------------------------------ helpers
    def t(self, key, **kw):
        return self.dlg.t(key, **kw)

    @property
    def lang(self):
        return self.dlg.lang

    def n(self, v, d=2):
        return number(v, self.lang, d)

    def raw(self, v):
        return self.n(v, 3) if isinstance(v, float) else str(v)

    def txt(self, texts):
        v = pick(texts, self.lang)
        return v if v else self.t("translation_pending_text")

    def labelled(self, who, text):
        key = {"student": "label_student", "system": "label_system", "decision": "label_decision"}[who]
        self.dlg.say(terminal.style(f"[{self.t(key)}]", "accent2") + " " + text)

    def badge(self, item):
        lab = self.kb.label(item)
        if lab == "DEMO":
            return terminal.style(" [DEMO]", "warn")
        if lab == "draft":
            return terminal.style(" [" + self.t("draft_label") + "]", "warn")
        return ""

    def demo_notice(self):
        if self.kb.is_demo:
            self.dlg.warn(self.t("demo_notice"))
        elif self.session.draft:
            self.dlg.warn(self.t("draft_notice"))

    def family_name(self, fid):
        f = self.kb.grammar.families.get(fid)
        return self.txt(f["names"]) if f else fid

    def rule_name(self, rid):
        r = self.kb.grammar.rules.get(rid)
        return self.txt(r["names"]) if r else rid

    def guard_name(self, gid):
        g = self.kb.grammar.guards.get(gid)
        return self.txt(g["names"]) if g else gid

    def shape_name(self, sid):
        s = self.kb.grammar.initial_shapes.get(sid)
        return self.txt(s["names"]) if s else (self.t("student_shape") if sid is None else sid)

    def process_name(self, pid):
        return self.kb.process_name(pid, self.lang) or self.t("not_defined")

    def material_name(self, mid):
        return self.kb.material_name(mid, self.lang) or self.t("not_defined")

    def decision_text(self, key, kw):
        return self.t(key, **{k: (self.n(v, 2) if isinstance(v, float) else v) for k, v in kw.items()})

    def log(self, stage, key, **kw):
        self.state.decisions.append([stage, key, kw])

    # ------------------------------------------------------------ flujo
    def run(self) -> str:
        if not self.session.language:
            self.session.language = language_select.select_language(self.io, HEADER)
        try:
            if self.state.stage > 1:
                self.dlg.title(self.t("resume_title"))
                self.dlg.option("1", self.t("resume_continue", stage=self.state.stage))
                self.dlg.option("2", self.t("resume_new"))
                if self.dlg.choose(["1", "2"]) == "2":
                    self.reset()
            stages = {1: self.stage1, 2: self.stage2, 3: self.stage3, 4: self.stage4, 5: self.stage5, 6: self.stage6}
            while self.state.stage in stages:
                stages[self.state.stage]()
            return RESULT_MENU
        except ReturnToMenu:
            return RESULT_MENU

    def reset(self):
        self.session.subsystem_states[SUBSYSTEM_ID] = FormState()
        self.state = self.session.subsystem_states[SUBSYSTEM_ID]

    # ETAPA 1 -------------------------------------------------------------
    def stage1(self):
        self.dlg.title(self.t("stage1_title"))
        self.dlg.hint_globals()
        self.dlg.note(self.t("stage1_help"))
        self.state.idea = self.dlg.ask_text("describe_idea")
        self.state.profile = CTX.build_profile(self.kb, self.state.idea)
        self.edit_profile()
        self.state.stage = 2

    def show_profile(self):
        p = self.state.profile
        self.dlg.section(self.t("profile_title"))
        prop = lambda f: terminal.style(" (" + self.t("proposed") + ")", "muted") if f in p.proposed_by_system else ""
        self.dlg.say(f"  [{terminal.style('1', 'accent')}] {self.t('f_product')}: {p.product or self.t('not_defined')}")
        self.dlg.say(f"  [{terminal.style('2', 'accent')}] {self.t('f_function')}: {p.function or self.t('not_defined')}")
        self.dlg.say(f"  [{terminal.style('3', 'accent')}] {self.t('f_user')}: {p.user_context or self.t('not_defined')}")
        self.dlg.say(f"  [{terminal.style('4', 'accent')}] {self.t('f_material')}: {self.material_name(p.material_id)}{prop('material_id')}")
        self.dlg.say(f"  [{terminal.style('5', 'accent')}] {self.t('f_process')}: {self.process_name(p.process_id)}{prop('process_id')}")
        q = self.state.quality
        self.dlg.say(f"      {self.t('f_standards')}: " + (", ".join(f"{s.get('designation')} ({s.get('edition') or '—'}, {s.get('status') or '—'})" for s in q["standards"]) if q and q.get("standards") else self.t("none")))
        tz = self.state.triz
        self.dlg.say(f"      {self.t('f_requirements')}: " + (f"TRIZ {tz.get('contradiction')} → {tz.get('principles')}" if tz else "") + (f" · {self.state.form_goal}" if self.state.form_goal else "") if (tz or self.state.form_goal) else f"      {self.t('f_requirements')}: {self.t('none')}")
        self.dlg.note(self.t("catalog_provisional"))

    def pick_catalog(self, items, id_field):
        items = list(items.values())
        for i, it in enumerate(items, start=1):
            self.dlg.option(str(i), self.txt(it["names"]))
        self.dlg.option("0", self.t("not_defined"))
        k = self.dlg.ask_int("ask_number_or_zero", 0, len(items))
        return None if k == 0 else items[k - 1][id_field]

    def edit_profile(self):
        p = self.state.profile
        while True:
            self.show_profile()
            self.dlg.say(self.t("edit_profile_prompt"))
            ch = self.dlg.choose(["1", "2", "3", "4", "5"], allow_empty=True)
            if not ch:
                self.log(1, "dec_profile_confirmed")
                return
            if ch == "1":
                p.product = self.dlg.ask_text("ask_product")
            elif ch == "2":
                p.function = self.dlg.ask_text("ask_function")
            elif ch == "3":
                p.user_context = self.dlg.ask_text("ask_user")
            elif ch == "4":
                p.material_id = self.pick_catalog(self.kb.materials, "material_id")
                if "material_id" in p.proposed_by_system:
                    p.proposed_by_system.remove("material_id")
            elif ch == "5":
                p.process_id = self.pick_catalog(self.kb.processes, "process_id")
                if "process_id" in p.proposed_by_system:
                    p.proposed_by_system.remove("process_id")

    # ETAPA 2 -------------------------------------------------------------
    def stage2(self):
        while True:
            self.dlg.title(self.t("stage2_title"))
            self.dlg.option("1", self.t("opt_import_triz"))
            self.dlg.option("2", self.t("opt_import_quality"))
            self.dlg.option("3", self.t("opt_declare_manual"))
            self.dlg.option("c", self.t("opt_continue"))
            if self.state.triz:
                self.labelled("system", self.t("imported_from", origin="SIADDI", file=os.path.basename(self.state.triz["file"]), date=self.state.triz["created_at"]))
            if self.state.quality:
                self.labelled("system", self.t("imported_from", origin="SIADEC", file=os.path.basename(self.state.quality["file"]), date=self.state.quality["created_at"]))
            if self.state.form_goal:
                self.labelled("student", f"{self.t('f_form_goal')}: {self.state.form_goal}")
            ch = self.dlg.choose(["1", "2", "3", "c"])
            if ch == "1":
                self.import_file(HO.ORIGIN_TRIZ)
            elif ch == "2":
                self.import_file(HO.ORIGIN_QUALITY)
            elif ch == "3":
                self.state.form_goal = self.dlg.ask_text("ask_form_goal")
                self.state.form_constraints = self.dlg.ask(self.t("ask_form_constraints") + " ")
                if self.dlg.yes_no("ask_manual_principles", default=False):
                    ids = self.dlg.ask_int_list("ask_principle_ids", 1, 40)
                    if ids:
                        self.state.triz = {"file": "manual", "created_at": "—", "principles": ids, "contradiction": None,
                                           "manual": True, "project": None, "problem": None}
                self.log(2, "dec_manual_requirements")
            else:
                if not (self.state.triz or self.state.quality or self.state.form_goal):
                    self.dlg.note(self.t("nothing_imported"))
                    self.state.form_goal = self.dlg.ask_text("ask_form_goal")
                self.state.stage = 3
                return

    def import_file(self, origin):
        files = HO.available(origin)
        if not files:
            self.dlg.warn(self.t("no_exchange_files", origin="SIADDI" if origin == HO.ORIGIN_TRIZ else "SIADEC"))
            path = self.dlg.ask(self.t("ask_path_optional") + " ")
            if not path:
                return
            files = [os.path.expanduser(path)]
        else:
            for i, f in enumerate(files[:9], start=1):
                self.dlg.option(str(i), os.path.basename(f))
            self.dlg.option("r", self.t("opt_other_path"))
            ch = self.dlg.choose([str(i) for i in range(1, min(9, len(files)) + 1)] + ["r"])
            if ch == "r":
                files = [os.path.expanduser(self.dlg.ask_text("ask_path"))]
            else:
                files = [files[int(ch) - 1]]
        try:
            data = HO.read_triz(files[0], self.kb.is_demo) if origin == HO.ORIGIN_TRIZ else HO.read_quality(files[0], self.kb.is_demo)
        except HO.HandoffError as exc:
            self.dlg.warn(self.t("import_rejected", reason=str(exc)))
            return
        if origin == HO.ORIGIN_TRIZ:
            c = data.get("contradiction") or {}
            self.dlg.say(f"  {self.t('contradiction')}: {c.get('improving')} × {c.get('worsening')}")
            names = data.get("principle_names", {})
            for pid in data["principles"]:
                nm = (names.get(str(pid)) or {}).get("names") or {}
                self.dlg.bullet(f"{pid} {pick(nm, self.lang) or ''}")
        else:
            for s in data["standards"]:
                self.dlg.bullet(f"{s.get('designation')} — {s.get('edition') or '—'} — {s.get('status') or '—'}")
            for r in data.get("restrictions", []):
                self.dlg.bullet(f"{self.t('restriction')}: {r}")
        self.dlg.option("a", self.t("opt_accept"))
        self.dlg.option("d", self.t("opt_discard"))
        if self.dlg.choose(["a", "d"]) == "a":
            if origin == HO.ORIGIN_TRIZ:
                self.state.triz = data
                self.log(2, "dec_import_triz", file=os.path.basename(files[0]))
            else:
                self.state.quality = data
                self.log(2, "dec_import_quality", file=os.path.basename(files[0]))
            self.dlg.ok(self.t("import_ok"))

    # ETAPA 3 -------------------------------------------------------------
    def stage3(self):
        if not self.kb.grammar.visible_rules():
            self.dlg.title(self.t("stage3_title"))
            self.dlg.warn(self.t("no_rules_available"))
            self.dlg.pause()
            raise ReturnToMenu()
        text = CTX.requirements_text(self.state, self.lang)
        interp = GA.analyze(self.kb, text, self.state.profile, self.state.triz, self.state.quality, self.state.manual_families)
        self.state.interpretation = interp
        while True:
            self.dlg.title(self.t("stage3_title"))
            self.demo_notice()
            self.labelled("system", self.t("hypothesis_note"))
            self.dlg.section(self.t("families_label"))
            if not interp.families:
                self.dlg.warn(self.t("no_families"))
            for i, (fid, vias) in enumerate(sorted(interp.families.items(), key=lambda kv: -len(kv[1]))):
                role = self.t("principal") if i == 0 else self.t("secondary")
                n_rules = len(self.kb.grammar.rules_of_family(fid))
                self.dlg.say(f"  {self.family_name(fid)} — {role} · {self.t('via')}: {', '.join(self.via_text(v) for v in vias)} · {self.t('n_rules', n=n_rules)}"
                             + self.badge(self.kb.grammar.families.get(fid)))
            for pid in interp.principles_without_family:
                self.dlg.warn(self.t("principle_without_family", pid=pid))
            self.dlg.section(self.t("initial_shape_label"))
            self.dlg.say(f"  {self.shape_name(interp.initial_shape_id)}" + (f" — {self.t('because_words', words=', '.join(interp.shape_reason))}" if interp.shape_reason else f" — {self.t('default_shape')}"))
            self.dlg.section(self.t("guards_label"))
            for gid, why in interp.guards.items():
                g = self.kb.grammar.guards[gid]
                self.dlg.say(f"  {self.guard_name(gid)} [{g['expr']}] — {self.t('gtype_' + g['type'])}{self.badge(g)}")
            for sid in interp.standards_without_guards:
                self.dlg.warn(self.t("standard_without_guards", std=sid))
            self.dlg.say(f"  {self.t('confidence')}: {self.n(interp.confidence)} ({self.t('level_' + interp.level)})")
            if interp.alternatives_shapes:
                self.dlg.say(f"  {self.t('alternatives')}: " + ", ".join(self.shape_name(s) for s in interp.alternatives_shapes))
            self.dlg.blank()
            for k, lab in (("c", "opt_confirm"), ("f", "opt_families"), ("s", "opt_other_shape"), ("d", "opt_draw_shape"), ("?", "opt_why")):
                self.dlg.option(k, self.t(lab))
            ch = self.dlg.choose(["c", "f", "s", "d", "?"])
            if ch == "?":
                for cid, words in interp.concepts.items():
                    self.dlg.bullet(self.t("why_concept", concept=cid, words=", ".join(words)))
                for row in self.kb.grammar.triz_map:
                    if self.state.triz and int(row["principle_id"]) in (self.state.triz.get("principles") or []):
                        self.dlg.bullet(self.t("why_triz_row", pid=row["principle_id"], fams=", ".join(row["family_ids"]),
                                               just=self.txt(row.get("justification")), src=row.get("source")) + self.badge(row))
                self.dlg.pause()
            elif ch == "f":
                fams = list(self.kb.grammar.visible_families())
                for i, fid in enumerate(fams, start=1):
                    mark = "★" if fid in interp.families else " "
                    self.dlg.say(f"  [{i}] {mark} {self.family_name(fid)}")
                nums = self.dlg.ask_int_list("ask_toggle_families", 1, len(fams))
                for k in nums:
                    fid = fams[k - 1]
                    if fid in interp.families:
                        interp.families.pop(fid)
                        if fid in self.state.manual_families:
                            self.state.manual_families.remove(fid)
                    else:
                        interp.families[fid] = ["student"]
                        self.state.manual_families.append(fid)
                self.log(3, "dec_families_modified")
            elif ch == "s":
                shapes = list(self.kb.grammar.visible_shapes())
                for i, sid in enumerate(shapes, start=1):
                    self.dlg.option(str(i), self.shape_name(sid) + " — " + self.txt(self.kb.grammar.initial_shapes[sid].get("description")))
                k = self.dlg.ask_int("ask_number", 1, len(shapes))
                interp.initial_shape_id = shapes[k - 1]
                interp.shape_reason = []
                self.state.problem.student_shape = None
            elif ch == "d":
                self.draw_shape()
            else:
                if not interp.families:
                    self.dlg.warn(self.t("need_family"))
                    continue
                self.configure_problem(interp)
                self.log(3, "dec_interpretation_confirmed")
                self.state.stage = 4
                return

    def via_text(self, v):
        kind, _, val = v.partition(":")
        if kind == "triz":
            return self.t("via_triz", pid=val)
        if kind == "concept":
            return self.t("via_concept", concept=val)
        return self.t("via_student")

    def draw_shape(self):
        """C9.7: forma inicial del estudiante por coordenadas «x,y; x,y; ...» (un polígono)."""
        self.dlg.note(self.t("draw_help"))
        raw = self.dlg.ask_text("ask_coordinates")
        try:
            pts = [tuple(float(v) for v in pair.split(",")) for pair in raw.replace(" ", "").split(";") if pair]
            if len(pts) < 3 or any(len(p) != 2 for p in pts):
                raise ValueError
        except ValueError:
            self.dlg.warn(self.t("bad_coordinates"))
            return
        x0, y0, x1, y1 = geo.bbox(pts)
        s = max(x1 - x0, y1 - y0) or 1
        norm = geo.ensure_ccw([((x - x0) / s, (y - y0) / s) for x, y in pts])
        if not geo.is_simple(norm):
            self.dlg.warn(self.t("bad_coordinates"))
            return
        self.state.problem.student_shape = {"elements": [{"eid": "e1", "points": [list(p) for p in norm],
                                                          "labels": ["divisible", "edge_ext", "repeatable", "body"],
                                                          "role": "body", "holes": [], "attrs": {}}], "anchors": [], "counter": 2}
        self.state.interpretation.initial_shape_id = None
        self.dlg.ok(self.t("student_shape_ok"))
        self.log(3, "dec_student_shape")

    def configure_problem(self, interp):
        p = self.state.problem
        p.objective = self.state.form_goal or self.state.idea
        p.initial_shape_id = interp.initial_shape_id
        p.active_families = {k: v for k, v in interp.families.items()}
        learned = LEARN.current(LEARN_FILE)
        p.active_rules = GA.rules_for_families(self.kb, p.active_families)
        p.rule_weights = {r: learned.get(r, self.kb.grammar.rules[r].get("weight", 1.0)) for r in p.active_rules}
        p.active_guards = list(interp.guards)
        proc = self.kb.processes.get(self.state.profile.process_id)
        if proc and proc.get("wall_thickness_rel"):
            p.wall_thickness = proc["wall_thickness_rel"]

    # ETAPA 4 -------------------------------------------------------------
    def stage4(self):
        p = self.state.problem
        while True:
            self.dlg.title(self.t("stage4_title"))
            self.demo_notice()
            self.show_profile()
            self.dlg.section(self.t("problem_title"))
            self.dlg.say(f"  {self.t('f_objective')}: {p.objective}")
            c = (self.state.triz or {}).get("contradiction")
            self.dlg.say(f"  {self.t('contradiction')}: " + (f"[{c.get('improving')}] × [{c.get('worsening')}]" if c else self.t("not_applicable")))
            self.dlg.say(f"  {self.t('initial_shape_label')}: {self.shape_name(p.initial_shape_id) if not p.student_shape else self.t('student_shape')}")
            self.dlg.say(f"  {self.t('families_label')}: " + ", ".join(self.family_name(f) for f in p.active_families))
            self.dlg.say(f"  [{terminal.style('r', 'accent')}] {self.t('rules_active')}:")
            for rid in p.active_rules:
                self.dlg.say(f"      {rid} — {self.rule_name(rid)} · {self.t('weight')} {self.n(p.rule_weights.get(rid, 1))}" + self.badge(self.kb.grammar.rules[rid]))
            self.dlg.say(f"  [{terminal.style('g', 'accent')}] {self.t('guards_label')}: " + ", ".join(p.active_guards))
            self.dlg.say(f"  [{terminal.style('h', 'accent')}] {self.t('f_max_height')}: {self.n(p.max_height) if p.max_height else self.t('not_declared')} · "
                         f"[{terminal.style('a', 'accent')}] {self.t('f_max_width')}: {self.n(p.max_width) if p.max_width else self.t('not_declared')}")
            self.dlg.say(f"  [{terminal.style('x', 'accent')}] {self.t('f_depth')}: {p.min_depth}–{p.max_depth} · "
                         f"[{terminal.style('n', 'accent')}] {self.t('f_n')}: {p.n_alternatives} · "
                         f"[{terminal.style('z', 'accent')}] {self.t('f_seed')}: {p.seed}")
            pn = self.t("series_unavailable") if not self.kb.preferred.available else p.preferred_series
            self.dlg.say(f"  [{terminal.style('e', 'accent')}] {self.t('f_series')}: {pn}" + self.badge(self.kb.preferred_meta))
            self.dlg.note("  " + self.t("units_abstract"))
            self.dlg.blank()
            self.dlg.option("w", self.t("opt_weights"))
            self.dlg.option("p", self.t("opt_param_ranges"))
            self.dlg.option("c", self.t("opt_confirm_generate"))
            ch = self.dlg.choose(["r", "g", "h", "a", "x", "n", "z", "e", "w", "p", "c"])
            if ch == "r":
                rules = sorted(self.kb.grammar.visible_rules())
                for i, rid in enumerate(rules, start=1):
                    mark = "★" if rid in p.active_rules else " "
                    self.dlg.say(f"  [{i}] {mark} {rid} — {self.rule_name(rid)} ({self.family_name(self.kb.grammar.rules[rid]['family_id'])})")
                for k in self.dlg.ask_int_list("ask_toggle", 1, len(rules)):
                    rid = rules[k - 1]
                    if rid in p.active_rules:
                        p.active_rules.remove(rid)
                    else:
                        p.active_rules.append(rid)
                        p.rule_weights.setdefault(rid, self.kb.grammar.rules[rid].get("weight", 1.0))
            elif ch == "g":
                gs = sorted(self.kb.grammar.visible_guards())
                for i, gid in enumerate(gs, start=1):
                    mark = "★" if gid in p.active_guards else " "
                    self.dlg.say(f"  [{i}] {mark} {gid} — {self.guard_name(gid)} ({self.t('gtype_' + self.kb.grammar.guards[gid]['type'])})")
                self.dlg.note(self.t("guard_toggle_note"))
                for k in self.dlg.ask_int_list("ask_toggle", 1, len(gs)):
                    gid = gs[k - 1]
                    if gid == "g_no_self_intersection":
                        continue
                    if gid in p.active_guards:
                        p.active_guards.remove(gid)
                    else:
                        p.active_guards.append(gid)
            elif ch == "h":
                p.max_height = self.dlg.ask_float("ask_max_height", 0.05, 5) or None
                if "g_student_height" not in p.active_guards:
                    p.active_guards.append("g_student_height")
            elif ch == "a":
                p.max_width = self.dlg.ask_float("ask_max_width", 0.05, 5) or None
                if "g_student_width" not in p.active_guards:
                    p.active_guards.append("g_student_width")
            elif ch == "x":
                p.min_depth = self.dlg.ask_int("ask_min_depth", 1, 6, default=p.min_depth)
                p.max_depth = self.dlg.ask_int("ask_max_depth", p.min_depth, 8, default=max(p.max_depth, p.min_depth))
            elif ch == "n":
                p.n_alternatives = self.dlg.ask_int("ask_n", 1, 40, default=p.n_alternatives)
            elif ch == "z":
                p.seed = self.dlg.ask_int("ask_seed", 0, 10 ** 9, default=p.seed)
            elif ch == "e":
                series = list((self.kb.preferred.series or {}).keys())
                if not series:
                    self.dlg.warn(self.t("series_unavailable"))
                    continue
                for i, s in enumerate(series, start=1):
                    self.dlg.option(str(i), s)
                p.preferred_series = series[self.dlg.ask_int("ask_number", 1, len(series)) - 1]
            elif ch == "w":
                for rid in p.active_rules:
                    p.rule_weights[rid] = self.dlg.ask_float("ask_rule_weight", 0, 10, default=p.rule_weights.get(rid, 1.0), rule=rid)
            elif ch == "p":
                self.edit_param_ranges()
            else:
                if not p.active_rules:
                    self.dlg.warn(self.t("need_rules"))
                    continue
                p.confirmed = True
                self.log(4, "dec_problem_confirmed", seed=p.seed)
                self.state.stage = 5
                return

    def edit_param_ranges(self):
        p = self.state.problem
        rules = [r for r in p.active_rules if any(s.get("type") in ("int", "float") for s in (self.kb.grammar.rules[r].get("parameters") or {}).values())]
        if not rules:
            return
        for i, rid in enumerate(rules, start=1):
            self.dlg.option(str(i), f"{rid} — {self.rule_name(rid)}")
        rid = rules[self.dlg.ask_int("ask_number", 1, len(rules)) - 1]
        for name, spec in self.kb.grammar.rules[rid]["parameters"].items():
            if spec.get("type") not in ("int", "float"):
                continue
            cur = {**spec, **p.param_overrides.get(rid, {}).get(name, {})}
            lo = self.dlg.ask_float("ask_param_min", spec["min"], spec["max"], default=cur["min"], param=name)
            hi = self.dlg.ask_float("ask_param_max", lo, spec["max"], default=cur["max"], param=name)
            if spec["type"] == "int":
                lo, hi = int(round(lo)), int(round(hi))
            p.param_overrides.setdefault(rid, {})[name] = {"min": lo, "max": hi}

    # ETAPA 5 -------------------------------------------------------------
    def stage5(self):
        self.dlg.title(self.t("stage5_title"))
        self.demo_notice()
        if not self.state.alternatives:
            self.dlg.say(self.t("generating", n=self.state.problem.n_alternatives, seed=self.state.problem.seed))
            GEN.run(self.kb, self.state.problem, self.state)
            info = self.state.derivation_info
            self.dlg.ok(self.t("generated", n=len(self.state.alternatives), dup=info["duplicates"], attempts=info["attempts"]))
            if info["exhausted"]:
                self.dlg.warn(self.t("exhausted"))
            if not info["preferred_available"]:
                self.dlg.warn(self.t("series_unavailable"))
            self.constraint_report()
            self.dlg.say(self.t("svg_folder", path=self.state.session_dir))
            self.dlg.pause()
        self.gallery()

    def constraint_report(self):
        rej = self.state.derivation_info.get("rejections", {})
        if not rej:
            return
        self.dlg.section(self.t("constraint_report"))
        for key, n in sorted(rej.items(), key=lambda kv: -kv[1]):
            if key.startswith("op:"):
                self.dlg.bullet(self.t("rejected_op", reason=key[3:], n=n))
            else:
                g = self.kb.grammar.guards.get(key, {})
                self.dlg.bullet(self.t("rejected_guard", guard=self.guard_name(key), n=n, source=g.get("source", "—")))

    def alt_line(self, a):
        it = self.state.item(a.alternative_id)
        mark = "★" if it.useful else ("✗" if it.discarded else " ")
        sel = "▶" if it.selected else " "
        risk = self.state.risk.get(a.alternative_id)
        rtxt = f" · {self.t('risk_short')} {self.n(risk[0])}" if risk else ""
        return f"{sel}{mark} {a.alternative_id}  " + " → ".join(s.rule_id.replace("r_", "") for s in a.steps) + rtxt

    def gallery(self):
        alts = self.state.alternatives
        if not alts:
            self.dlg.warn(self.t("no_alternatives"))
            self.dlg.option("4", self.t("opt_back_problem"))
            self.dlg.choose(["4"])
            self.state.stage = 4
            return
        while self.state.stage == 5:
            self.dlg.title(self.t("gallery_title"))
            self.demo_notice()
            for a in alts:
                self.dlg.say("  " + self.alt_line(a))
            self.dlg.note(self.t("gallery_legend"))
            self.dlg.say(self.t("contact_sheet", path=self.state.svg_paths.get("_sheet", "—")))
            self.dlg.blank()
            self.dlg.option("1-" + str(len(alts)), self.t("opt_open_alt"))
            self.dlg.option("h", self.t("opt_open_sheet"))
            self.dlg.option("k", self.t("opt_compare"))
            self.dlg.option("r", self.t("opt_regenerate"))
            self.dlg.option("f", self.t("opt_to_stage6"))
            ans = self.dlg.ask("> ").lower()
            if ans.isdigit() and 1 <= int(ans) <= len(alts):
                self.state.index = int(ans) - 1
                self.view_alternative()
            elif ans == "h":
                if not terminal_image.open_with_viewer(self.state.svg_paths.get("_sheet")):
                    self.dlg.say(self.state.svg_paths.get("_sheet"))
            elif ans == "k":
                self.compare()
            elif ans == "r":
                self.state.problem.seed = new_seed()
                self.state.alternatives = []
                self.state.stage = 4
                return
            elif ans == "f":
                if not self.state.selected_ids():
                    self.dlg.warn(self.t("need_selection"))
                    continue
                self.log(5, "dec_selected", ids=", ".join(self.state.selected_ids()))
                self.state.stage = 6
                return
            else:
                self.dlg.warn(self.t("err_invalid_option"))

    def show_indicators_abstract(self, aid):
        vals = self.state.abstract_indicators.get(aid, {})
        for iid, v in vals.items():
            ind = self.kb.indicator(iid)
            name = self.txt(ind["names"]) if ind else iid
            self.dlg.say(f"    {name}: " + (f"{self.raw(v[0])} → q={self.n(v[1], 2)}" if v else self.t("no_data")) + self.badge(ind))
        risk = self.state.risk.get(aid)
        if risk:
            self.dlg.say(f"    {self.txt(self.kb.risk_spec()['names'])}: {self.n(risk[0], 2)}" + self.badge(self.kb.risk_spec()))
        elif not self.kb.risk_spec():
            self.dlg.note("    " + self.t("risk_unavailable"))
        if not self.kb.indicators():
            self.dlg.note("    " + self.t("indicators_unavailable"))

    def view_alternative(self):
        while True:
            alts = self.state.alternatives
            a = alts[self.state.index]
            aid = a.alternative_id
            it = self.state.item(aid)
            self.dlg.title(f"{aid} ({self.state.index + 1}/{len(alts)})")
            self.demo_notice()
            self.dlg.say(preview_ascii.preview(a.shape, unicode_ok=terminal.unicode_enabled()))
            self.dlg.say(f"  {self.t('file_label')}: {self.state.svg_paths.get(aid)}")
            self.dlg.section(self.t("recipe"))
            self.dlg.say(f"  {self.t('initial_shape_label')}: {self.shape_name(a.initial_shape)} · {self.t('f_seed')}: {a.seed}")
            for i, s in enumerate(a.steps, start=1):
                params = ", ".join(f"{k}={self.n(v, 3) if isinstance(v, float) else v}" for k, v in s.params.items())
                snap = "".join(f" [{k}: {self.n(o, 4)}→{self.n(n, 4)} {self.state.problem.preferred_series}]" for k, (o, n) in s.snapped.items())
                self.dlg.say(f"   {i}. {s.rule_id} ({self.rule_name(s.rule_id)}) → {s.target} · {params}{snap}")
            self.dlg.say(f"  {self.t('families_label')}: " + ", ".join(self.family_name(f) for f in a.families(self.kb.grammar)))
            guards_all = {}
            for s in a.steps:
                guards_all.update(s.guards)
            self.dlg.say(f"  {self.t('guards_passed')}: {sum(guards_all.values())}/{len(guards_all)}")
            self.dlg.section(self.t("indicators_level1"))
            self.show_indicators_abstract(aid)
            self.dlg.note("  " + self.t("risk_not_cpk"))
            if it.interpretation:
                self.labelled("student", it.interpretation)
            state = self.t("state_useful") if it.useful else (self.t("state_discarded") if it.discarded else self.t("state_pending"))
            self.labelled("decision", state + (" · " + self.t("state_selected") if it.selected else ""))
            self.dlg.blank()
            opts = [("u", "nav_useful"), ("d", "nav_discard"), ("i", "opt_interpret"), ("q", "opt_questions"),
                    ("v", "opt_variations"), ("j", "opt_adjust"), ("o", "opt_open_svg"), ("e", "opt_select"),
                    ("s", "nav_next"), ("a", "nav_prev"), ("l", "nav_back_gallery")]
            for k, lab in opts:
                self.dlg.option(k, self.t(lab))
            ch = self.dlg.choose([k for k, _ in opts])
            if ch == "u":
                it.useful, it.discarded = True, False
                self.log(5, "dec_alt_useful", aid=aid)
            elif ch == "d":
                it.useful, it.discarded, it.selected = False, True, False
                self.log(5, "dec_alt_discard", aid=aid)
            elif ch == "i":
                it.interpretation = self.dlg.ask_text("ask_interpretation")
            elif ch == "q":
                self.dlg.note(self.t("pedagogical_label"))
                for key in ("pq_base", "pq_joint", "pq_rotate", "pq_user"):
                    self.dlg.bullet(self.t(key))
            elif ch == "v":
                self.make_variations(a)
            elif ch == "j":
                self.adjust(a)
            elif ch == "o":
                if not terminal_image.show_inline(self.state.svg_paths.get(aid, "")):
                    if not terminal_image.open_with_viewer(self.state.svg_paths.get(aid, "")):
                        self.dlg.say(self.state.svg_paths.get(aid))
            elif ch == "e":
                it.selected = not it.selected
                if it.selected:
                    it.discarded = False
            elif ch == "s":
                self.state.index = min(self.state.index + 1, len(alts) - 1)
            elif ch == "a":
                self.state.index = max(self.state.index - 1, 0)
            else:
                return

    def make_variations(self, base):
        seed = INT.new_variation_seed(base.seed, len(self.state.alternatives))
        new = INT.variations(self.kb, self.state.problem, base, seed)
        if not new:
            self.dlg.warn(self.t("no_variations"))
            return
        for v in new:
            self.state.alternatives.append(v)
            self.state.item(v.alternative_id).variation_of = base.alternative_id
        GEN.compute_abstract(self.kb, self.state)
        GEN.write_svgs(self.kb, self.state)
        self.dlg.ok(self.t("variations_added", n=len(new), base=base.alternative_id, seed=seed))
        self.log(5, "dec_variations", aid=base.alternative_id, seed=seed)

    def adjust(self, a):
        numeric = [(i, k, v) for i, s in enumerate(a.steps) for k, v in s.params.items() if isinstance(v, (int, float)) and not isinstance(v, bool)]
        if not numeric:
            self.dlg.warn(self.t("nothing_to_adjust"))
            return
        for n, (i, k, v) in enumerate(numeric, start=1):
            self.dlg.option(str(n), f"{a.steps[i].rule_id}.{k} = {v}")
        sel = numeric[self.dlg.ask_int("ask_number", 1, len(numeric)) - 1]
        val = self.dlg.ask_float("ask_new_value", None, None, param=sel[1])
        if isinstance(sel[2], int):
            val = int(round(val))
        new, failed = INT.adjust_parameter(self.kb, self.state.problem, a, sel[0], sel[1], val)
        if failed:
            self.dlg.warn(self.t("adjust_failed", reason=self.guard_name(failed) if not failed.startswith("op:") else failed))
            return
        self.state.alternatives.append(new)
        self.state.item(new.alternative_id).variation_of = a.alternative_id
        GEN.compute_abstract(self.kb, self.state)
        GEN.write_svgs(self.kb, self.state)
        self.dlg.ok(self.t("adjusted", aid=new.alternative_id))

    def compare(self):
        ids = self.dlg.ask_int_list("ask_two_alts", 1, len(self.state.alternatives), allow_empty=False)
        if len(ids) != 2:
            self.dlg.warn(self.t("need_two"))
            return
        a, b = (self.state.alternatives[i - 1] for i in ids)
        for alt in (a, b):
            self.dlg.section(alt.alternative_id + " — " + " → ".join(s.rule_id for s in alt.steps))
            self.show_indicators_abstract(alt.alternative_id)
        from ..grammar import similarity
        self.dlg.say(self.t("similarity", v=self.n(similarity.similarity(similarity.raster(a.shape), similarity.raster(b.shape)))))
        self.dlg.pause()

    # ETAPA 6 -------------------------------------------------------------
    def stage6(self):
        sel = self.state.selected_ids()
        if not sel:
            self.state.stage = 5
            return
        for aid in sel:
            self.state.evaluated.setdefault(aid, EvaluatedAlternative(aid, mc_seed=self.state.problem.seed))
        idx = max(0, min(self.state.current_eval, len(sel) - 1))
        aid = sel[idx]
        ev = self.state.evaluated[aid]
        a = self.state.alternative(aid)
        self.dlg.title(f"{self.t('stage6_title')} — {aid} ({idx + 1}/{len(sel)})")
        self.demo_notice()
        self.dlg.say(self.t("summary_line", product=self.state.profile.product, process=self.process_name(self.state.profile.process_id),
                            seed=self.state.problem.seed, thr=self.n(ev.threshold)))
        self.dlg.say("  " + self.t("recipe") + ": " + " → ".join(f"{s.rule_id}" for s in a.steps))
        it = self.state.item(aid)
        self.labelled("student", it.interpretation or self.t("no_interpretation"))
        self.dlg.say(f"  {self.t('file_label')}: {self.state.svg_paths.get(aid)}")
        # 3 dimensionamiento
        self.dlg.section("3. " + self.t("sec_dimensioning"))
        if ev.scale_mm:
            m = DIM.scaled_shape_metrics(a.shape, ev.scale_mm)
            self.dlg.say(f"  {self.t('scale_line', ref=self.t('ref_' + ev.scale_reference), v=self.n(ev.scale_value_mm, 1), k=self.n(ev.scale_mm, 2), w=self.n(m['width_mm'], 1), h=self.n(m['height_mm'], 1))}")
            for gid, ok in ev.absolute_guards.items():
                self.dlg.say(f"  {self.guard_name(gid)}: " + (terminal.style(self.t("passed"), "ok") if ok else terminal.style(self.t("failed"), "err")))
        else:
            self.dlg.say("  " + self.t("not_dimensioned"))
        # 4–5 cotas y tolerancias
        self.dlg.section("4–5. " + self.t("sec_ctq"))
        if not ev.ctqs:
            self.dlg.say("  " + self.t("no_ctq"))
        for c in ev.ctqs:
            tol = f"{self.n(c.lower, 3)}/+{self.n(c.upper, 3)}" if (c.lower or c.upper) else self.t("no_tolerance")
            src = self.t("tol_student") if c.tol_source == "student" else (c.tol_source or "—")
            orig = f" ({self.t('original')} {self.n(c.original_nominal, 3)})" if c.original_nominal is not None else ""
            self.dlg.say(f"  {c.ctq_id} {c.name} [{self.t('ft_' + c.feature_type)}] {self.n(c.nominal_mm, 3)} mm{orig} · {self.t('tol')} {tol} ({src}) · "
                         f"{self.process_name(c.process_id)}")
        for ch in ev.chains:
            self.dlg.say(f"  {ch.chain_id} {ch.name}: " + " + ".join(f"{self.n(a_, 0)}·{cid}" for cid, a_ in ch.terms) + f" · {self.t('tol')} {self.n(ch.lower, 3)}/+{self.n(ch.upper, 3)}")
        # 6–8 indicadores, riesgo, Cpk
        vec = EVAL.indicator_vector(self.kb, self.state, aid)
        self.dlg.section("6. " + self.t("sec_indicators"))
        for iid, v in vec.items():
            ind = self.kb.indicator(iid)
            self.dlg.say(f"  {self.txt(ind['names']) if ind else iid}: " + (f"{self.raw(v[0])} → q={self.n(v[1], 2)}" if v else self.t("no_data")) + self.badge(ind))
        if not self.kb.indicators():
            self.dlg.warn(self.t("indicators_unavailable"))
        self.dlg.section("7. " + self.t("sec_risk"))
        risk = self.state.risk.get(aid)
        self.dlg.say("  " + (f"{self.n(risk[0], 2)} — {self.t('risk_not_cpk')}" if risk else self.t("risk_unavailable")))
        self.dlg.section("8. " + self.t("sec_cpk", it=ev.iterations))
        self.show_capability(ev)
        # 9 consumidor
        self.dlg.section("9. " + self.t("sec_consumer"))
        cs = self.state.consumer_summary.get(aid)
        if cs:
            self.dlg.say(f"  n={cs['n_respondents']} · q={self.n(cs['q'], 2) if cs['q'] is not None else '—'}")
            if cs["n_respondents"] < self.kb.scales.get("min_respondents", 30):
                self.dlg.warn(self.t("survey_exploratory", n=cs["n_respondents"], min=self.kb.scales.get("min_respondents", 30)))
        else:
            self.dlg.say("  " + self.t("no_survey"))
        # 12 brechas
        self.dlg.section("12. " + self.t("sec_gaps"))
        gaps = self.gaps(ev)
        for g in gaps:
            self.dlg.bullet(g)
        if not gaps:
            self.dlg.say("  " + self.t("no_gaps"))
        self.labelled("decision", self.t("dec_" + ev.decision) + (f" — {ev.justification}" if ev.justification else ""))
        self.dlg.blank()
        opts = [("d", "opt_dimension"), ("k", "opt_ctq"), ("t", "opt_tolerances"), ("p", "opt_process"), ("c", "opt_compute"),
                ("y", "opt_threshold"), ("o", "opt_improve"), ("w", "opt_integral"), ("e", "opt_survey"),
                ("r", "opt_decide"), ("g", "opt_save_record"), ("x", "opt_export"), ("z", "opt_package"),
                ("l", "opt_learning"), ("s", "nav_next_alt"), ("a", "nav_prev_alt"), ("b", "nav_back_gallery"), ("?", "opt_why")]
        for k, lab in opts:
            self.dlg.option(k, self.t(lab))
        self.dlg.hint_globals()
        ch = self.dlg.choose([k for k, _ in opts])
        getattr(self, "act_" + {"d": "dimension", "k": "ctq", "t": "tolerances", "p": "process", "c": "compute", "y": "threshold",
                                "o": "improve", "w": "integral", "e": "survey", "r": "decide", "g": "save", "x": "export",
                                "z": "package", "l": "learning", "s": "next", "a": "prev", "b": "back", "?": "why"}[ch])(aid, ev)

    def show_capability(self, ev):
        if not ev.results:
            self.dlg.say("  " + self.t("cpk_not_computed"))
        for c in ev.ctqs:
            r = ev.results.get(c.ctq_id)
            if not r:
                if c.sigma_mm:
                    self.dlg.say(f"  {c.ctq_id} {c.name}: " + self.t("sigma_loaded_pending", sigma=self.n(c.sigma_mm, 4), src=c.sigma_source))
                else:
                    self.dlg.say(f"  {c.ctq_id} {c.name}: " + terminal.style(self.t("no_capability"), "warn"))
                continue
            warn = terminal.style(" ⚠", "warn") if r.cpk_estimate < ev.threshold else ""
            self.dlg.say(f"  {c.ctq_id} {c.name}: {self.t('cpk_est')} {self.n(r.cpk_estimate, 2)} · PPM {self.n(r.ppm, 0)} "
                         f"[{self.n(r.ppm_ci95[0], 0)}–{self.n(r.ppm_ci95[1], 0)}] · {self.t('contribution')} {self.n(100 * r.contribution.get(c.ctq_id, 0), 0)} %"
                         f"{warn}")
            self.dlg.note(f"      σ={self.n(c.sigma_mm, 4)} mm ({c.sigma_source}; {self.t('dq_' + (c.data_quality or 'none'))}) · "
                          f"{self.t('analytic')}: Cp={self.n(r.cp_analytic, 2) if r.cp_analytic is not None else '—'}, "
                          f"Cpk={self.n(r.cpk_analytic, 2) if r.cpk_analytic is not None else '—'} · {self.t('dist_' + c.distribution)} · seed {r.seed}")
        for ch in ev.chains:
            r = ev.results.get(ch.chain_id)
            if not r:
                continue
            contrib = ", ".join(f"{cid} {self.n(100 * v, 0)} %" for cid, v in sorted(r.contribution.items(), key=lambda kv: -kv[1]))
            self.dlg.say(f"  {ch.chain_id} {ch.name}: {self.t('cpk_est')} {self.n(r.cpk_estimate, 2)} · PPM {self.n(r.ppm, 0)} · {self.t('contribution')}: {contrib}")
        if ev.results:
            self.dlg.note("  " + self.t("cpk_honest"))
        for lbl, res in ev.previous_results:
            self.dlg.note("  " + self.t("previous_result", label=lbl, values=", ".join(f"{k}={self.n(v.cpk_estimate, 2)}" for k, v in res.items())))

    def gaps(self, ev):
        out = []
        for c in ev.ctqs:
            if c.sigma_mm is None:
                out.append(self.t("gap_sigma", ctq=f"{c.ctq_id} {c.name}"))
            if not (c.lower or c.upper):
                out.append(self.t("gap_tolerance", ctq=f"{c.ctq_id} {c.name}"))
        for s in (self.state.interpretation.standards_without_guards if self.state.interpretation else []):
            out.append(self.t("standard_without_guards", std=s))
        if not self.kb.tolerance_tables:
            out.append(self.t("gap_tolerance_tables"))
        if not self.kb.capability.records:
            out.append(self.t("gap_capability_db"))
        if not self.state.consumer_summary:
            out.append(self.t("gap_survey"))
        if not self.kb.references:
            out.append(self.t("gap_references"))
        return out

    # ---- acciones de la etapa 6
    def act_dimension(self, aid, ev):
        a = self.state.alternative(aid)
        self.dlg.option("1", self.t("ref_overall_width"))
        self.dlg.option("2", self.t("ref_overall_height"))
        ev.scale_reference = "overall_width" if self.dlg.ask_int("ask_number", 1, 2) == 1 else "overall_height"
        ev.scale_value_mm = self.dlg.ask_float("ask_scale_mm", 1, 100000, default=ev.scale_value_mm)
        ev.scale_mm = DIM.scale_factor(a.shape, ev.scale_reference, ev.scale_value_mm)
        cands = DIM.candidate_ctqs(a.shape, ev.scale_mm)
        prof = self.state.profile
        for c in cands:
            c.process_id, c.material_id = prof.process_id, prof.material_id
        # ajuste a números preferidos (C27.2.3)
        if self.kb.preferred.available and cands and self.dlg.yes_no("ask_snap_series", series=self.state.problem.preferred_series):
            for c in cands:
                s = self.kb.preferred.snap(c.nominal_mm, self.state.problem.preferred_series)
                if s is not None and abs(s - c.nominal_mm) > 1e-9:
                    c.original_nominal, c.nominal_mm = c.nominal_mm, s
        elif not self.kb.preferred.available:
            self.dlg.warn(self.t("series_unavailable"))
        ev.ctqs = cands
        ev.results = {}
        # guardas absolutas (C9.6)
        env = G.measure(a.shape, {**self.state.problem.context(), "scale_mm": ev.scale_mm})
        ev.absolute_guards = {}
        for gid in self.state.problem.active_guards:
            g = self.kb.grammar.guards.get(gid)
            if g and g.get("units") == "mm" and self.kb.grammar.visible(g):
                ok, applicable = G.check(g, env)
                if applicable:
                    ev.absolute_guards[gid] = bool(ok)
        self.attach_capability(ev)
        self.log(6, "dec_dimensioned", aid=aid, v=ev.scale_value_mm)
        self.dlg.ok(self.t("ctq_proposed", n=len(cands)))

    def attach_capability(self, ev):
        for c in ev.ctqs:
            rec = self.kb.capability.lookup(c.process_id, c.material_id, c.feature_type, c.nominal_mm)
            if rec:
                c.sigma_mm, c.mean_shift_mm = rec["sigma_mm"], rec.get("mean_shift_mm") or 0.0
                c.distribution, c.data_quality = rec.get("distribution", "normal"), rec.get("data_quality")
                c.capability_id = rec["capability_id"]
                c.sigma_source = ("DEMO · " if self.kb.is_demo else "") + rec["capability_id"]
            else:
                c.sigma_mm, c.sigma_source, c.data_quality, c.capability_id = None, None, None, None

    def act_ctq(self, aid, ev):
        if not ev.scale_mm:
            self.dlg.warn(self.t("dimension_first"))
            return
        self.dlg.option("1", self.t("ctq_remove"))
        self.dlg.option("2", self.t("ctq_add"))
        self.dlg.option("3", self.t("chain_add"))
        self.dlg.option("4", self.t("ctq_rename"))
        k = self.dlg.ask_int("ask_number", 1, 4)
        if k == 1:
            for i, c in enumerate(ev.ctqs, start=1):
                self.dlg.option(str(i), f"{c.ctq_id} {c.name} {self.n(c.nominal_mm, 3)}")
            for idx in sorted(self.dlg.ask_int_list("ask_numbers_multi", 1, len(ev.ctqs)), reverse=True):
                ev.ctqs.pop(idx - 1)
        elif k == 2:
            name = self.dlg.ask_text("ask_ctq_name")
            for i, ft in enumerate(("linear", "diameter", "radius"), start=1):
                self.dlg.option(str(i), self.t("ft_" + ft))
            ft = ("linear", "diameter", "radius")[self.dlg.ask_int("ask_number", 1, 3) - 1]
            nominal = self.dlg.ask_float("ask_nominal", 0.001, 100000)
            cid = f"c{len(ev.ctqs) + 1}"
            while any(c.ctq_id == cid for c in ev.ctqs):
                cid += "b"
            ev.ctqs.append(CAP.CTQ(cid, name, ft, nominal, process_id=self.state.profile.process_id,
                                   material_id=self.state.profile.material_id, origin="student"))
            self.attach_capability(ev)
        elif k == 3:
            for i, c in enumerate(ev.ctqs, start=1):
                self.dlg.option(str(i), f"{c.ctq_id} {c.name}")
            idxs = self.dlg.ask_int_list("ask_chain_members", 1, len(ev.ctqs), allow_empty=False)
            terms = []
            for i in idxs:
                coef = self.dlg.ask_float("ask_coef", -10, 10, default=1, ctq=ev.ctqs[i - 1].ctq_id)
                terms.append((ev.ctqs[i - 1].ctq_id, coef))
            lo = self.dlg.ask_float("ask_lower_dev", -1000, 0)
            hi = self.dlg.ask_float("ask_upper_dev", 0, 1000)
            name = self.dlg.ask_text("ask_chain_name")
            ev.chains.append(CAP.Chain(f"ch{len(ev.chains) + 1}", name, terms, lo, hi))
        else:
            for i, c in enumerate(ev.ctqs, start=1):
                self.dlg.option(str(i), f"{c.ctq_id} {c.name}")
            c = ev.ctqs[self.dlg.ask_int("ask_number", 1, len(ev.ctqs)) - 1]
            c.name = self.dlg.ask_text("ask_ctq_name")
        ev.results = {}
        self.log(6, "dec_ctq_modified", aid=aid)

    def act_tolerances(self, aid, ev):
        if not ev.ctqs:
            self.dlg.warn(self.t("dimension_first"))
            return
        tables = self.kb.tolerance_tables
        if tables:
            for i, t in enumerate(tables, start=1):
                self.dlg.option(str(i), self.txt(t["names"]) + self.badge(t))
        self.dlg.option("0", self.t("tol_manual_option"))
        k = self.dlg.ask_int("ask_number_or_zero", 0, len(tables))
        for c in ev.ctqs:
            if k > 0:
                tol = DIM.tolerance_from_table(tables[k - 1], c.nominal_mm)
                if tol is None:
                    self.dlg.warn(self.t("tol_out_of_table", ctq=c.ctq_id))
                    continue
                c.lower, c.upper = -tol, tol
                c.tol_source = f"table:{tables[k - 1]['table_id']}"
            else:
                c.lower = self.dlg.ask_float("ask_lower_dev_ctq", -1000, 0, default=c.lower or None, ctq=f"{c.ctq_id} {c.name}", nom=self.n(c.nominal_mm, 3))
                c.upper = self.dlg.ask_float("ask_upper_dev_ctq", 0, 1000, default=c.upper or None, ctq=f"{c.ctq_id} {c.name}", nom=self.n(c.nominal_mm, 3))
                c.tol_source = "student"
        if not tables:
            self.dlg.note(self.t("tol_no_tables"))
        ev.results = {}
        self.log(6, "dec_tolerances", aid=aid)

    def act_process(self, aid, ev):
        if not ev.ctqs:
            self.dlg.warn(self.t("dimension_first"))
            return
        self.dlg.option("1", self.t("process_all"))
        self.dlg.option("2", self.t("process_one"))
        k = self.dlg.ask_int("ask_number", 1, 2)
        targets = ev.ctqs
        if k == 2:
            for i, c in enumerate(ev.ctqs, start=1):
                self.dlg.option(str(i), f"{c.ctq_id} {c.name}")
            targets = [ev.ctqs[self.dlg.ask_int("ask_number", 1, len(ev.ctqs)) - 1]]
        pid = self.pick_catalog(self.kb.processes, "process_id")
        mid = self.pick_catalog(self.kb.materials, "material_id")
        if ev.results:
            ev.previous_results.append((f"{self.process_name(targets[0].process_id)}", dict(ev.results)))
        for c in targets:
            c.process_id, c.material_id = pid, mid
        self.attach_capability(ev)
        if any(c.sigma_mm for c in ev.ctqs) and all((c.lower or c.upper) for c in ev.ctqs if c.sigma_mm):
            self.act_compute(aid, ev, quiet=True)
        self.log(6, "dec_process", aid=aid, process=self.process_name(pid))

    def act_compute(self, aid, ev, quiet=False):
        if not ev.ctqs:
            self.dlg.warn(self.t("dimension_first"))
            return
        missing_tol = [c.ctq_id for c in ev.ctqs if not (c.lower or c.upper)]
        if missing_tol:
            self.dlg.warn(self.t("need_tolerances", ids=", ".join(missing_tol)))
            return
        if not quiet:
            ev.iterations = self.dlg.ask_int("ask_iterations", 1000, 2_000_000, default=ev.iterations)
        ev.mc_seed = ev.mc_seed or self.state.problem.seed
        ev.results = CAP.simulate(ev.ctqs, ev.chains, ev.iterations, ev.mc_seed)
        if not ev.results:
            self.dlg.warn(self.t("no_capability_any"))
        self.log(6, "dec_computed", aid=aid, it=ev.iterations)

    def act_threshold(self, aid, ev):
        ev.threshold = self.dlg.ask_float("ask_threshold", 0.5, 3.0, default=ev.threshold)
        self.log(6, "dec_threshold", aid=aid, thr=ev.threshold)

    def act_improve(self, aid, ev):
        low = [c for c in ev.ctqs if ev.results.get(c.ctq_id) and ev.results[c.ctq_id].cpk_estimate < ev.threshold]
        self.dlg.section(self.t("improve_title"))
        if not low:
            self.dlg.say(self.t("no_low_cpk"))
            return
        opts = self.kb.improvement_options() or ["open_tolerance", "change_process", "redesign_joint", "regenerate"]
        self.dlg.note(self.t("pedagogical_label") + (self.badge(self.kb.pedagogical) if self.kb.improvement_options() else ""))
        for i, o in enumerate(opts, start=1):
            self.dlg.option(str(i), self.t("imp_" + o))
        k = self.dlg.ask_int("ask_number", 1, len(opts))
        choice = opts[k - 1]
        if choice == "open_tolerance":
            for i, c in enumerate(low, start=1):
                self.dlg.option(str(i), f"{c.ctq_id} {c.name} Cpk {self.n(ev.results[c.ctq_id].cpk_estimate, 2)}")
            c = low[self.dlg.ask_int("ask_number", 1, len(low)) - 1]
            ev.previous_results.append((f"{c.ctq_id} ±{self.n(c.upper, 3)}", dict(ev.results)))
            c.lower = self.dlg.ask_float("ask_lower_dev_ctq", -1000, 0, default=c.lower, ctq=c.ctq_id, nom=self.n(c.nominal_mm, 3))
            c.upper = self.dlg.ask_float("ask_upper_dev_ctq", 0, 1000, default=c.upper, ctq=c.ctq_id, nom=self.n(c.nominal_mm, 3))
            c.tol_source = "student"
            ev.results = CAP.simulate(ev.ctqs, ev.chains, ev.iterations, ev.mc_seed)
        elif choice == "change_process":
            self.act_process(aid, ev)
        elif choice == "redesign_joint":
            self.dlg.say(self.t("imp_redesign_hint"))
            self.state.stage = 5
            self.state.index = next(i for i, a in enumerate(self.state.alternatives) if a.alternative_id == aid)
        else:
            self.state.stage = 4
            self.state.alternatives = []
        self.log(6, "dec_improve", aid=aid, option=self.t("imp_" + choice))

    def act_integral(self, aid, ev):
        sel = self.state.selected_ids()
        vectors = {a: EVAL.indicator_vector(self.kb, self.state, a) for a in sel}
        ids = [i["indicator_id"] for i in self.kb.indicators()]
        if not ids:
            self.dlg.warn(self.t("indicators_unavailable"))
            return
        self.dlg.section(self.t("integral_title"))
        self.dlg.note(self.t("integral_method"))
        self.dlg.option("1", self.t("weights_direct"))
        self.dlg.option("2", self.t("weights_ahp"))
        self.dlg.option("3", self.t("weights_experts"))
        self.dlg.option("4", self.t("weights_keep"))
        k = self.dlg.ask_int("ask_number", 1, 4, default=4 if self.state.weights else 1)
        if k == 1:
            for iid in ids:
                self.state.weights[iid] = self.dlg.ask_float("ask_indicator_weight", 0, 100, default=self.state.weights.get(iid, 1),
                                                             ind=self.txt(self.kb.indicator(iid)["names"]))
            self.state.weights_method = "direct"
        elif k == 2:
            self.ahp(ids)
        elif k == 3:
            self.experts(ids)
        if not self.state.weights:
            return
        w = mcda.normalize_weights({i: self.state.weights.get(i, 0) for i in ids}) if sum(self.state.weights.get(i, 0) for i in ids) > 0 else {}
        self.dlg.section(self.t("weights_normalized"))
        for iid, wv in w.items():
            self.dlg.say(f"  {self.txt(self.kb.indicator(iid)['names'])}: {self.n(wv, 3)}")
        renorm = None
        for a in sel:
            k_val, missing, kind = EVAL.integral(vectors[a], self.state.weights, renormalize=False)
            if kind == "partial":
                if renorm is None:
                    renorm = self.dlg.yes_no("ask_renormalize", default=False)
                k_val, missing, kind = EVAL.integral(vectors[a], self.state.weights, renormalize=renorm)
                self.dlg.say(f"  {a}: K {self.t('partial')} = {self.n(k_val, 3) if k_val is not None else '—'} "
                             f"({self.t('missing')}: {', '.join(missing)}; {self.t('renormalized') if renorm else self.t('not_renormalized')})")
            else:
                self.dlg.say(f"  {a}: K = {self.n(k_val, 3) if k_val is not None else '—'}")
        rs = EVAL.ranking_and_sensitivity(vectors, self.state.weights, 0.2)
        if rs:
            self.dlg.section(self.t("arithmetic"))
            for a, rows in rs["steps"].items():
                self.dlg.say(f"  {a}: " + " + ".join(f"{self.n(wv, 3)}×{self.n(q, 3)}" for _cid, _raw, q, wv, _part in rows) + f" = {self.n(rs['totals'][a], 3)}")
            self.dlg.section(self.t("ranking"))
            for i, a in enumerate(rs["ranking"], start=1):
                self.dlg.say(f"  {i}. {a} — {self.n(rs['totals'][a], 3)}")
            self.dlg.say(terminal.style(self.t("ranking_stable"), "ok") if rs["sensitivity"]["stable"] else terminal.style(self.t("ranking_fragile"), "warn"))
            self.dlg.note(self.t("ranking_criteria_note", ids=", ".join(rs["criteria"])))
        else:
            self.dlg.warn(self.t("ranking_unavailable"))
        if len(sel) >= 2 and self.dlg.yes_no("ask_pareto", default=False):
            for i, iid in enumerate(ids, start=1):
                self.dlg.option(str(i), self.txt(self.kb.indicator(iid)["names"]))
            nums = self.dlg.ask_int_list("ask_pareto_indicators", 1, len(ids), allow_empty=False)
            chosen = [ids[n - 1] for n in nums[:3]]
            front, considered = EVAL.pareto(vectors, chosen)
            self.dlg.say(self.t("pareto_result", front=", ".join(front) or "—", considered=", ".join(considered) or "—"))
        self.dlg.note(self.t("not_the_correct"))
        self.log(6, "dec_weights", method=self.state.weights_method)
        self.dlg.pause()

    def ahp(self, ids):
        n = len(ids)
        names = [self.txt(self.kb.indicator(i)["names"]) for i in ids]
        m = [[1.0] * n for _ in range(n)]
        self.dlg.note(self.t("ahp_help"))
        for i in range(n):
            for j in range(i + 1, n):
                v = self.dlg.ask_float("ask_ahp_pair", 1 / 9, 9, default=1, a=names[i], b=names[j])
                m[i][j], m[j][i] = v, 1 / v
        w, lam, ci = mcda.ahp_weights(m)
        cr = mcda.ahp_consistency_ratio(ci, n, self.kb.ahp_random_index())
        self.state.weights = {ids[k]: w[k] for k in range(n)}
        self.state.weights_method = "ahp"
        self.dlg.say(self.t("ahp_result", lam=self.n(lam, 3), ci=self.n(ci, 3), cr=self.n(cr, 3) if cr is not None else "—"))
        if cr is None:
            self.dlg.warn(self.t("ahp_no_ri"))
        elif cr > self.kb.ahp.get("cr_threshold", 0.1):
            self.dlg.warn(self.t("ahp_inconsistent", thr=self.n(self.kb.ahp.get("cr_threshold", 0.1), 2)))
        self.state.expert_panel = {"method": "ahp", "matrix": m, "lambda_max": lam, "ci": ci, "cr": cr,
                                   "ri_source": self.kb.ahp.get("source")}

    def experts(self, ids):
        self.dlg.note(self.t("experts_help", ids=", ".join(ids)))
        path = os.path.expanduser(self.dlg.ask_text("ask_path"))
        import csv
        try:
            ranks = {}
            with open(path, encoding="utf-8-sig", newline="") as fh:
                for row in csv.DictReader(fh):
                    ranks.setdefault(row["expert"], {})[row["indicator_id"]] = float(row["rank"])
            rankings = [[r[i] for i in ids] for r in ranks.values()]
            W, chi2, df, p = mcda.kendall_w(rankings)
        except (OSError, KeyError, ValueError) as exc:
            self.dlg.warn(self.t("experts_error", error=str(exc)))
            return
        w = mcda.weights_from_mean_ranks(rankings)
        self.state.weights = {ids[k]: w[k] for k in range(len(ids))}
        self.state.weights_method = "experts"
        self.state.expert_panel = {"method": "experts", "m": len(rankings), "kendall_w": W, "chi2": chi2, "df": df, "p_value": p}
        self.dlg.say(self.t("kendall_result", m=len(rankings), w=self.n(W, 3), chi2=self.n(chi2, 2), df=df, p=self.n(p, 4)))

    def act_survey(self, aid, ev):
        scales = self.kb.scales_visible()
        if not scales:
            self.dlg.warn(self.t("scales_unavailable"))
            return
        rng = tuple(self.kb.scales.get("scale", [1, 7]))
        self.dlg.option("1", self.t("survey_template"))
        self.dlg.option("2", self.t("survey_target"))
        self.dlg.option("3", self.t("survey_import"))
        k = self.dlg.ask_int("ask_number", 1, 3)
        sel = self.state.selected_ids()
        if k == 1:
            path = CONS.write_template(os.path.join(self.state.session_dir, "survey_template.csv"), sel, scales, self.lang, rng)
            self.dlg.ok(self.t("saved_to", path=path))
            self.dlg.note(self.t("survey_note"))
        elif k == 2:
            for s in scales:
                self.state.survey_target[s["scale_id"]] = self.dlg.ask_float("ask_target", rng[0], rng[1], default=self.state.survey_target.get(s["scale_id"]),
                                                                             left=self.txt(s["left"]), right=self.txt(s["right"]))
        else:
            if not self.state.survey_target:
                self.dlg.warn(self.t("survey_need_target"))
                return
            path = os.path.expanduser(self.dlg.ask_text("ask_path"))
            try:
                rows = CONS.read_responses(path, {s["scale_id"] for s in scales}, set(sel), rng)
            except (OSError, CONS.SurveyError, KeyError) as exc:
                self.dlg.warn(self.t("survey_error", error=str(exc)))
                return
            self.state.survey_rows = rows
            self.state.consumer_summary = CONS.summarize(rows, self.state.survey_target, rng)
            self.dlg.ok(self.t("survey_loaded", n=len(rows)))
            self.log(6, "dec_survey", n=len(rows))

    def act_decide(self, aid, ev):
        self.dlg.option("1", self.t("dec_adopt"))
        self.dlg.option("2", self.t("dec_discard"))
        self.dlg.option("3", self.t("dec_pending"))
        ev.decision = ("adopt", "discard", "pending")[self.dlg.ask_int("ask_number", 1, 3) - 1]
        ev.justification = self.dlg.ask_text("ask_justification")
        self.log(6, "dec_alt_decision", aid=aid, decision=self.t("dec_" + ev.decision))

    def summary_lines(self):
        s = self.state
        out = [self.t("label_student") + ":", "  " + s.idea, "  " + (s.form_goal or "")]
        out.append(self.t("label_system") + ":")
        out.append(f"  {self.t('f_seed')}: {s.problem.seed} · {self.t('generated_short', n=len(s.alternatives))}")
        for aid, ev in s.evaluated.items():
            cpks = [r.cpk_estimate for r in ev.results.values() if r.kind == "ctq"]
            out.append(f"  {aid}: {self.t('cpk_est')} min {self.n(min(cpks), 2) if cpks else '—'} · {self.t('dec_' + ev.decision)}")
        out.append(self.t("label_decision") + ":")
        for st, key, kw in s.decisions:
            out.append(f"  ({self.t('stage')} {st}) {self.decision_text(key, kw)}")
        return out

    def record(self):
        return REC.build_record(self.kb, self.state, self.session.project_id, self.lang, self.decision_text)

    def act_save(self, aid, ev):
        rec = self.record()
        lines = [terminal.strip_ansi(x) for x in self.summary_lines()]
        if self.kb.is_demo:
            lines.insert(0, self.t("demo_notice"))
        jp, tp = REC.save(rec, self.state, lines)
        self.dlg.ok(self.t("saved_to", path=tp))
        self.dlg.ok(self.t("saved_to", path=jp))

    def act_export(self, aid, ev):
        self.dlg.ok(self.t("exported_to", path=REC.export(self.record(), self.lang)))

    def act_package(self, aid, ev):
        self.act_save(aid, ev)
        self.dlg.ok(self.t("package_ready", path=REC.package(self.state, None)))

    def act_learning(self, aid, ev):
        spec = self.kb.learning_spec()
        if not spec:
            self.dlg.warn(self.t("learning_unavailable"))
            return
        evaluated = []
        for a_id, e in self.state.evaluated.items():
            cpks = [r.cpk_estimate for r in e.results.values() if r.kind == "ctq"]
            evaluated.append({"rules": [s.rule_id for s in self.state.alternative(a_id).steps], "adopted": e.decision == "adopt",
                              "min_cpk": min(cpks) if cpks else None})
        prop = LEARN.propose(self.state.problem.rule_weights, evaluated, ev.threshold, spec)
        if not prop:
            self.dlg.say(self.t("learning_nothing"))
            return
        self.dlg.section(self.t("learning_title"))
        for r, ch in prop.items():
            self.dlg.bullet(f"{r}: {self.n(ch['from'], 2)} → {self.n(ch['to'], 2)} (+{ch['up']} / −{ch['down']})")
        if self.dlg.yes_no("ask_apply_learning", default=False):
            who = self.dlg.ask_text("ask_approved_by")
            LEARN.apply(prop, LEARN_FILE, who)
            for r, ch in prop.items():
                self.state.problem.rule_weights[r] = ch["to"]
            self.dlg.ok(self.t("learning_applied"))
            self.log(6, "dec_learning", who=who)

    def act_next(self, aid, ev):
        self.state.current_eval = min(self.state.current_eval + 1, len(self.state.selected_ids()) - 1)

    def act_prev(self, aid, ev):
        self.state.current_eval = max(self.state.current_eval - 1, 0)

    def act_back(self, aid, ev):
        self.state.stage = 5

    def act_why(self, aid, ev):
        self.dlg.section(self.t("why_title"))
        for key in ("why_rules", "why_guards", "why_indicators", "why_cpk", "why_contribution", "why_ranking"):
            self.dlg.bullet(self.t(key))
        self.dlg.pause()
