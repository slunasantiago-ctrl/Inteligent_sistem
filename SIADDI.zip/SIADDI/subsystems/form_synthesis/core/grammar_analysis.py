"""Etapa 3: familias de reglas, forma inicial y guardas aplicables (C7, C28, C29)."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class GrammarInterpretation:
    families: dict = field(default_factory=dict)           # family_id -> [vías]
    principles_without_family: list = field(default_factory=list)
    initial_shape_id: str = None
    shape_reason: list = field(default_factory=list)
    guards: dict = field(default_factory=dict)             # guard_id -> motivo
    standards_without_guards: list = field(default_factory=list)
    concepts: dict = field(default_factory=dict)
    confidence: float = 0.0
    alternatives_shapes: list = field(default_factory=list)

    @property
    def level(self):
        c = self.confidence
        return "high" if c >= 0.7 else ("medium" if c >= 0.5 else "low")


def analyze(kb, text: str, profile, triz=None, quality=None, manual_families=()):
    g = kb.grammar
    res = GrammarInterpretation()
    # 1. familias por TRIZ (C28)
    principles = (triz or {}).get("principles") or []
    if principles:
        fam, without = g.families_for_principles(principles)
        for fid, pids in fam.items():
            res.families.setdefault(fid, []).extend(f"triz:{p}" for p in pids)
        res.principles_without_family = without
    # 2. familias por conceptos del texto
    for n, concept, words in kb.match(kb.concepts.get("concepts", []), text):
        res.concepts[concept["concept_id"]] = words
        for fid in concept.get("families", []):
            if fid in g.visible_families():
                res.families.setdefault(fid, []).append(f"concept:{concept['concept_id']}")
    # 3. declaradas por el estudiante
    for fid in manual_families:
        res.families.setdefault(fid, []).append("student")
    # forma inicial
    shapes = g.visible_shapes()
    ranked = kb.match(list(shapes.values()), text)
    if ranked:
        res.initial_shape_id = ranked[0][1]["shape_id"]
        res.shape_reason = ranked[0][2]
        res.alternatives_shapes = [r[1]["shape_id"] for r in ranked[1:]]
    else:
        default = [s["shape_id"] for s in shapes.values() if s.get("default")] or list(shapes)
        res.initial_shape_id = default[0] if default else None
        res.alternatives_shapes = [s for s in shapes if s != res.initial_shape_id]
    # guardas (C29)
    imported = {(s.get("standard_id"), str(s.get("edition"))) for s in (quality or {}).get("standards", [])}
    imported_ids = {s.get("standard_id") for s in (quality or {}).get("standards", [])}
    covered = set()
    for gid, gd in g.visible_guards().items():
        t = gd.get("type")
        if t == "geometric":
            res.guards[gid] = "geometric"
        elif t == "process":
            procs = gd.get("process_ids")
            if not procs or (profile.process_id in procs):
                res.guards[gid] = f"process:{profile.process_id or '*'}"
        elif t == "normative":
            key = (gd.get("standard_id"), str(gd.get("edition")))
            if key in imported:
                res.guards[gid] = f"standard:{gd.get('standard_id')}"
                covered.add(gd.get("standard_id"))
        # las guardas del estudiante se activan al declarar el límite (etapa 4)
    res.standards_without_guards = sorted(imported_ids - covered)
    n_fam = len(res.families)
    support = sum(len(v) for v in res.families.values())
    res.confidence = round(min(0.95, 0.3 + 0.1 * support + (0.2 if principles else 0.0) + (0.1 if ranked else 0.0)), 2) if n_fam else 0.0
    return res


def rules_for_families(kb, families):
    out = []
    for fid in families:
        out += [r["rule_id"] for r in kb.grammar.rules_of_family(fid)]
    return sorted(set(out))
