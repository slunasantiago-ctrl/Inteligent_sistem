"""Registro de la decisión y paquete académico (C27.7, C35)."""
from __future__ import annotations

import datetime as dt
import os
import zipfile

from isppr_platform import exchange
from isppr_platform.datastore import save_json

SUBSYSTEM_ORIGIN = "standardization"   # identificador vigente de la opción [3] (P4, P7.1)
SUBSYSTEM_VERSION = "1.0"


def build_record(kb, state, project_id, lang, text_of_decision):
    alts = []
    for a in state.alternatives:
        it = state.item(a.alternative_id)
        ev = state.evaluated.get(a.alternative_id)
        entry = {"alternative_id": a.alternative_id, "recipe": a.recipe(), "families": a.families(kb.grammar),
                 "useful": it.useful, "discarded": it.discarded, "selected": it.selected,
                 "student_interpretation": it.interpretation, "variation_of": it.variation_of,
                 "abstract_indicators": state.abstract_indicators.get(a.alternative_id),
                 "risk_index_level1": state.risk.get(a.alternative_id), "svg": state.svg_paths.get(a.alternative_id)}
        if ev:
            entry.update({
                "scale": {"reference": ev.scale_reference, "value_mm": ev.scale_value_mm, "mm_per_unit": ev.scale_mm},
                "ctq": [c.to_dict() for c in ev.ctqs], "chains": [c.to_dict() for c in ev.chains],
                "threshold": ev.threshold, "iterations": ev.iterations, "mc_seed": ev.mc_seed,
                "capability": {k: r.to_dict() for k, r in ev.results.items()},
                "previous_capability": [{"label": lbl, "results": {k: r.to_dict() for k, r in res.items()}} for lbl, res in ev.previous_results],
                "indicators": ev.indicators, "absolute_guards": ev.absolute_guards,
                "decision": {"status": ev.decision, "justification": ev.justification}})
        alts.append(entry)
    adopted = []
    for aid, ev in state.evaluated.items():
        if ev.decision == "adopt":
            cpks = [r.cpk_estimate for r in ev.results.values() if r.kind == "ctq"]
            adopted.append({"alternative_id": aid, "min_cpk_estimate": round(min(cpks), 3) if cpks else None,
                            "rules": [s.rule_id for s in state.alternative(aid).steps]})
    return {
        "project_id": project_id, "subsystem_version": SUBSYSTEM_VERSION, "date": dt.date.today().isoformat(),
        "language": lang, "demo": kb.is_demo, "data_mode": kb.mode.name,
        "idea": state.idea, "profile": state.profile.to_dict(), "form_goal": state.form_goal,
        "form_constraints": state.form_constraints,
        "imported": {"siaddi": state.triz, "siadec": state.quality},
        "synthesis_problem": state.problem.to_dict(),
        "derivation": state.derivation_info,
        "alternatives": alts, "adopted_alternatives": adopted,
        "weights": state.weights, "weights_method": state.weights_method, "expert_panel": state.expert_panel,
        "survey": {"target": state.survey_target, "summary": state.consumer_summary, "n_rows": len(state.survey_rows)},
        "decisions": [{"stage": st, "key": k, "params": kw, "text": text_of_decision(k, kw)} for st, k, kw in state.decisions],
        "sources": sorted({x for x in [kb.preferred_meta.get("source")] + [r.get("source") for r in kb.capability.records]
                           + [t.get("source") for t in kb.tolerance_tables] if x}),
    }


def save(record, state, text_lines):
    os.makedirs(state.session_dir, exist_ok=True)
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    jp = os.path.join(state.session_dir, f"siadef_record_{stamp}.json")
    tp = os.path.join(state.session_dir, f"siadef_record_{stamp}.txt")
    save_json(jp, record)
    with open(tp, "w", encoding="utf-8") as fh:
        fh.write("\n".join(text_lines) + "\n")
    return jp, tp


def package(state, record_paths):
    """Paquete académico: registro, recetas, SVG, entradas de simulación y fuentes (C35)."""
    base = state.session_dir.rstrip(os.sep)
    zpath = base + ".zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for name in sorted(os.listdir(base)):
            z.write(os.path.join(base, name), arcname=os.path.join(os.path.basename(base), name))
    return zpath


def export(record, lang):
    return exchange.write_envelope(SUBSYSTEM_ORIGIN, lang, record)
