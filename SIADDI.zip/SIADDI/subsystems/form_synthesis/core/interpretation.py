"""Etapa 6 (parte del estudiante): interpretación, variaciones y ajuste de alternativas (C11.2, C11.3)."""
from __future__ import annotations

import copy
import random

from ..grammar.derivation import Alternative, apply_step, check_guards, derive
from ..grammar.operations import OperationError


def variations(kb, problem, base_alt, seed, n=4):
    """Nuevas derivaciones a partir de una alternativa, con otra semilla; la receta original se conserva."""
    p = copy.deepcopy(problem)
    p.seed = seed
    p.student_shape = base_alt.shape.to_dict()
    p.n_alternatives = n
    p.min_depth, p.max_depth = 1, 2
    res = derive(kb.grammar, p, kb.preferred.snapper(problem.preferred_series))
    out = []
    for i, a in enumerate(res.alternatives, start=1):
        a.alternative_id = f"{base_alt.alternative_id}v{i}"
        a.steps = list(base_alt.steps) + a.steps
        a.initial_shape = base_alt.initial_shape
        out.append(a)
    return out


def adjust_parameter(kb, problem, alt, step_index, param, value):
    """Cambia un parámetro de la receta y reconstruye con nueva comprobación de guardas (C11.2)."""
    steps = [copy.deepcopy(s) for s in alt.steps]
    steps[step_index].params[param] = value
    if alt.initial_shape and alt.initial_shape in kb.grammar.initial_shapes:
        shape = kb.grammar.shape(alt.initial_shape)
    else:
        shape = problem.initial_shape(kb.grammar)
    guard_ids = list(dict.fromkeys(["g_no_self_intersection"] + list(problem.active_guards)))
    for s in steps:
        rule = kb.grammar.rules[s.rule_id]
        try:
            shape = apply_step(shape, rule, s.target, {**s.params, "_op": rule["operation"]})
        except OperationError as exc:
            return None, f"op:{exc}"
        res, failed = check_guards(guard_ids + rule.get("guards_post", []), kb.grammar, shape, problem.context(),
                                   {**s.params, "_op": rule["operation"]})
        if failed:
            return None, failed
        s.guards = res
    return Alternative(alt.alternative_id + "'", shape, steps, alt.seed, alt.index, alt.initial_shape), None


def new_variation_seed(base_seed: int, k: int) -> int:
    return random.Random(base_seed * 7919 + k).randint(1000, 99999)
