"""Etapa 5: orquesta la derivación, los indicadores abstractos y la salida SVG (C10, C11, C30, C31.2, C35)."""
from __future__ import annotations

import datetime as dt
import os

from ..grammar.derivation import derive
from ..quality import indicators as IND
from ..render import svg

OUTPUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "output")


def session_dir(demo: bool) -> str:
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    return os.path.join(OUTPUT, "demo" if demo else "sessions", f"sesion_{stamp}")


def run(kb, problem, state):
    snap = kb.preferred.snapper(problem.preferred_series)
    result = derive(kb.grammar, problem, snap)
    state.alternatives = result.alternatives
    state.derivation_info = {"rejections": dict(result.rejections), "duplicates": result.duplicates,
                             "attempts": result.attempts, "exhausted": result.exhausted,
                             "preferred_available": kb.preferred.available}
    state.gallery = {}
    state.abstract_indicators = {}
    state.risk = {}
    state.evaluated = {}
    state.session_dir = state.session_dir or session_dir(kb.is_demo)
    compute_abstract(kb, state)
    write_svgs(kb, state)
    return result


def compute_abstract(kb, state):
    ind_ids = {i["indicator_id"]: i for i in kb.indicators()}
    spec = kb.risk_spec()
    for a in state.alternatives:
        vals = {}
        guard_results = {}
        for st in a.steps:
            guard_results.update(st.guards)
        if "ind_conformity" in ind_ids:
            vals["ind_conformity"] = IND.conformity(guard_results)
        if "ind_complexity" in ind_ids:
            vals["ind_complexity"] = IND.complexity(a.shape, ind_ids["ind_complexity"]["coefficients"])
        if "ind_novelty" in ind_ids:
            vals["ind_novelty"] = IND.novelty(a.shape, kb.references)
        state.abstract_indicators[a.alternative_id] = vals
        if spec:
            state.risk[a.alternative_id] = IND.risk_index(a.shape, spec)


def write_svgs(kb, state, highlight=None):
    highlight = highlight or {}
    paths = {}
    for a in state.alternatives:
        legend = [f"{a.alternative_id} · seed {a.seed} · " + " → ".join(s.rule_id for s in a.steps)]
        if kb.is_demo:
            legend.append("DEMO")
        p = os.path.join(state.session_dir, f"{a.alternative_id}.svg")
        svg.write_alternative(p, a.alternative_id, a.shape, legend, highlight.get(a.alternative_id, ()))
        paths[a.alternative_id] = p
    sheet = os.path.join(state.session_dir, "contact_sheet.svg")
    svg.write_contact_sheet(sheet, [(a.alternative_id, a.shape, "") for a in state.alternatives], title=f"seed {state.problem.seed}")
    paths["_sheet"] = sheet
    state.svg_paths = paths
    return paths
