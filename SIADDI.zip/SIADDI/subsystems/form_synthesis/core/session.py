"""Estado propio del subsistema 3 (C26.1): se conserva al ir y volver al menú y al cambiar de idioma."""
from __future__ import annotations

from dataclasses import dataclass, field

from .manufacturing_profile import ManufacturingProfile
from .synthesis_problem import SynthesisProblem


@dataclass
class GalleryItem:
    useful: bool = False
    discarded: bool = False
    interpretation: str = ""
    variation_of: str = None
    selected: bool = False


@dataclass
class EvaluatedAlternative:
    alternative_id: str
    scale_reference: str = "overall_width"
    scale_value_mm: float = None
    scale_mm: float = None
    ctqs: list = field(default_factory=list)
    chains: list = field(default_factory=list)
    threshold: float = 1.33
    iterations: int = 100_000
    mc_seed: int = None
    results: dict = field(default_factory=dict)
    previous_results: list = field(default_factory=list)   # [(etiqueta, resultados)] para comparar (C27.5)
    indicators: dict = field(default_factory=dict)         # indicator_id -> (bruto, q)
    absolute_guards: dict = field(default_factory=dict)
    decision: str = "pending"                              # adopt | discard | pending
    justification: str = ""


@dataclass
class FormState:
    stage: int = 1
    idea: str = ""
    profile: ManufacturingProfile = field(default_factory=ManufacturingProfile)
    form_goal: str = ""
    form_constraints: str = ""
    triz: dict = None
    quality: dict = None
    manual_families: list = field(default_factory=list)
    interpretation: object = None
    problem: SynthesisProblem = field(default_factory=SynthesisProblem)
    alternatives: list = field(default_factory=list)
    derivation_info: dict = field(default_factory=dict)
    abstract_indicators: dict = field(default_factory=dict)   # alt -> {ind: (raw, q)}
    risk: dict = field(default_factory=dict)                  # alt -> (valor, factores)
    gallery: dict = field(default_factory=dict)               # alt -> GalleryItem
    evaluated: dict = field(default_factory=dict)             # alt -> EvaluatedAlternative
    weights: dict = field(default_factory=dict)
    weights_method: str = "direct"
    expert_panel: dict = None
    survey_rows: list = field(default_factory=list)
    survey_target: dict = field(default_factory=dict)
    consumer_summary: dict = field(default_factory=dict)
    decisions: list = field(default_factory=list)              # [etapa, clave, parámetros]
    session_dir: str = None
    index: int = 0
    current_eval: int = 0
    svg_paths: dict = field(default_factory=dict)

    def item(self, aid) -> GalleryItem:
        if aid not in self.gallery:
            self.gallery[aid] = GalleryItem()
        return self.gallery[aid]

    def alternative(self, aid):
        for a in self.alternatives:
            if a.alternative_id == aid:
                return a
        return None

    def selected_ids(self):
        return [a.alternative_id for a in self.alternatives if self.item(a.alternative_id).selected]
