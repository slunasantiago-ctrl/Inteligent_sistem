"""Perfil de fabricación declarado o confirmado por el estudiante (C7 etapa 1, C8).

SIADEF no supone material ni proceso: si el estudiante no los conoce quedan «no definido».
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field


@dataclass
class ManufacturingProfile:
    product: str = ""
    function: str = ""
    user_context: str = ""
    material_id: str = None
    process_id: str = None
    proposed_by_system: list = field(default_factory=list)

    def to_dict(self):
        return asdict(self)


def extract(kb, text: str) -> ManufacturingProfile:
    prof = ManufacturingProfile(product=" ".join(text.split()[:12]), function=text)
    procs = kb.match(list(kb.processes.values()), text)
    if procs:
        prof.process_id = procs[0][1]["process_id"]
        prof.proposed_by_system.append("process_id")
    mats = kb.match(list(kb.materials.values()), text)
    if mats:
        prof.material_id = mats[0][1]["material_id"]
        prof.proposed_by_system.append("material_id")
    return prof
