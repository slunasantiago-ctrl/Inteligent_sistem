"""Etapa 6: de unidades abstractas a mm, cotas críticas candidatas y tolerancias (C27.2 puntos 3–5)."""
from __future__ import annotations

from ..grammar import geometry as geo
from ..quality.capability import CTQ


def scale_factor(shape, reference: str, value_mm: float) -> float:
    x0, y0, x1, y1 = shape.bbox()
    size = (x1 - x0) if reference == "overall_width" else (y1 - y0)
    if size <= 0:
        raise ValueError("degenerate_shape")
    return value_mm / size


def candidate_ctqs(shape, scale_mm: float):
    """Cotas candidatas por etiquetas: diámetros de ejes, longitudes de segmentos, agujeros y encajes."""
    out = []
    n = 0
    for e in shape.elements:
        frame = geo.principal_frame(e.points)
        length, width, _b = geo.extent_along(e.points, frame)
        if "joint" in e.labels:
            n += 1
            r = e.attrs.get("radius") or width / 2
            out.append(CTQ(f"c{n}", f"axis_{e.eid}", "diameter", round(2 * r * scale_mm, 3)))
        if "segment" in e.labels:
            n += 1
            out.append(CTQ(f"c{n}", f"segment_{e.eid}", "linear", round(length * scale_mm, 3)))
        if e.holes:
            n += 1
            hb = geo.bbox(e.holes[0])
            out.append(CTQ(f"c{n}", f"hole_{e.eid}", "diameter", round((hb[2] - hb[0]) * scale_mm, 3)))
        if "nested" in e.labels:
            n += 1
            out.append(CTQ(f"c{n}", f"insert_{e.eid}", "linear", round(length * scale_mm, 3)))
        if "shell" in e.labels and e.attrs.get("wall"):
            n += 1
            out.append(CTQ(f"c{n}", f"wall_{e.eid}", "linear", round(e.attrs["wall"] * scale_mm, 3)))
    return out


def tolerance_from_table(table: dict, nominal: float):
    for lo, hi, tol in table.get("ranges", []):
        if lo < nominal <= hi or (lo == 0 and nominal == 0):
            return tol
    return None


def scaled_shape_metrics(shape, scale_mm):
    x0, y0, x1, y1 = shape.bbox()
    return {"width_mm": (x1 - x0) * scale_mm, "height_mm": (y1 - y0) * scale_mm}
