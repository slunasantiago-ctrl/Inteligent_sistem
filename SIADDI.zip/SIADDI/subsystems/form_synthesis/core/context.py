"""Etapas 1 y 2: idea, perfil de fabricación y requisitos de forma (C7)."""
from __future__ import annotations

from .manufacturing_profile import extract


def build_profile(kb, idea_text):
    return extract(kb, idea_text)


def requirements_text(state, lang):
    """Texto combinado sobre el que se interpreta la gramática: idea + objetivo + lo importado."""
    parts = [state.idea, state.form_goal, state.form_constraints]
    if state.triz:
        parts += [state.triz.get("project") or "", state.triz.get("problem") or ""]
    return " ".join(p for p in parts if p)
