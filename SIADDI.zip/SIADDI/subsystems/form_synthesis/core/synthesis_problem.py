"""Problema de síntesis = gramática configurada (C8, etapa 4)."""
from __future__ import annotations

import random
from dataclasses import asdict, dataclass, field

from ..grammar.vocabulary import Shape


def new_seed() -> int:
    return random.SystemRandom().randint(1000, 99999)


@dataclass
class SynthesisProblem:
    objective: str = ""
    initial_shape_id: str = None
    student_shape: dict = None              # forma inicial dibujada por el estudiante (C9.7)
    active_families: dict = field(default_factory=dict)   # family_id -> vía ("triz:1", "concept:...", "student")
    active_rules: list = field(default_factory=list)
    rule_weights: dict = field(default_factory=dict)
    param_overrides: dict = field(default_factory=dict)   # rule_id -> {param: {min, max}}
    active_guards: list = field(default_factory=list)
    min_depth: int = 2
    max_depth: int = 4
    n_alternatives: int = 12
    seed: int = field(default_factory=new_seed)
    duplicate_threshold: float = 0.95
    wall_thickness: float = 0.02
    max_height: float = None
    max_width: float = None
    preferred_series: str = "R10"
    confirmed: bool = False

    def context(self) -> dict:
        ctx = {"wall_thickness": self.wall_thickness}
        if self.max_height:
            ctx["max_height"] = self.max_height
        if self.max_width:
            ctx["max_width"] = self.max_width
        return ctx

    def initial_shape(self, grammar) -> Shape:
        if self.student_shape:
            return Shape.from_dict(self.student_shape)
        return grammar.shape(self.initial_shape_id)

    def to_dict(self):
        return asdict(self)
