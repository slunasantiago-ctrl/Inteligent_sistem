"""Índice integral, frente de Pareto y sensibilidad sobre la calidad de la forma (C30.4).

Usa el método común declarado en isppr_platform.mcda. Los q ya están orientados (1 = mejor).
"""
from __future__ import annotations

from isppr_platform import mcda

from ..quality import capability as CAP
from ..quality import indicators as IND


def indicator_vector(kb, state, aid):
    """Vector completo de indicadores (abstractos + dimensionados + consumidor) para una alternativa."""
    vals = dict(state.abstract_indicators.get(aid, {}))
    ev = state.evaluated.get(aid)
    ind = {i["indicator_id"]: i for i in kb.indicators()}
    alt = state.alternative(aid)
    if ev and ev.ctqs:
        if "ind_unification" in ind:
            vals["ind_unification"] = IND.unification(ev.ctqs, alt.shape, kb.preferred, state.problem.preferred_series)
        if "ind_reproducibility" in ind:
            vals["ind_reproducibility"] = IND.reproducibility(ev.results, ev.ctqs, ev.threshold)
        if "ind_robustness" in ind:
            frac = CAP.robust_fraction(ev.ctqs, ev.threshold, ind["ind_robustness"].get("sigma_increase", 0.2))
            vals["ind_robustness"] = (round(frac, 4), round(frac, 4)) if frac is not None else None
    if "ind_consumer" in ind:
        summ = state.consumer_summary.get(aid)
        vals["ind_consumer"] = (summ["q"], summ["q"]) if summ and summ.get("q") is not None else None
    for k in list(ind):
        vals.setdefault(k, None)
    if ev:
        ev.indicators = vals
    return vals


def q_values(vec):
    return {k: (v[1] if v else None) for k, v in vec.items()}


def integral(vec, weights, renormalize=False):
    q = q_values(vec)
    w = {k: weights.get(k, 0) for k in q if weights.get(k, 0) > 0}
    if not w:
        return None, list(q), None
    k_full, missing = mcda.weighted_index(q, w)
    if missing:
        return mcda.partial_index(q, w, renormalize), missing, "partial"
    return k_full, [], "full"


def ranking_and_sensitivity(vectors, weights, margin=0.2):
    """vectors: {aid: vec}. Solo usa indicadores con peso y valor en todas las alternativas."""
    ids = [k for k, w in weights.items() if w > 0 and all(vectors[a].get(k) for a in vectors)]
    if not ids or not vectors:
        return None
    criteria = {k: "max" for k in ids}
    scores = {a: {k: vectors[a][k][1] for k in ids} for a in vectors}
    w = {k: weights[k] for k in ids}
    totals, steps = mcda.weighted_sum(criteria, w, scores, 0, 1)
    sens = mcda.sensitivity(criteria, w, scores, margin, 0, 1)
    return {"criteria": ids, "totals": totals, "steps": steps, "ranking": mcda.ranking(totals), "sensitivity": sens}


def pareto(vectors, indicator_ids):
    pts = {}
    for a, vec in vectors.items():
        if all(vec.get(k) for k in indicator_ids):
            pts[a] = {k: vec[k][1] for k in indicator_ids}
    if not pts:
        return [], []
    return mcda.pareto_front(pts, {k: "max" for k in indicator_ids}), sorted(pts)
