"""Lectura validada de lo exportado por SIADDI y SIADEC sin importar su código (C26.2, P7)."""
from __future__ import annotations

from isppr_platform import exchange

ORIGIN_TRIZ = "conceptual_design"
ORIGIN_QUALITY = "quality_management"


class HandoffError(ValueError):
    pass


def available(origin):
    return exchange.list_files(origin)


def _ids(values, lo, hi, field):
    out = []
    for v in values or []:
        if not isinstance(v, int) or not lo <= v <= hi:
            raise HandoffError(f"{field}_out_of_range:{v}")
        out.append(v)
    return out


def read_triz(path, demo_mode=False) -> dict:
    try:
        env = exchange.read_envelope(path, [ORIGIN_TRIZ], demo_mode)
    except exchange.EnvelopeError as exc:
        raise HandoffError(str(exc))
    p = env["payload"]
    c = p.get("contradiction")
    if c:
        _ids([c.get("improving"), c.get("worsening")], 1, 39, "parameter")
    useful = _ids(p.get("useful_principles"), 1, 40, "principle")
    matrix = _ids(p.get("matrix_principles"), 1, 40, "principle")
    student = _ids(p.get("student_selected_principles"), 1, 40, "principle")
    return {"file": path, "created_at": env["created_at"], "language": env["language"], "contradiction": c,
            "principles": useful or matrix or student, "useful": useful, "matrix": matrix,
            "principle_names": p.get("principle_names", {}), "ideas": p.get("ideas", []),
            "project": p.get("project_description"), "problem": p.get("problem"),
            "matrix_status": p.get("matrix_status"), "demo": bool(p.get("demo")), "project_id": p.get("project_id")}


def read_quality(path, demo_mode=False) -> dict:
    try:
        env = exchange.read_envelope(path, [ORIGIN_QUALITY], demo_mode)
    except exchange.EnvelopeError as exc:
        raise HandoffError(str(exc))
    p = env["payload"]
    stds = []
    for s in p.get("standards_marked", []):
        if not s.get("standard_id"):
            raise HandoffError("standard_without_id")
        stds.append(s)
    return {"file": path, "created_at": env["created_at"], "language": env["language"], "profile": p.get("profile", {}),
            "standards": stds, "clauses": p.get("clauses", []), "restrictions": p.get("restrictions", []),
            "iso_edition": p.get("iso_edition"), "demo": bool(p.get("demo")), "project_id": p.get("project_id")}
