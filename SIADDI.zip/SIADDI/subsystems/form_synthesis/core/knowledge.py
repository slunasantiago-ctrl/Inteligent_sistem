"""Base de conocimiento de SIADEF (C16): gramática, normas, procesos, capacidades, indicadores."""
from __future__ import annotations

import os

from isppr_platform import textnorm
from isppr_platform.datastore import DataMode, load_json
from isppr_platform.i18n import pick

from ..grammar.rules import GrammarBase
from ..grammar.vocabulary import Shape
from ..quality.preferred_numbers import PreferredNumbers
from ..quality.process_capability_db import CapabilityDB

SUB_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class FormKnowledge:
    def __init__(self, mode: DataMode = None, root: str = None):
        self.mode = mode or DataMode()
        self.root = root or SUB_ROOT
        d = self.mode.data_dir(self.root)
        self.data_dir = d
        self.grammar = GrammarBase(d, self.mode)
        pn = load_json(os.path.join(d, "standards", "preferred_numbers.json"), {})
        self.preferred_meta = pn
        self.preferred = PreferredNumbers(pn, self.mode.visible(pn))
        self.tolerance_tables = [t for t in load_json(os.path.join(d, "standards", "tolerance_tables.json"), {"tables": []})["tables"]
                                 if self.mode.visible(t)]
        self.processes = {p["process_id"]: p for p in load_json(os.path.join(d, "process_catalog.json"), {"processes": []})["processes"]}
        self.materials = {m["material_id"]: m for m in load_json(os.path.join(d, "material_catalog.json"), {"materials": []})["materials"]}
        self.capability = CapabilityDB(load_json(os.path.join(d, "process_capability.json"), {"records": []}), self.mode)
        self.indicators_data = load_json(os.path.join(d, "indicators.json"), {"indicators": []})
        self.scales = load_json(os.path.join(d, "semantic_scales.json"), {"scales": []})
        refs = load_json(os.path.join(d, "reference_shapes", "references.json"), {"shapes": []})
        self.references = [Shape.from_dict(r["shape"]) for r in refs.get("shapes", [])] if self.mode.visible(refs) else []
        self.ahp = load_json(os.path.join(d, "ahp_random_index.json"), {})
        self.concepts = load_json(os.path.join(d, "concepts.json"), {"concepts": []})
        self.pedagogical = load_json(os.path.join(d, "pedagogical_templates.json"), {})
        self.glossary = load_json(os.path.join(d, "glossary.json"), {"terms": []})

    @property
    def is_demo(self):
        return self.mode.demo

    def label(self, item):
        return self.mode.label(item)

    # ------------------------------------------------------------- indicadores
    def indicators(self):
        if not self.mode.visible(self.indicators_data):
            return []
        return [i for i in self.indicators_data.get("indicators", []) if self.mode.visible(i)]

    def indicator(self, iid):
        for i in self.indicators():
            if i["indicator_id"] == iid:
                return i
        return None

    def risk_spec(self):
        spec = self.indicators_data.get("risk_index")
        return spec if spec and self.mode.visible(spec) else None

    def ahp_random_index(self):
        return self.ahp.get("random_index") if self.mode.visible(self.ahp) else None

    def scales_visible(self):
        return self.scales.get("scales", []) if self.mode.visible(self.scales) else []

    def learning_spec(self):
        spec = (self.pedagogical or {}).get("learning")
        return spec if spec and self.mode.visible(spec) else None

    def improvement_options(self):
        return self.pedagogical.get("improvement_options", []) if self.mode.visible(self.pedagogical) else []

    # ------------------------------------------------------------- léxico
    def match(self, items, text):
        scored = []
        for it in items:
            hits = textnorm.match_stems(text, it.get("stems", {}))
            if hits:
                scored.append((len(hits), it, [h[0] for h in hits]))
        scored.sort(key=lambda x: -x[0])
        return scored

    def process_name(self, pid, lang):
        p = self.processes.get(pid)
        return pick(p["names"], lang) if p else None

    def material_name(self, mid, lang):
        m = self.materials.get(mid)
        return pick(m["names"], lang) if m else None

    def validate(self):
        return self.grammar.validate() + self.capability.validate()
