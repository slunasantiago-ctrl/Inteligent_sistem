"""Adaptador del subsistema 3 — SIADEF — a la plataforma (C26.1, P4).

Mientras no se apruebe el cambio de nombre de la opción [3], el identificador interno es
«standardization» y el código vive en la carpeta form_synthesis/ (C26.1, P4).
"""
from __future__ import annotations

from isppr_platform.subsystem import Subsystem


class FormSynthesisSubsystem(Subsystem):
    id = "standardization"
    name = "Стандартизация"
    status = "active"

    def run(self, session, io) -> str:
        from .interface.cli import SiadefCLI
        return SiadefCLI(session, io).run()
