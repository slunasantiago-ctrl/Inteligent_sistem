"""Salida SVG de alternativas y hoja de contactos (C35). Solo presentación, sin lógica."""
from __future__ import annotations

import os
from xml.sax.saxutils import escape

PAD = 0.12


def _transform(box, size):
    x0, y0, x1, y1 = box
    w, h = max(x1 - x0, 1e-9), max(y1 - y0, 1e-9)
    side = max(w, h) * (1 + 2 * PAD)
    ox = x0 - (side - w) / 2
    oy = y0 - (side - h) / 2
    k = size / side
    return lambda p: ((p[0] - ox) * k, size - (p[1] - oy) * k)


def _path(points, tf):
    return "M " + " L ".join(f"{tf(p)[0]:.2f},{tf(p)[1]:.2f}" for p in points) + " Z"


def shape_group(shape, size, highlight=(), box=None):
    tf = _transform(box or shape.bbox(), size)
    parts = []
    for e in shape.elements:
        d = _path(e.points, tf) + "".join(" " + _path(h, tf) for h in e.holes)
        joint = "joint" in e.labels
        stroke = "#c0392b" if e.eid in highlight else ("#2c3e50" if not joint else "#8e44ad")
        fill = "#d6eaf8" if not joint else "#e8daef"
        if "nested" in e.labels:
            fill = "#fdebd0"
        parts.append(f'<path d="{d}" fill="{fill}" fill-rule="evenodd" stroke="{stroke}" stroke-width="{2.4 if e.eid in highlight else 1.4}"/>')
    for a in shape.anchors:
        x, y = tf(a.point)
        parts.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="3" fill="#e67e22"/>')
    return "\n".join(parts)


def write_alternative(path, alt_id, shape, legend_lines, highlight=(), size=480):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    legend_h = 18 * (len(legend_lines) + 1)
    body = shape_group(shape, size, highlight)
    legend = "\n".join(f'<text x="10" y="{size + 18 * (i + 1)}" font-family="Helvetica, Arial, sans-serif" font-size="12" fill="#333">{escape(line)}</text>'
                       for i, line in enumerate(legend_lines))
    svg = (f'<?xml version="1.0" encoding="UTF-8"?>\n'
           f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size + legend_h}" viewBox="0 0 {size} {size + legend_h}">\n'
           f'<rect width="100%" height="100%" fill="#ffffff"/>\n'
           f'<text x="10" y="22" font-family="Helvetica, Arial, sans-serif" font-size="16" font-weight="bold" fill="#111">{escape(alt_id)}</text>\n'
           f'{body}\n{legend}\n</svg>\n')
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(svg)
    return path


def write_contact_sheet(path, items, cols=4, cell=220, title=""):
    """items: [(alt_id, shape, subtitle)]."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    rows = (len(items) + cols - 1) // cols
    W, H = cols * cell, rows * (cell + 30) + 40
    out = [f'<?xml version="1.0" encoding="UTF-8"?>',
           f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
           '<rect width="100%" height="100%" fill="#ffffff"/>',
           f'<text x="10" y="26" font-family="Helvetica, Arial, sans-serif" font-size="16" font-weight="bold">{escape(title)}</text>']
    for i, (aid, shape, sub) in enumerate(items):
        r, c = divmod(i, cols)
        x, y = c * cell, 40 + r * (cell + 30)
        out.append(f'<g transform="translate({x},{y})"><rect x="2" y="2" width="{cell - 4}" height="{cell + 26}" fill="none" stroke="#ddd"/>')
        out.append(shape_group(shape, cell))
        out.append(f'<text x="8" y="{cell + 20}" font-family="Helvetica, Arial, sans-serif" font-size="12">{escape(aid)} {escape(sub)}</text></g>')
    out.append("</svg>")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(out) + "\n")
    return path
