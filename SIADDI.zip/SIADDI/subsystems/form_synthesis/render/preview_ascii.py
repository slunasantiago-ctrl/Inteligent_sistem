"""Vista previa de baja resolución en la terminal (C35, nivel 3). Funciona sin Unicode."""
from __future__ import annotations

from ..grammar import geometry as geo


def preview(shape, cols: int = 44, rows: int = 20, unicode_ok: bool = True) -> str:
    x0, y0, x1, y1 = shape.bbox()
    w, h = max(x1 - x0, 1e-9), max(y1 - y0, 1e-9)
    # las celdas de terminal son ~2 veces más altas que anchas
    side = max(w, h * cols / (2 * rows))
    ox = x0 - (side - w) / 2
    sy = side * 2 * rows / cols
    oy = y0 - (sy - h) / 2
    full, joint, empty = ("█", "●", "·") if unicode_ok else ("#", "o", ".")
    lines = []
    for r in range(rows):
        y = oy + sy * (1 - (r + 0.5) / rows)
        line = []
        for c in range(cols):
            x = ox + side * (c + 0.5) / cols
            ch = empty
            for e in shape.elements:
                if geo.point_in_polygon((x, y), e.points) and not any(geo.point_in_polygon((x, y), hh) for hh in e.holes):
                    ch = joint if "joint" in e.labels else full
                    if ch == joint:
                        break
            line.append(ch)
        lines.append("".join(line).rstrip(empty) or "")
    return "\n".join("  " + ln for ln in lines)
