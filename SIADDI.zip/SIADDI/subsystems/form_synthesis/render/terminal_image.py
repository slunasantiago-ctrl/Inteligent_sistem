"""Niveles de vista previa (C35): imagen en terminal -> visor del sistema -> ASCII -> ruta.

Mostrar SVG dentro de la terminal requiere convertirlo a PNG: solo se intenta si la
dependencia opcional `cairosvg` está instalada y la terminal es compatible (iTerm2, WezTerm, kitty).
"""
from __future__ import annotations

import base64
import os
import subprocess
import sys


def terminal_supports_images() -> bool:
    prog = os.environ.get("TERM_PROGRAM", "")
    term = os.environ.get("TERM", "")
    return prog in ("iTerm.app", "WezTerm") or "kitty" in term


def show_inline(svg_path: str) -> bool:
    if not terminal_supports_images() or not sys.stdout.isatty():
        return False
    try:
        import cairosvg  # dependencia opcional
    except Exception:
        return False
    try:
        png = cairosvg.svg2png(url=svg_path, output_width=360)
        data = base64.b64encode(png).decode("ascii")
        sys.stdout.write(f"\x1b]1337;File=inline=1;width=40;preserveAspectRatio=1:{data}\a\n")
        sys.stdout.flush()
        return True
    except Exception:
        return False


def open_with_viewer(path: str) -> bool:
    """Abre el archivo con el visor del sistema, solo si el estudiante lo pide (C35)."""
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", path])
        elif os.name == "nt":
            os.startfile(path)  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False
