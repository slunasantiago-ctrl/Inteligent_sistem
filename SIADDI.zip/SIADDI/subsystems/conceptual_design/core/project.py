"""Estado del proyecto de diseño del subsistema 1 (A7, A11, A26.8, A27.5, A27.8)."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field


@dataclass
class PrincipleState:
    useful: bool = False
    discarded: bool = False
    ideas: list = field(default_factory=list)
    chosen_by: str = "matrix"   # "matrix" | "student" (exploración manual, rotulada)


@dataclass
class ProjectState:
    stage: int = 1
    description: str = ""
    problem: str = ""
    interpretation: object = None
    contradiction: object = None
    matrix_principles: list = field(default_factory=list)
    matrix_cell_found: bool = False
    manual_principles: list = field(default_factory=list)   # elegidos por el estudiante (rotulados)
    principle_states: dict = field(default_factory=dict)
    industry: str = "consumer_goods"   # A27.5: Diseño Industrial / Bienes de consumo
    current_index: int = 0
    general_ideas: list = field(default_factory=list)
    decisions: list = field(default_factory=list)   # [etapa, clave, parámetros] — decisión del estudiante
    exported_to: str = None

    def pstate(self, pid: int) -> PrincipleState:
        if pid not in self.principle_states:
            self.principle_states[pid] = PrincipleState()
        return self.principle_states[pid]

    def useful_principles(self):
        return [pid for pid, st in sorted(self.principle_states.items()) if st.useful]

    def all_ideas(self):
        out = [{"principle": None, "idea": i} for i in self.general_ideas]
        for pid, st in sorted(self.principle_states.items()):
            out += [{"principle": pid, "idea": i} for i in st.ideas]
        return out

    def to_record(self):
        c = self.contradiction.to_dict() if self.contradiction else None
        return {
            "description": self.description, "problem": self.problem, "contradiction": c,
            "matrix_principles": self.matrix_principles,
            "student_selected_principles": self.manual_principles,
            "principles": {str(k): asdict(v) for k, v in self.principle_states.items()},
            "industry": self.industry, "ideas": self.all_ideas(), "decisions": self.decisions,
        }
