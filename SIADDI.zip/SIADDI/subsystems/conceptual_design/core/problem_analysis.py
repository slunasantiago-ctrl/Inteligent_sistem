"""Interpretación lingüística del problema -> candidatos de parámetros TRIZ (A7 etapa 3, A12, A13, A26.11.6).

Capa de interpretación: produce hipótesis con puntuación, confianza y evidencias.
No consulta la matriz ni genera contenido TRIZ.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from isppr_platform import textnorm

W_PROBLEM = 1.0
W_PROJECT = 0.5
AMBIGUITY_RATIO = 0.8


@dataclass
class Evidence:
    word: str
    concept_id: str
    role: str        # "improve" | "worsen" | "neutral"
    source: str      # "problem" | "project"
    reason: str      # "before_contrast" | "after_contrast" | "worsen_cue" | "no_marker"


@dataclass
class Candidate:
    parameter_id: int
    score: float
    concept_id: str
    evidence: list = field(default_factory=list)


@dataclass
class Interpretation:
    improve: list
    worsen: list
    confidence_improve: float
    confidence_worsen: float
    ambiguous: bool
    contrast_found: bool
    connectors: list
    evidence: list

    @property
    def confidence(self) -> float:
        if not self.worsen:
            return round(self.confidence_improve * 0.5, 2)
        return round((self.confidence_improve + self.confidence_worsen) / 2, 2)

    @property
    def level(self) -> str:
        c = self.confidence
        return "high" if c >= 0.7 else ("medium" if c >= 0.5 else "low")


def confidence_level(value: float) -> str:
    return "high" if value >= 0.7 else ("medium" if value >= 0.5 else "low")


class ProblemInterpreter:
    def __init__(self, concepts: dict, markers: dict):
        self.concepts = concepts.get("concepts", [])
        self.markers = markers or {}

    def _contrast_position(self, norm_text: str):
        best = (-1, None)
        for lang_list in (self.markers.get("contrast") or {}).values():
            for phrase in lang_list:
                pos = textnorm.find_phrase(norm_text, phrase)
                if pos >= 0 and (best[0] < 0 or pos < best[0]):
                    best = (pos, textnorm.normalize(phrase))
        return best

    def _is_worsen_cue(self, token: str) -> bool:
        for lang_list in (self.markers.get("worsen_cues") or {}).values():
            for cue in lang_list:
                cue_n = textnorm.normalize(cue)
                if " " not in cue_n and token.startswith(cue_n):
                    return True
        return False

    def analyze(self, project_text: str, problem_text: str) -> Interpretation:
        imp, wor, evid, connectors = {}, {}, [], []
        contrast_any = False
        for text, weight, source in ((problem_text or "", W_PROBLEM, "problem"),
                                     (project_text or "", W_PROJECT, "project")):
            norm = textnorm.normalize(text)
            cpos, connector = self._contrast_position(norm)
            if cpos >= 0:
                contrast_any = True
                connectors.append(connector)
            for concept in self.concepts:
                for word, _stem, pos in textnorm.match_stems(text, concept.get("stems", {})):
                    cid = concept["concept_id"]
                    if self._is_worsen_cue(word):
                        role, reason = "worsen", "worsen_cue"
                        wor[cid] = wor.get(cid, 0) + weight * 1.2
                    elif cpos >= 0 and pos > cpos:
                        role, reason = "worsen", "after_contrast"
                        wor[cid] = wor.get(cid, 0) + weight
                        imp[cid] = imp.get(cid, 0) + weight * 0.2
                    elif cpos >= 0:
                        role, reason = "improve", "before_contrast"
                        imp[cid] = imp.get(cid, 0) + weight
                        wor[cid] = wor.get(cid, 0) + weight * 0.2
                    else:
                        role, reason = "neutral", "no_marker"
                        imp[cid] = imp.get(cid, 0) + weight * 0.6
                        wor[cid] = wor.get(cid, 0) + weight * 0.4
                    evid.append(Evidence(word, cid, role, source, reason))

        concept_by_id = {c["concept_id"]: c for c in self.concepts}
        imp_ranked = sorted(imp.items(), key=lambda kv: -kv[1])
        top_imp_concept = imp_ranked[0][0] if imp_ranked else None
        wor_ranked = sorted(((c, s) for c, s in wor.items() if c != top_imp_concept), key=lambda kv: -kv[1])

        def expand(ranked, exclude_params=()):
            out, seen = [], set(exclude_params)
            for cid, score in ranked:
                for rank, pid in enumerate(concept_by_id[cid].get("parameter_ids", [])):
                    if pid in seen:
                        continue
                    seen.add(pid)
                    ev = [e for e in evid if e.concept_id == cid]
                    out.append(Candidate(pid, round(score * (1.0 if rank == 0 else 0.7), 3), cid, ev))
            return out

        improve = expand(imp_ranked)
        worsen = expand(wor_ranked, exclude_params=[improve[0].parameter_id] if improve else [])

        def conf(ranked):
            if not ranked:
                return 0.0
            top = ranked[0][1]
            second = ranked[1][1] if len(ranked) > 1 else 0.0
            return round(top / (top + second + 0.5), 2)

        c_imp = conf(imp_ranked)
        c_wor = conf(wor_ranked)
        ambiguous = (not contrast_any) or not worsen or (
            len(imp_ranked) > 1 and imp_ranked[1][1] >= AMBIGUITY_RATIO * imp_ranked[0][1] and not contrast_any)
        if len(wor_ranked) > 1 and wor_ranked[1][1] >= AMBIGUITY_RATIO * wor_ranked[0][1]:
            ambiguous = True
        return Interpretation(improve, worsen, c_imp, c_wor, ambiguous, contrast_any, connectors, evid)
