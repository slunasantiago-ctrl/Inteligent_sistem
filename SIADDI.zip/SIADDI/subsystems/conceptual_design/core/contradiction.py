"""Contradicción técnica: parámetro que mejora × parámetro que empeora (A8)."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Contradiction:
    improving: int
    worsening: int
    confidence: float = 0.0
    origin: str = "siaddi"    # "siaddi" (hipótesis aceptada) | "student" (modificada por el estudiante)
    confirmed: bool = False

    def swapped(self) -> "Contradiction":
        return Contradiction(self.worsening, self.improving, self.confidence, "student", False)

    def valid(self) -> bool:
        return (1 <= self.improving <= 39 and 1 <= self.worsening <= 39
                and self.improving != self.worsening)

    def to_dict(self):
        return {"improving": self.improving, "worsening": self.worsening,
                "confidence": self.confidence, "origin": self.origin, "confirmed": self.confirmed}
