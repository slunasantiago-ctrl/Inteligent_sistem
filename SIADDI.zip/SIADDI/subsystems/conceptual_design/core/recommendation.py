"""Selección y orden de la información de la etapa 6 (A10, A27.2, A27.6, A27.7).

Solo filtra y ordena datos existentes; la «relación con tu problema» se arma con plantillas.
"""
from __future__ import annotations

from isppr_platform.i18n import pick

from ..triz.principles import SECTIONS


def principle_view(kb, pid: int, lang: str, contradiction, industry: str):
    p = kb.principles.get(pid)
    if p is None:
        return None
    names = {lg: pick(p.get("names"), lg) for lg in ("es", "en", "ru")}
    defs = pick(p.get("definition"), lang)
    examples = pick(p.get("examples"), lang)
    asit = p.get("asit_bridge") or {}
    asit_view = None
    if pick(asit.get("tool"), lang):
        asit_view = {"tool": pick(asit.get("tool"), lang),
                     "question": pick(asit.get("disruptive_question"), lang),
                     "example": pick(asit.get("example"), lang)}
    industry_text = pick((p.get("industry_examples") or {}).get(industry), lang)
    solved = []
    for c in p.get("contradictions_solved") or []:
        match = bool(contradiction and c.get("improving") == contradiction.improving
                     and c.get("preserving") == contradiction.worsening)
        solved.append({
            "improving": c.get("improving"), "preserving": c.get("preserving"),
            "improving_name": kb.parameters.name(c.get("improving"), lang),
            "preserving_name": kb.parameters.name(c.get("preserving"), lang),
            "solution": pick(c.get("solution"), lang), "matches_student": match,
        })
    solved.sort(key=lambda s: not s["matches_student"])  # A27.7: resaltar coincidencia
    freq = p.get("frequency") or {}
    done, total = kb.principles.completeness(pid, lang)
    return {
        "id": pid, "names": names, "active_name": names.get(lang),
        "provisional_name": kb.principles.is_provisional_name(pid),
        "definition": defs, "examples": examples, "asit": asit_view,
        "industry": industry, "industry_text": industry_text,
        "contradictions_solved": solved,
        "frequency_label": pick(freq.get("label"), lang), "instances": freq.get("instance_count"),
        "guiding_questions": pick(p.get("guiding_questions"), lang),
        "completeness": (done, total), "sections": SECTIONS,
    }


def order_principles(kb, pids):
    """Mantiene el orden de la matriz (no reordena por invención)."""
    return [pid for pid in pids if kb.principles.get(pid)]
