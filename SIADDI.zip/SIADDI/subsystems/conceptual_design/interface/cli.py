"""Interfaz de terminal del subsistema 1 — SIADDI (A7–A11, A21, A22, A26.8, A27).

Solo presenta y pregunta: la lógica vive en core/ y triz/. Todos los textos salen de
locales/*.json mediante t(clave, idioma).
"""
from __future__ import annotations

import os

from isppr_platform import exchange, language_select, terminal
from isppr_platform.datastore import DataMode, save_json
from isppr_platform.dialog import Dialog
from isppr_platform.i18n import number
from isppr_platform.subsystem import RESULT_MENU, ReturnToMenu

from ..core.contradiction import Contradiction
from ..core.problem_analysis import ProblemInterpreter, confidence_level
from ..core.project import ProjectState
from ..core.recommendation import order_principles, principle_view
from ..language.manager import translator
from ..triz.knowledge import SUB_ROOT, TrizKnowledge

SUBSYSTEM_ID = "conceptual_design"
HEADER = ("SIADDI", "Sistema Inteligente de Apoyo a Decisiones", "Estratégicas en Diseño Industrial")
OUTPUT_DIR = os.path.join(SUB_ROOT, "output")
SUBSYSTEM_VERSION = "1.0"


class SiaddiCLI:
    def __init__(self, session, io, kb: TrizKnowledge = None):
        self.session = session
        self.io = io
        self.kb = kb or TrizKnowledge(DataMode(session.demo, session.draft))
        self.dlg = Dialog(io, session, translator())
        self.interpreter = ProblemInterpreter(self.kb.concepts, self.kb.markers)
        self.state = session.state_for(SUBSYSTEM_ID, ProjectState)

    # ------------------------------------------------------------------ helpers
    def t(self, key, **kw):
        return self.dlg.t(key, **kw)

    @property
    def lang(self):
        return self.dlg.lang

    def pname(self, pid):
        name = self.kb.parameters.name(pid, self.lang)
        return name if name else self.t("missing_name")

    def prname(self, pid):
        name = self.kb.principles.name(pid, self.lang)
        if not name:
            return self.t("missing_name")
        if self.kb.principles.is_provisional_name(pid):
            name += " " + self.t("provisional_term")
        return name

    def demo_notice(self):
        if self.kb.is_demo:
            self.dlg.warn(self.t("demo_notice"))

    def short_product(self):
        words = self.state.description.split()
        return " ".join(words[:10]) + ("…" if len(words) > 10 else "")

    def labelled(self, who, text):
        key = {"student": "label_student", "system": "label_system", "decision": "label_decision"}[who]
        self.dlg.say(terminal.style(f"[{self.t(key)}]", "accent2") + " " + text)

    # ------------------------------------------------------------------ flujo
    def run(self) -> str:
        if not self.session.language:
            self.session.language = language_select.select_language(self.io, HEADER)
        try:
            if self.state.stage > 1:
                self.dlg.title(self.t("resume_title"))
                self.dlg.option("1", self.t("resume_continue", stage=self.state.stage))
                self.dlg.option("2", self.t("resume_new"))
                if self.dlg.choose(["1", "2"]) == "2":
                    self.session.subsystem_states[SUBSYSTEM_ID] = ProjectState()
                    self.state = self.session.subsystem_states[SUBSYSTEM_ID]
            stages = {1: self.stage1, 2: self.stage2, 3: self.stage3, 4: self.stage4,
                      5: self.stage5, 6: self.stage6, 7: self.closing}
            while self.state.stage in stages:
                stages[self.state.stage]()
            return RESULT_MENU
        except ReturnToMenu:
            return RESULT_MENU

    # ETAPA 1 ---------------------------------------------------------------
    def stage1(self):
        self.dlg.title(self.t("stage1_title"))
        self.dlg.hint_globals()
        self.dlg.note(self.t("stage1_help"))
        self.state.description = self.dlg.ask_text("describe_project")
        self.state.stage = 2

    # ETAPA 2 ---------------------------------------------------------------
    def stage2(self):
        self.dlg.title(self.t("stage2_title"))
        self.state.problem = self.dlg.ask_text("describe_problem")
        self.state.stage = 3

    # ETAPA 3 ---------------------------------------------------------------
    def show_parameter_list(self):
        self.dlg.section(self.t("param_list_title"))
        for pid in range(1, 40):
            self.dlg.say(f"  [{pid:2d}] {self.pname(pid)}")
        self.dlg.note(self.t("names_reference_notice"))

    def explain_candidate(self, cand):
        words = sorted({e.word for e in cand.evidence})
        reasons = sorted({self.t("reason_" + e.reason) for e in cand.evidence})
        return self.t("why_parameter", words=", ".join(words), concept=cand.concept_id,
                      reasons="; ".join(reasons), pid=cand.parameter_id, name=self.pname(cand.parameter_id))

    def stage3(self):
        self.dlg.title(self.t("stage3_title"))
        interp = self.interpreter.analyze(self.state.description, self.state.problem)
        self.state.interpretation = interp
        self.labelled("student", f"«{self.state.problem}»")
        if not interp.improve:
            self.dlg.warn(self.t("no_candidates"))
            self.manual_contradiction()
            return
        imp, wor = interp.improve[0], (interp.worsen[0] if interp.worsen else None)
        self.labelled("system", self.t("hypothesis_note"))
        self.dlg.say(f"  {self.t('improves')}: [{imp.parameter_id}] {self.pname(imp.parameter_id)}")
        if wor:
            self.dlg.say(f"  {self.t('worsens')}: [{wor.parameter_id}] {self.pname(wor.parameter_id)}")
        else:
            self.dlg.say(f"  {self.t('worsens')}: {self.t('not_identified')}")
        lvl = confidence_level(interp.confidence)
        self.dlg.say(f"  {self.t('confidence')}: {number(interp.confidence, self.lang)} ({self.t('level_' + lvl)})")
        if interp.ambiguous:
            self.dlg.warn(self.t("ambiguous_notice"))
        self.dlg.section(self.t("alternatives"))
        alts_i = [c.parameter_id for c in interp.improve[1:4]]
        alts_w = [c.parameter_id for c in interp.worsen[1:4]]
        self.dlg.say(f"  {self.t('improves')}: " + (", ".join(f"[{p}] {self.pname(p)}" for p in alts_i) or "—"))
        self.dlg.say(f"  {self.t('worsens')}: " + (", ".join(f"[{p}] {self.pname(p)}" for p in alts_w) or "—"))
        while True:
            self.dlg.blank()
            self.dlg.option("c", self.t("opt_confirm"))
            self.dlg.option("s", self.t("opt_swap"))
            self.dlg.option("e", self.t("opt_choose_alternative"))
            self.dlg.option("r", self.t("opt_reject_manual"))
            self.dlg.option("l", self.t("opt_param_list"))
            self.dlg.option("?", self.t("opt_why"))
            ch = self.dlg.choose(["c", "s", "e", "r", "l", "?"])
            if ch == "?":
                self.dlg.say(self.explain_candidate(imp))
                if wor:
                    self.dlg.say(self.explain_candidate(wor))
                continue
            if ch == "l":
                self.show_parameter_list()
                continue
            if ch == "r" or wor is None:
                if ch != "r":
                    self.dlg.warn(self.t("need_worsening"))
                self.manual_contradiction()
                return
            if ch == "c":
                self.state.contradiction = Contradiction(imp.parameter_id, wor.parameter_id, interp.confidence, "siaddi")
                self.state.decisions.append([3, "decision_confirmed_interpretation", {}])
            elif ch == "s":
                self.state.contradiction = Contradiction(wor.parameter_id, imp.parameter_id, interp.confidence, "student")
                self.state.decisions.append([3, "decision_swapped", {}])
            elif ch == "e":
                i = self.dlg.ask_int("ask_improving_id", 1, 39, default=imp.parameter_id)
                w = self.dlg.ask_int("ask_worsening_id", 1, 39, default=wor.parameter_id)
                if i == w:
                    self.dlg.warn(self.t("same_parameter"))
                    continue
                self.state.contradiction = Contradiction(i, w, interp.confidence, "student")
                self.state.decisions.append([3, "decision_modified", {}])
            self.state.stage = 4
            return

    def manual_contradiction(self):
        self.show_parameter_list()
        while True:
            i = self.dlg.ask_int("ask_improving_id", 1, 39)
            w = self.dlg.ask_int("ask_worsening_id", 1, 39)
            if i != w:
                break
            self.dlg.warn(self.t("same_parameter"))
        self.state.contradiction = Contradiction(i, w, 0.0, "student")
        self.state.decisions.append([3, "decision_manual", {}])
        self.state.stage = 4

    # ETAPA 4 ---------------------------------------------------------------
    def describe_param(self, pid):
        desc = self.kb.parameters.description(pid, self.lang)
        self.dlg.say(f"    {self.t('definition')}: " + (desc if desc else self.t("missing_parameter_description")))

    def stage4(self):
        c = self.state.contradiction
        self.dlg.title(self.t("stage4_title"))
        self.dlg.say(self.t("contradiction_sentence", improve=self.pname(c.improving).lower(),
                            worsen=self.pname(c.worsening).lower()))
        self.dlg.blank()
        self.dlg.say(terminal.style(self.t("param_improves_label"), "bold"))
        self.dlg.say(f"  [{c.improving}] {self.pname(c.improving)}")
        self.describe_param(c.improving)
        self.dlg.say(terminal.style(self.t("param_worsens_label"), "bold"))
        self.dlg.say(f"  [{c.worsening}] {self.pname(c.worsening)}")
        self.describe_param(c.worsening)
        self.dlg.section(self.t("explanation"))
        self.dlg.say("  " + self.t("contradiction_explanation"))
        self.dlg.section(self.t("relation_problem"))
        self.dlg.say("  " + self.t("relation_template", product=self.short_product(),
                                   improve=self.pname(c.improving), worsen=self.pname(c.worsening)))
        lvl = confidence_level(c.confidence)
        origin = self.t("origin_" + c.origin)
        self.dlg.say(f"  {self.t('confidence')}: {number(c.confidence, self.lang)} ({self.t('level_' + lvl)}) — {origin}")
        if self.state.interpretation and self.state.interpretation.improve:
            alts = [x.parameter_id for x in self.state.interpretation.improve[:3] if x.parameter_id != c.improving]
            altw = [x.parameter_id for x in self.state.interpretation.worsen[:3] if x.parameter_id != c.worsening]
            self.dlg.section(self.t("alternatives"))
            self.dlg.say(f"  {self.t('improves')}: " + (", ".join(f"[{p}] {self.pname(p)}" for p in alts) or "—"))
            self.dlg.say(f"  {self.t('worsens')}: " + (", ".join(f"[{p}] {self.pname(p)}" for p in altw) or "—"))
        self.dlg.blank()
        self.dlg.say(terminal.style(self.t("confirm_contradiction"), "bold"))
        self.dlg.option("c", self.t("opt_confirm"))
        self.dlg.option("s", self.t("opt_swap"))
        self.dlg.option("e", self.t("opt_modify"))
        ch = self.dlg.choose(["c", "s", "e"])
        if ch == "c":
            c.confirmed = True
            self.state.decisions.append([4, "decision_contradiction_confirmed", {"i": c.improving, "w": c.worsening}])
            self.state.stage = 5
        elif ch == "s":
            self.state.contradiction = c.swapped()
        else:
            i = self.dlg.ask_int("ask_improving_id", 1, 39, default=c.improving)
            w = self.dlg.ask_int("ask_worsening_id", 1, 39, default=c.worsening)
            if i == w:
                self.dlg.warn(self.t("same_parameter"))
                return
            self.state.contradiction = Contradiction(i, w, c.confidence, "student")

    # ETAPA 5 ---------------------------------------------------------------
    def stage5(self):
        c = self.state.contradiction
        self.dlg.title(self.t("stage5_title"))
        self.demo_notice()
        self.dlg.say(self.t("matrix_query", i=c.improving, w=c.worsening,
                            iname=self.pname(c.improving), wname=self.pname(c.worsening)))
        status = self.kb.matrix.status
        if status != "complete":
            cov = self.kb.matrix.coverage()
            self.dlg.warn(self.t("matrix_incomplete", status=self.t("matrix_status_" + status),
                                 filled=cov["filled"], missing=cov["empty"]))
        result = self.kb.matrix.lookup(c.improving, c.worsening)
        if result:
            self.state.matrix_principles = order_principles(self.kb, result)
            self.state.matrix_cell_found = True
            self.dlg.ok(self.t("matrix_result", n=len(result)))
            for pid in self.state.matrix_principles:
                self.dlg.say(f"  [{pid}] {self.prname(pid)}")
            src = self.kb.matrix.source
            if src:
                self.dlg.note(self.t("source_label") + ": " + src)
            self.dlg.pause()
            self.state.current_index = 0
            self.state.stage = 6
            return
        self.state.matrix_cell_found = False
        self.dlg.warn(self.t("matrix_cell_missing"))
        self.dlg.option("b", self.t("opt_back_contradiction"))
        self.dlg.option("x", self.t("opt_explore_manual"))
        self.dlg.option("f", self.t("opt_finish"))
        ch = self.dlg.choose(["b", "x", "f"])
        if ch == "b":
            self.state.stage = 4
            self.state.contradiction.confirmed = False
        elif ch == "x":
            ids = self.dlg.ask_int_list("ask_principle_ids", 1, 40, allow_empty=False)
            self.state.matrix_principles = []
            for pid in ids:
                self.state.pstate(pid).chosen_by = "student"
            self.state.manual_principles = ids
            self.state.decisions.append([5, "decision_manual_principles", {"ids": ", ".join(map(str, ids))}])
            self.state.current_index = 0
            self.state.stage = 6
        else:
            self.state.stage = 7

    # ETAPA 6 ---------------------------------------------------------------
    def principle_list(self):
        if self.state.matrix_principles:
            return self.state.matrix_principles
        return self.state.manual_principles

    def render_principle(self, pid):
        v = principle_view(self.kb, pid, self.lang, self.state.contradiction, self.state.industry)
        c = self.state.contradiction
        st = self.state.pstate(pid)
        self.dlg.title(self.t("stage6_title"))
        self.demo_notice()
        done, total = v["completeness"]
        lst = self.principle_list()
        pos = lst.index(pid) + 1 if pid in lst else 1
        self.dlg.say(terminal.style(f"{self.t('principle')} {pid} — {v['active_name'] or self.t('missing_name')}", "title")
                     + f"   ({pos}/{len(lst)})")
        if v["provisional_name"]:
            self.dlg.note(self.t("provisional_name_notice"))
        others = [f"{lg.upper()}: {v['names'][lg]}" for lg in ("es", "en", "ru") if lg != self.lang and v["names"].get(lg)]
        self.dlg.note("  " + " · ".join(others))
        self.dlg.note("  " + self.t("completeness", done=done, total=total))
        if st.chosen_by == "student":
            self.dlg.warn(self.t("chosen_by_student"))
        # 2 definición
        self.dlg.section("1. " + self.t("sec_definition"))
        if v["definition"]:
            for d in v["definition"]:
                self.dlg.bullet(d)
        else:
            self.dlg.say("  " + self.t("no_documented_info"))
        # 3 relación
        self.dlg.section("2. " + self.t("sec_relation"))
        self.dlg.say("  " + self.t("principle_relation_template", principle=v["active_name"] or pid,
                                   product=self.short_product(), improve=self.pname(c.improving),
                                   worsen=self.pname(c.worsening)))
        # 4 ejemplos
        self.dlg.section("3. " + self.t("sec_examples"))
        if v["examples"]:
            for e in v["examples"]:
                self.dlg.bullet(e)
        else:
            self.dlg.say("  " + self.t("no_documented_info"))
        # 5 ASIT
        self.dlg.section("4. " + self.t("sec_asit"))
        if v["asit"]:
            self.dlg.say(f"  {self.t('asit_tool')}: {v['asit']['tool']}")
            self.dlg.say(f"  {self.t('asit_question')}: {v['asit']['question'] or self.t('no_documented_info')}")
            self.dlg.say(f"  {self.t('asit_example')}: {v['asit']['example'] or self.t('no_documented_info')}")
        else:
            self.dlg.say("  " + self.t("no_documented_info"))
        # 6 industria
        self.dlg.section("5. " + self.t("sec_industry") + f" — {self.t('industry_' + v['industry'])}")
        self.dlg.say("  " + (v["industry_text"] or self.t("no_industry_example")))
        # 7 contradicciones resueltas
        self.dlg.section("6. " + self.t("sec_contradictions"))
        if v["contradictions_solved"]:
            for s in v["contradictions_solved"]:
                mark = terminal.style(" ◀ " + self.t("matches_yours"), "accent") if s["matches_student"] else ""
                self.dlg.bullet(f"{self.t('improves')} [{s['improving']}] {s['improving_name']} / "
                                f"{self.t('preserves')} [{s['preserving']}] {s['preserving_name']}: "
                                f"{s['solution'] or self.t('no_documented_info')}{mark}")
        else:
            self.dlg.say("  " + self.t("no_documented_info"))
        # 8 frecuencia
        self.dlg.section("7. " + self.t("sec_frequency"))
        if v["instances"] is not None:
            self.dlg.say(f"  {v['frequency_label'] or ''} — {self.t('instances', n=v['instances'])}")
        else:
            self.dlg.say("  " + self.t("no_documented_info"))
        # 9 preguntas
        self.dlg.section("8. " + self.t("sec_questions"))
        if v["guiding_questions"]:
            for q in v["guiding_questions"]:
                self.dlg.bullet(q)
        else:
            self.dlg.say("  " + self.t("no_documented_info"))
            self.dlg.note("  " + self.t("pedagogical_questions_hint"))
        # estado del estudiante
        self.dlg.blank()
        status = self.t("state_useful") if st.useful else (self.t("state_discarded") if st.discarded else self.t("state_pending"))
        self.labelled("decision", status)
        for idea in st.ideas:
            self.labelled("student", idea)

    def why_principle(self, pid):
        c = self.state.contradiction
        p = self.kb.principles.get(pid) or {}
        inst = (p.get("frequency") or {}).get("instance_count")
        if self.state.pstate(pid).chosen_by == "student":
            self.dlg.say(self.t("why_principle_student"))
        else:
            self.dlg.say(self.t("why_principle", i=c.improving, w=c.worsening, iname=self.pname(c.improving),
                                wname=self.pname(c.worsening), n=inst if inst is not None else "—"))
            if self.kb.matrix.source:
                self.dlg.note(self.t("source_label") + ": " + self.kb.matrix.source)

    def exploration_questions(self, pid):
        """A11: preguntas pedagógicas sobre producto, problema, contexto, usuario y principio."""
        c = self.state.contradiction
        name = self.kb.principles.name(pid, self.lang) or str(pid)
        self.dlg.section(self.t("exploration_title"))
        self.dlg.note(self.t("pedagogical_label"))
        for key in ("q_product", "q_problem", "q_context", "q_user", "q_principle"):
            self.dlg.bullet(self.t(key, principle=name, product=self.short_product(),
                                   improve=self.pname(c.improving), worsen=self.pname(c.worsening)))

    def choose_industry(self):
        inds = self.kb.principles.industries or ["consumer_goods"]
        for i, key in enumerate(inds, start=1):
            self.dlg.option(str(i), self.t("industry_" + key))
        n = self.dlg.ask_int("ask_industry", 1, len(inds))
        self.state.industry = inds[n - 1]

    def stage6(self):
        lst = self.principle_list()
        if not lst:
            self.state.stage = 7
            return
        idx = max(0, min(self.state.current_index, len(lst) - 1))
        pid = lst[idx]
        self.render_principle(pid)
        st = self.state.pstate(pid)
        self.dlg.blank()
        for key, label in (("s", "nav_next"), ("a", "nav_prev"), ("l", "nav_list"), ("u", "nav_useful"),
                           ("d", "nav_discard"), ("i", "nav_idea"), ("g", "nav_explore"), ("c", "nav_industry"),
                           ("?", "opt_why"), ("f", "nav_finish")):
            self.dlg.option(key, self.t(label))
        self.dlg.hint_globals()
        ch = self.dlg.choose(["s", "a", "l", "u", "d", "i", "g", "c", "?", "f"])
        if ch == "s":
            self.state.current_index = min(idx + 1, len(lst) - 1)
        elif ch == "a":
            self.state.current_index = max(idx - 1, 0)
        elif ch == "l":
            self.dlg.section(self.t("nav_list"))
            for i, p in enumerate(lst, start=1):
                mark = "★ " if self.state.pstate(p).useful else ("✗ " if self.state.pstate(p).discarded else "  ")
                self.dlg.say(f"  {i}. {mark}[{p}] {self.prname(p)}")
            n = self.dlg.ask_int("ask_go_to", 1, len(lst), default=idx + 1)
            self.state.current_index = n - 1
        elif ch == "u":
            st.useful, st.discarded = True, False
            self.state.decisions.append([6, "decision_useful", {"pid": pid}])
        elif ch == "d":
            st.useful, st.discarded = False, True
            self.state.decisions.append([6, "decision_discard", {"pid": pid}])
        elif ch == "i":
            idea = self.dlg.ask_text("ask_idea", principle=self.prname(pid))
            st.ideas.append(idea)
        elif ch == "g":
            self.exploration_questions(pid)
            idea = self.dlg.ask(self.t("ask_idea_optional") + " ")
            if idea:
                st.ideas.append(idea)
        elif ch == "c":
            self.choose_industry()
        elif ch == "?":
            self.why_principle(pid)
            self.dlg.pause()
        elif ch == "f":
            self.state.stage = 7

    # CIERRE ----------------------------------------------------------------
    def summary_lines(self):
        c = self.state.contradiction
        out = [self.t("label_student") + ":", "  " + self.state.description, "  " + self.state.problem]
        out.append(self.t("label_system") + ":")
        if c:
            out.append(f"  {self.t('improves')} [{c.improving}] {self.pname(c.improving)} × "
                       f"{self.t('worsens')} [{c.worsening}] {self.pname(c.worsening)}")
        if self.state.matrix_principles:
            out.append("  " + self.t("matrix_principles_label") + ": " +
                       ", ".join(f"{p} {self.prname(p)}" for p in self.state.matrix_principles))
        out.append(self.t("label_decision") + ":")
        for stage, key, kw in self.state.decisions:
            out.append(f"  ({self.t('stage')} {stage}) {self.t(key, **kw)}")
        for item in self.state.all_ideas():
            prefix = f"[{item['principle']}] " if item["principle"] else ""
            out.append(f"  {self.t('idea')}: {prefix}{item['idea']}")
        return out

    def closing(self):
        self.dlg.title(self.t("closing_title"))
        self.demo_notice()
        for line in self.summary_lines():
            self.dlg.say(line)
        while True:
            self.dlg.blank()
            self.dlg.option("i", self.t("nav_general_idea"))
            self.dlg.option("g", self.t("opt_save_record"))
            self.dlg.option("x", self.t("opt_export"))
            self.dlg.option("v", self.t("opt_back_stage6"))
            self.dlg.option("n", self.t("resume_new"))
            self.dlg.option("m", self.t("opt_menu"))
            ch = self.dlg.choose(["i", "g", "x", "v", "n"])
            if ch == "i":
                self.state.general_ideas.append(self.dlg.ask_text("ask_general_idea"))
            elif ch == "g":
                path = self.save_record()
                self.dlg.ok(self.t("saved_to", path=path))
            elif ch == "x":
                path = self.export()
                self.dlg.ok(self.t("exported_to", path=path))
            elif ch == "v":
                if self.principle_list():
                    self.state.stage = 6
                    return
                self.dlg.warn(self.t("no_principles"))
            elif ch == "n":
                self.session.subsystem_states[SUBSYSTEM_ID] = ProjectState()
                self.state = self.session.subsystem_states[SUBSYSTEM_ID]
                return

    def save_record(self) -> str:
        """Registro local del trabajo (A18). En demo se rotula y no se mezcla (A26.11.2)."""
        import datetime as dt
        sub = "demo" if self.kb.is_demo else "records"
        stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        base = os.path.join(OUTPUT_DIR, sub, f"siaddi_{stamp}")
        rec = self.state.to_record()
        rec.update({"language": self.lang, "demo": self.kb.is_demo, "matrix_status": self.kb.matrix.status,
                    "matrix_source": self.kb.matrix.source})
        save_json(base + ".json", rec)
        with open(base + ".txt", "w", encoding="utf-8") as fh:
            if self.kb.is_demo:
                fh.write(terminal.strip_ansi(self.t("demo_notice")) + "\n\n")
            fh.write("\n".join(terminal.strip_ansi(x) for x in self.summary_lines()) + "\n")
        return base + ".txt"

    def export_payload(self) -> dict:
        c = self.state.contradiction
        useful = self.state.useful_principles()
        names = {}
        for pid in sorted(set(self.state.matrix_principles) | set(useful) | set(self.state.manual_principles)):
            p = self.kb.principles.get(pid) or {}
            names[str(pid)] = {"names": p.get("names"), "provisional": self.kb.principles.is_provisional_name(pid),
                               "source": p.get("source")}
        return {
            "project_id": self.session.project_id,
            "subsystem_version": SUBSYSTEM_VERSION,
            "project_description": self.state.description,
            "problem": self.state.problem,
            "contradiction": {"improving": c.improving, "worsening": c.worsening} if c else None,
            "matrix_principles": list(self.state.matrix_principles),
            "student_selected_principles": list(self.state.manual_principles),
            "useful_principles": useful,
            "principle_names": names,
            "ideas": self.state.all_ideas(),
            "decisions": [{"stage": st, "key": k, "params": kw, "text": self.t(k, **kw)}
                          for st, k, kw in self.state.decisions],
            "matrix_status": self.kb.matrix.status,
            "sources": [self.kb.matrix.source, self.kb.principles.meta.get("source")],
            "demo": self.kb.is_demo,
        }

    def export(self) -> str:
        """Exportación al sobre común (P7.3) para SIADEF."""
        path = exchange.write_envelope(SUBSYSTEM_ID, self.lang, self.export_payload())
        self.state.exported_to = path
        return path
