import os
import tempfile
import unittest

from tests import _helpers  # noqa: F401
from isppr_platform.datastore import DataMode
from subsystems.conceptual_design.core.problem_analysis import ProblemInterpreter
from subsystems.conceptual_design.triz.contradiction_matrix import MatrixImportError, parse_matrix_csv
from subsystems.conceptual_design.triz.knowledge import TrizKnowledge
from subsystems.conceptual_design import setup_data


class InterpreterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        kb = TrizKnowledge(DataMode())
        cls.pi = ProblemInterpreter(kb.concepts, kb.markers)

    def check(self, text, improve, worsen):
        r = self.pi.analyze("", text)
        self.assertTrue(r.improve, text)
        self.assertEqual(r.improve[0].parameter_id, improve, text)
        self.assertTrue(r.worsen, text)
        self.assertIn(r.worsen[0].parameter_id, worsen, text)

    def test_strength_vs_weight_three_languages(self):
        self.check("La silla debe ser más resistente pero sin aumentar el peso", 14, (1, 2))
        self.check("The chair must be stronger but without increasing weight", 14, (1, 2))
        self.check("Стул должен быть прочнее, но без увеличения веса", 14, (1, 2))

    def test_inverse_order(self):
        self.check("Quiero que sea más ligera pero que no pierda resistencia", 2, (13, 14))

    def test_empty_text_is_low_confidence(self):
        r = self.pi.analyze("", "")
        self.assertEqual(r.improve, [])
        self.assertEqual(r.level, "low")


def grid(cell_14_2="1 10 35"):
    rows = []
    for i in range(1, 40):
        row = [""] * 39
        if i == 14:
            row[1] = cell_14_2
        rows.append(";".join(row))
    return "\n".join(rows) + "\n"


class MatrixTests(unittest.TestCase):
    def test_normal_matrix_is_empty_until_loaded(self):
        kb = TrizKnowledge(DataMode())
        self.assertFalse(kb.matrix.lookup(14, 2))

    def test_demo_cell(self):
        kb = TrizKnowledge(DataMode(demo=True))
        self.assertEqual(kb.matrix.lookup(14, 2), [1, 10, 35])

    def test_parse_rejects_bad_principle(self):
        with self.assertRaises(MatrixImportError):
            parse_matrix_csv(grid("1 99"))
        with self.assertRaises(MatrixImportError):
            parse_matrix_csv(grid("1 1"))
        with self.assertRaises(MatrixImportError):
            parse_matrix_csv("1;2\n")

    def test_parse_accepts_valid(self):
        cells, status = parse_matrix_csv(grid())
        self.assertEqual(cells[(14, 2)], [1, 10, 35])
        self.assertEqual(status, "partial")

    def test_import_requires_source(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "m.csv")
            with open(p, "w") as fh:
                fh.write(grid())
            with self.assertRaises(setup_data.ImportFailed):
                setup_data.import_matrix(p, "", data_dir=d)


class KnowledgeTests(unittest.TestCase):
    def test_data_validates(self):
        kb = TrizKnowledge(DataMode())
        self.assertIn("SIADDI", setup_data.status_report(kb) if hasattr(setup_data, "status_report") else "SIADDI")


if __name__ == "__main__":
    unittest.main()
