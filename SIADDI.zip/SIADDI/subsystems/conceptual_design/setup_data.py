"""Carga y verificación de datos del subsistema 1 (A26.11).

Uso (desde la raíz del proyecto):
    python3 setup_data.py conceptual_design import-matrix archivo.csv --source "..."
    python3 setup_data.py conceptual_design import-principles archivo.json --source "..."
    python3 setup_data.py conceptual_design import-parameters archivo.json --source "..."
    python3 setup_data.py conceptual_design status
Si la validación falla, no se escribe nada y se muestra el motivo.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os

from isppr_platform.datastore import load_json, save_json

from .triz.contradiction_matrix import MatrixImportError, parse_matrix_csv
from .triz.knowledge import SUB_ROOT, TrizKnowledge
from .triz.principles import SECTIONS

DATA = os.path.join(SUB_ROOT, "data")


class ImportFailed(Exception):
    pass


def import_matrix(path: str, source: str, data_dir: str = DATA) -> dict:
    if not source:
        raise ImportFailed("--source es obligatorio")
    with open(path, encoding="utf-8-sig") as fh:
        text = fh.read()
    try:
        cells, status = parse_matrix_csv(text)
    except MatrixImportError as exc:
        raise ImportFailed(str(exc))
    data = {"meta": {"matrix_status": status, "source": source,
                     "verified_on": dt.date.today().isoformat()},
            "cells": {f"{a}x{b}": v for (a, b), v in sorted(cells.items())}}
    save_json(os.path.join(data_dir, "contradiction_matrix.json"), data)
    return data["meta"] | {"filled": len(cells)}


def _validate_principle(rec: dict):
    pid = rec.get("id")
    if not isinstance(pid, int) or not 1 <= pid <= 40:
        raise ImportFailed(f"id de principio fuera de 1..40: {pid}")
    if not rec.get("source"):
        raise ImportFailed(f"principio {pid}: falta 'source'")
    for c in rec.get("contradictions_solved") or []:
        for key in ("improving", "preserving"):
            v = c.get(key)
            if not isinstance(v, int) or not 1 <= v <= 39:
                raise ImportFailed(f"principio {pid}: contradictions_solved.{key} fuera de 1..39: {v}")
    for key in ("names", "definition", "examples", "guiding_questions"):
        if key in rec and rec[key] is not None and not isinstance(rec[key], dict):
            raise ImportFailed(f"principio {pid}: '{key}' debe ser un objeto por idioma")


def import_principles(path: str, source: str, data_dir: str = DATA) -> int:
    """Importación incremental (A26.11.3): actualiza solo los principios del archivo."""
    incoming = load_json(path)
    records = incoming.get("principles", incoming) if isinstance(incoming, dict) else incoming
    if not isinstance(records, list):
        raise ImportFailed("formato: lista de principios o {'principles': [...]}")
    for rec in records:
        rec.setdefault("source", source)
        if not source and not rec.get("source"):
            raise ImportFailed("--source es obligatorio")
        _validate_principle(rec)
    target = os.path.join(data_dir, "principles.json")
    base = load_json(target, {"meta": {}, "principles": []})
    by_id = {p["id"]: p for p in base["principles"]}
    for rec in records:
        merged = dict(by_id.get(rec["id"], {}))
        merged.update(rec)
        merged["status"] = rec.get("status", "approved")
        by_id[rec["id"]] = merged
    base["principles"] = [by_id[k] for k in sorted(by_id)]
    save_json(target, base)
    return len(records)


def import_parameters(path: str, source: str, data_dir: str = DATA) -> int:
    incoming = load_json(path)
    records = incoming.get("parameters", incoming) if isinstance(incoming, dict) else incoming
    if not isinstance(records, list):
        raise ImportFailed("formato: lista de parámetros o {'parameters': [...]}")
    for rec in records:
        pid = rec.get("id")
        if not isinstance(pid, int) or not 1 <= pid <= 39:
            raise ImportFailed(f"id de parámetro fuera de 1..39: {pid}")
        if not (rec.get("source") or source):
            raise ImportFailed("--source es obligatorio")
        rec.setdefault("source", source)
    target = os.path.join(data_dir, "parameters.json")
    base = load_json(target, {"meta": {}, "parameters": []})
    by_id = {p["id"]: p for p in base["parameters"]}
    for rec in records:
        merged = dict(by_id.get(rec["id"], {}))
        for key, val in rec.items():
            if isinstance(val, dict) and isinstance(merged.get(key), dict):
                merged[key] = {**merged[key], **val}
            else:
                merged[key] = val
        by_id[rec["id"]] = merged
    base["parameters"] = [by_id[k] for k in sorted(by_id)]
    save_json(target, base)
    return len(records)


def status_report(kb: TrizKnowledge = None) -> str:
    kb = kb or TrizKnowledge()
    cov = kb.matrix.coverage()
    lines = ["== SIADDI — estado de los datos ==",
             f"Matriz: estado={cov['status']} celdas con datos={cov['filled']} vacías={cov['empty']} "
             f"fuente={cov['source'] or '—'}",
             f"Parámetros cargados: {len(kb.parameters.items)}/39 · Principios cargados: {len(kb.principles.items)}/40",
             "", f"Cobertura por principio (secciones de A27.2, total {len(SECTIONS)}):"]
    for pid, (done, total) in kb.principles.coverage_report("es").items():
        lines.append(f"  P{pid:02d}: {done}/{total}")
    missing = kb.parameters.missing_report()
    lines.append("")
    lines.append(f"Parámetros con datos faltantes: {len(missing)}")
    for pid, gaps in list(missing.items())[:39]:
        lines.append(f"  [{pid}] falta: {', '.join(gaps)}")
    terms = kb.glossary.get("terms", [])
    lines.append("")
    lines.append("Glosario: " + ", ".join(f"{t['term_id']}={t.get('status')}" for t in terms))
    return "\n".join(lines)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="setup_data.py conceptual_design")
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("import-matrix", "import-principles", "import-parameters"):
        s = sub.add_parser(name)
        s.add_argument("file")
        s.add_argument("--source", required=True)
    sub.add_parser("status")
    args = p.parse_args(argv)
    try:
        if args.cmd == "import-matrix":
            print(json.dumps(import_matrix(args.file, args.source), ensure_ascii=False))
        elif args.cmd == "import-principles":
            print(f"principios importados: {import_principles(args.file, args.source)}")
        elif args.cmd == "import-parameters":
            print(f"parámetros importados: {import_parameters(args.file, args.source)}")
        else:
            print(status_report())
    except (ImportFailed, ValueError, FileNotFoundError) as exc:
        print(f"ERROR: {exc} — no se escribió nada")
        return 1
    return 0
