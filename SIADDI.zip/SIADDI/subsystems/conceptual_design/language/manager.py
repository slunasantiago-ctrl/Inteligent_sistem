"""Gestor de idioma del subsistema 1: reutiliza el traductor común de la plataforma (A4)."""
from __future__ import annotations

import os

from isppr_platform.i18n import Translator

LOCALES = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "locales")

_translator = None


def translator() -> Translator:
    global _translator
    if _translator is None:
        _translator = Translator(LOCALES)
    return _translator
