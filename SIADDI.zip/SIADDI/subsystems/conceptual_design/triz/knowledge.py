"""Base de conocimiento TRIZ del subsistema 1 (A16, A17, A26.11)."""
from __future__ import annotations

import os

from isppr_platform.datastore import DataMode, load_json

from .contradiction_matrix import ContradictionMatrix
from .parameters import ParameterBase
from .principles import PrincipleBase

SUB_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class TrizKnowledge:
    def __init__(self, mode: DataMode = None, root: str = None):
        self.mode = mode or DataMode()
        self.root = root or SUB_ROOT
        d = self.mode.data_dir(self.root)
        self.data_dir = d
        glossary = load_json(os.path.join(d, "glossary.json"), {"terms": []})
        self.glossary = glossary
        self.parameters = ParameterBase(load_json(os.path.join(d, "parameters.json"), {"parameters": []}))
        self.principles = PrincipleBase(load_json(os.path.join(d, "principles.json"), {"principles": []}), glossary)
        self.matrix = ContradictionMatrix(load_json(os.path.join(d, "contradiction_matrix.json"), {"cells": {}}))
        self.concepts = load_json(os.path.join(d, "concepts.json"), {"concepts": []})
        self.markers = load_json(os.path.join(d, "markers.json"), {})
        self.eval_sentences = load_json(os.path.join(d, "evaluation_sentences.json"), {"sentences": []})
        # glosario aplicado a parámetros
        for term in glossary.get("terms", []):
            tgt = term.get("target", {})
            if tgt.get("kind") == "parameter":
                p = self.parameters.get(tgt.get("id"))
                if p:
                    for lang, val in term.get("values", {}).items():
                        p.setdefault("names", {})
                        if not p["names"].get(lang):
                            p["names"][lang] = val

    @property
    def is_demo(self) -> bool:
        return self.mode.demo

    def validate(self):
        return self.parameters.validate() + self.principles.validate()
