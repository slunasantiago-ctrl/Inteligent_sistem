"""Los 40 principios inventivos con contenido enriquecido (A16, A27.3, A27.9).

Carga y valida; no genera contenido. Lo que falte se informa como faltante (A27.4).
"""
from __future__ import annotations

from isppr_platform.i18n import pick

N_PRINCIPLES = 40
SECTIONS = ("names", "definition", "relation", "examples", "asit_bridge",
            "industry_examples", "contradictions_solved", "frequency", "guiding_questions")


class PrincipleBase:
    def __init__(self, data: dict, glossary: dict = None):
        self.meta = data.get("meta", {})
        self.items = {int(p["id"]): p for p in data.get("principles", [])}
        self.industries = self.meta.get("industries", [])
        self.glossary_status = {}
        for term in (glossary or {}).get("terms", []):
            tgt = term.get("target", {})
            if tgt.get("kind") == "principle" and int(tgt.get("id", 0)) in self.items:
                p = self.items[int(tgt["id"])]
                field = tgt.get("field", "names")
                p.setdefault(field, {})
                for lang, val in term.get("values", {}).items():
                    if not pick(p[field], lang):
                        p[field][lang] = val
                self.glossary_status[int(tgt["id"])] = term.get("status", "provisional")

    def get(self, pid: int):
        return self.items.get(int(pid))

    def name(self, pid: int, lang: str):
        p = self.get(pid)
        return pick(p.get("names"), lang) if p else None

    def is_provisional_name(self, pid: int) -> bool:
        return self.glossary_status.get(int(pid)) == "provisional"

    def section_available(self, p: dict, section: str, lang: str) -> bool:
        if section == "relation":
            return True  # se genera de forma determinista con plantillas (A27.6)
        if section == "names":
            return bool(pick(p.get("names"), lang))
        if section == "frequency":
            return bool(p.get("frequency") and p["frequency"].get("instance_count") is not None)
        if section == "asit_bridge":
            b = p.get("asit_bridge") or {}
            return bool(pick(b.get("tool"), lang))
        if section == "industry_examples":
            return any(pick(v, lang) for v in (p.get("industry_examples") or {}).values())
        if section == "contradictions_solved":
            return bool(p.get("contradictions_solved"))
        value = p.get(section)
        return bool(pick(value, lang)) if isinstance(value, dict) else bool(value)

    def completeness(self, pid: int, lang: str):
        p = self.get(pid)
        if not p:
            return 0, len(SECTIONS)
        n = sum(1 for s in SECTIONS if self.section_available(p, s, lang))
        return n, len(SECTIONS)

    def coverage_report(self, lang: str = "es"):
        return {pid: self.completeness(pid, lang) for pid in sorted(self.items)}

    def validate(self):
        errors = []
        for pid, p in self.items.items():
            if pid < 1 or pid > N_PRINCIPLES:
                errors.append(f"principle_id_out_of_range:{pid}")
            if not p.get("source") and not self.meta.get("source"):
                errors.append(f"principle_{pid}_without_source")
            for c in p.get("contradictions_solved") or []:
                for key in ("improving", "preserving"):
                    v = c.get(key)
                    if not isinstance(v, int) or v < 1 or v > 39:
                        errors.append(f"principle_{pid}_contradiction_param_out_of_range:{v}")
        return errors
