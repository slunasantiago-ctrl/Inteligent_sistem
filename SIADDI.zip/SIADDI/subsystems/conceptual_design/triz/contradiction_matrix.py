"""Matriz de contradicciones 39×39 (A9, A16, A26.11.1).

Solo recupera lo que está cargado. Nunca completa celdas por su cuenta (A17).
"""
from __future__ import annotations

import csv
import io as _io

STATUSES = ("empty", "partial", "complete")


class ContradictionMatrix:
    def __init__(self, data: dict):
        self.meta = data.get("meta", {})
        self.cells = {}
        for key, values in (data.get("cells") or {}).items():
            a, b = key.lower().split("x")
            self.cells[(int(a), int(b))] = [int(v) for v in values]

    @property
    def status(self) -> str:
        return self.meta.get("matrix_status", "empty")

    @property
    def source(self):
        return self.meta.get("source")

    def lookup(self, improving: int, worsening: int):
        """Principios de la celda, o None si la celda no está cargada."""
        return self.cells.get((int(improving), int(worsening)))

    def coverage(self):
        filled = sum(1 for v in self.cells.values() if v)
        return {"filled": filled, "empty": 39 * 39 - 39 - filled, "status": self.status, "source": self.source}

    def to_json(self):
        return {"meta": self.meta, "cells": {f"{a}x{b}": v for (a, b), v in sorted(self.cells.items())}}


class MatrixImportError(ValueError):
    pass


def parse_matrix_csv(text: str):
    """Valida y convierte el CSV de A26.11.1. Lanza MatrixImportError con el motivo.

    Filas = parámetro que mejora (1..39), columnas = parámetro que empeora (1..39).
    Se acepta una fila y una columna de encabezado opcionales.
    """
    sample = text[:2048]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=";,\t")
    except csv.Error:
        dialect = csv.excel
    # una fila con todas las celdas vacías es válida (matriz parcial); solo se descartan líneas en blanco
    rows = [r for r in csv.reader(_io.StringIO(text), dialect) if len(r) > 1 or (r and r[0].strip())]
    if not rows or not any(c.strip() for r in rows for c in r):
        raise MatrixImportError("empty_file")
    # quitar encabezados si existen
    def is_header_row(r):
        cells = [c.strip() for c in r]
        return cells and (cells[0] == "" or not cells[0].replace(" ", "").isdigit()) and len(r) >= 40
    if len(rows) == 40 and is_header_row(rows[0]):
        rows = rows[1:]
    if len(rows) != 39:
        raise MatrixImportError(f"expected_39_rows:{len(rows)}")
    if all(len(r) == 40 for r in rows):
        rows = [r[1:] for r in rows]
    cells = {}
    for i, row in enumerate(rows, start=1):
        if len(row) != 39:
            raise MatrixImportError(f"row_{i}_expected_39_columns:{len(row)}")
        for j, raw in enumerate(row, start=1):
            raw = raw.strip()
            if raw in ("", "-", "—"):
                continue
            parts = raw.replace(",", " ").split()
            try:
                values = [int(p) for p in parts]
            except ValueError:
                raise MatrixImportError(f"cell_{i}x{j}_not_numeric:{raw}")
            if any(v < 1 or v > 40 for v in values):
                raise MatrixImportError(f"cell_{i}x{j}_principle_out_of_range:{raw}")
            if len(set(values)) != len(values):
                raise MatrixImportError(f"cell_{i}x{j}_duplicate_principle:{raw}")
            cells[(i, j)] = values
    filled = len(cells)
    status = "complete" if filled >= 39 * 39 - 39 else ("partial" if filled else "empty")
    return cells, status
