"""Los 39 parámetros de ingeniería (A5, A16). Motor TRIZ: sin idioma, IDs estables."""
from __future__ import annotations

from isppr_platform.i18n import pick

N_PARAMETERS = 39


class ParameterBase:
    def __init__(self, data: dict):
        self.meta = data.get("meta", {})
        self.items = {int(p["id"]): p for p in data.get("parameters", [])}

    def validate(self):
        errors = []
        ids = sorted(self.items)
        if ids and (ids[0] < 1 or ids[-1] > N_PARAMETERS):
            errors.append("parameter_id_out_of_range")
        for pid, p in self.items.items():
            if not p.get("source") and not self.meta.get("source"):
                errors.append(f"parameter_{pid}_without_source")
        return errors

    def get(self, pid: int):
        return self.items.get(int(pid))

    def name(self, pid: int, lang: str):
        p = self.get(pid)
        return pick(p.get("names"), lang) if p else None

    def description(self, pid: int, lang: str):
        p = self.get(pid)
        return pick(p.get("descriptions"), lang) if p else None

    def missing_report(self):
        """Qué parámetros carecen de descripción, sinónimos o ejemplos por idioma (A26.11.4)."""
        report = {}
        for pid, p in sorted(self.items.items()):
            gaps = []
            for lang in ("es", "en", "ru"):
                if not pick(p.get("descriptions"), lang):
                    gaps.append(f"description:{lang}")
                if not (p.get("synonyms") or {}).get(lang):
                    gaps.append(f"synonyms:{lang}")
                if not (p.get("examples") or {}).get(lang):
                    gaps.append(f"examples:{lang}")
            if gaps:
                report[pid] = gaps
        return report
