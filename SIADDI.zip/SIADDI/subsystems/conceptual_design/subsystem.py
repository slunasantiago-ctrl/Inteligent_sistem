"""Adaptador del subsistema 1 a la plataforma (A26.8, A26.9)."""
from __future__ import annotations

from isppr_platform.subsystem import Subsystem


class ConceptualDesignSubsystem(Subsystem):
    id = "conceptual_design"
    name = "Diseño conceptual (TRIZ)"
    status = "active"

    def run(self, session, io) -> str:
        from .interface.cli import SiaddiCLI
        return SiaddiCLI(session, io).run()
