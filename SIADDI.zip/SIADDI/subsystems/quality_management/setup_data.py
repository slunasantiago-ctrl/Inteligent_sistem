"""Carga y verificación de datos del subsistema 2 — SIADEC (B37).

Uso (desde la raíz):
    python3 setup_data.py quality_management import-lines archivo.json --source "..."
    python3 setup_data.py quality_management import-iso9001 archivo.json --edition iso9001_2015 --source "..."
    python3 setup_data.py quality_management import-catalog archivo.json --source "..."
    python3 setup_data.py quality_management import-advice archivo.json --source "..."
    python3 setup_data.py quality_management import-concepts archivo.json --source "..."
    python3 setup_data.py quality_management import-glossary archivo.json --source "..."
    python3 setup_data.py quality_management status
Valida formato, IDs únicos, referencias cruzadas y source. Si falla, no se escribe nada.
"""
from __future__ import annotations

import argparse
import os

from isppr_platform.datastore import load_json, save_json

from .standardization.knowledge import SUB_ROOT, QualityKnowledge

DATA = os.path.join(SUB_ROOT, "data")
MAX_TEXT = 600   # B30: ningún texto largo que pueda ser reproducción de una norma


class ImportFailed(Exception):
    pass


def _records(path, key):
    data = load_json(path)
    recs = data.get(key, data) if isinstance(data, dict) else data
    if not isinstance(recs, list):
        raise ImportFailed(f"formato: lista o {{'{key}': [...]}}")
    return recs


def _unique(recs, key):
    ids = [r.get(key) for r in recs]
    if None in ids:
        raise ImportFailed(f"falta '{key}'")
    if len(ids) != len(set(ids)):
        raise ImportFailed(f"'{key}' duplicado")


def _need_source(recs, source):
    for r in recs:
        r.setdefault("source", source)
        if not r.get("source"):
            raise ImportFailed("--source es obligatorio")


def import_lines(path, source, data_dir=DATA):
    recs = _records(path, "lines")
    _unique(recs, "line_id")
    _need_source(recs, source)
    target = os.path.join(data_dir, "standardization_matrix.json")
    base = load_json(target, {"meta": {}, "lines": []})
    by = {x["line_id"]: x for x in base["lines"]}
    for r in recs:
        r.setdefault("status", "approved")
        by[r["line_id"]] = {**by.get(r["line_id"], {}), **r}
    base["lines"] = [by[k] for k in sorted(by)]
    save_json(target, base)
    return len(recs)


def import_iso9001(path, edition, source, data_dir=DATA):
    if not edition:
        raise ImportFailed("--edition es obligatorio")
    recs = _records(path, "clauses")
    _unique(recs, "clause_id")
    for r in recs:
        for v in (r.get("title") or {}).values():
            if v and len(v) > MAX_TEXT:
                raise ImportFailed(f"cláusula {r['clause_id']}: título demasiado largo (B30)")
    save_json(os.path.join(data_dir, "iso9001", f"clauses_{edition}.json"),
              {"edition_id": edition, "status": "approved", "source": source, "clauses": recs})
    eds_path = os.path.join(data_dir, "iso9001", "editions.json")
    eds = load_json(eds_path, {"editions": []})
    for e in eds["editions"]:
        if e["edition_id"] == edition:
            e["has_structure"] = True
    save_json(eds_path, eds)
    return len(recs)


def import_catalog(path, source, data_dir=DATA):
    recs = _records(path, "standards")
    _unique(recs, "standard_id")
    for s in recs:
        if s.get("level") not in ("N1", "N2", "N3", "N4"):
            raise ImportFailed(f"{s['standard_id']}: nivel inválido")
        for r in s.get("rules", []):
            r.setdefault("source", source)
            if not r.get("source"):
                raise ImportFailed(f"{s['standard_id']}: regla sin source")
            if "applies_when" not in r:
                raise ImportFailed(f"{s['standard_id']}: regla sin applies_when")
    target = os.path.join(data_dir, "standards_catalog.json")
    base = load_json(target, {"meta": {}, "standards": []})
    by = {x["standard_id"]: x for x in base["standards"]}
    for s in recs:
        by[s["standard_id"]] = s
    base["standards"] = list(by.values())
    save_json(target, base)
    return len(recs)


def import_advice(path, source, data_dir=DATA):
    recs = _records(path, "advice")
    _unique(recs, "advice_id")
    kb = QualityKnowledge(root=os.path.dirname(data_dir) if data_dir != DATA else None)
    for a in recs:
        a.setdefault("source", source)
        if not a.get("source"):
            raise ImportFailed(f"{a['advice_id']}: sin source")
        if a.get("status") not in ("draft", "approved"):
            raise ImportFailed(f"{a['advice_id']}: estado inválido (draft|approved)")
        clause_ids = a.get("clause_ids") or {}
        if not clause_ids:
            raise ImportFailed(f"{a['advice_id']}: sin cláusulas")
        for ed, cl in clause_ids.items():
            if ed not in kb.clauses:
                raise ImportFailed(f"{a['advice_id']}: edición sin estructura cargada: {ed}")
            bad = [c for c in cl if c not in kb.clauses[ed]]
            if bad:
                raise ImportFailed(f"{a['advice_id']}: cláusulas inexistentes en {ed}: {bad}")
        for v in (a.get("action") or {}).values():
            if v and len(v) > MAX_TEXT:
                raise ImportFailed(f"{a['advice_id']}: texto demasiado largo (B30)")
    target = os.path.join(data_dir, "advice_library.json")
    base = load_json(target, {"advice": []})
    by = {x["advice_id"]: x for x in base["advice"]}
    for a in recs:
        by[a["advice_id"]] = a
    base["advice"] = list(by.values())
    save_json(target, base)
    return len(recs)


def import_simple(path, source, filename, key, idkey, data_dir=DATA):
    recs = _records(path, key)
    _unique(recs, idkey)
    _need_source(recs, source)
    target = os.path.join(data_dir, filename)
    base = load_json(target, {key: []})
    by = {x[idkey]: x for x in base.get(key, [])}
    for r in recs:
        by[r[idkey]] = r
    base[key] = list(by.values())
    save_json(target, base)
    return len(recs)


def status_report(kb=None):
    kb = kb or QualityKnowledge()
    lines = ["== SIADEC — estado de los datos ==",
             f"Líneas de la matriz: {sorted(kb.lines)} (fuente: {kb.matrix_meta.get('source')})"]
    for e in kb.editions:
        lines.append(f"Edición {e['designation']}: estado={e['status']} verificada={e.get('verified_on')} "
                     f"estructura={'sí' if kb.has_structure(e['edition_id']) else 'no'}")
    levels = {}
    for s in kb.catalog.get("standards", []):
        st = [r.get("status") for r in s.get("rules", [])]
        levels.setdefault(s.get("level"), []).append(f"{s['designation']}({'/'.join(st) or 'sin reglas'})")
    for lvl in sorted(levels):
        lines.append(f"Catálogo {lvl}: " + ", ".join(levels[lvl]))
    if "N4" not in levels:
        lines.append("Catálogo N4: sin normas técnicas por categoría (pendiente, B37 punto 4)")
    approved = [a for a in kb.advice if a.get("status") == "approved"]
    draft = [a for a in kb.advice if a.get("status") == "draft"]
    lines.append(f"Consejos: aprobados={len(approved)} borrador={len(draft)}")
    for ed in kb.clauses:
        covered = set()
        for a in approved:
            covered |= set((a.get("clause_ids") or {}).get(ed, []))
        miss = [c for c in kb.level2_clauses(ed) if c not in covered]
        lines.append(f"Cláusulas de {ed} sin consejo aprobado: {', '.join(miss) or 'ninguna'}")
    pending = []
    for ln in kb.lines.values():
        for lang in ("es", "en", "ru"):
            if not (ln.get("text") or {}).get(lang):
                pending.append(f"línea {ln['line_id']}:{lang}")
    lines.append("Traducciones pendientes: " + (", ".join(pending) or "ninguna"))
    errs = kb.validate()
    lines.append("Validación: " + ("OK" if not errs else "; ".join(errs)))
    return "\n".join(lines)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="setup_data.py quality_management")
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("import-lines", "import-catalog", "import-advice", "import-concepts", "import-glossary"):
        s = sub.add_parser(name)
        s.add_argument("file")
        s.add_argument("--source", required=True)
    s = sub.add_parser("import-iso9001")
    s.add_argument("file")
    s.add_argument("--edition", required=True)
    s.add_argument("--source", required=True)
    sub.add_parser("status")
    a = p.parse_args(argv)
    try:
        if a.cmd == "import-lines":
            n = import_lines(a.file, a.source)
        elif a.cmd == "import-iso9001":
            n = import_iso9001(a.file, a.edition, a.source)
        elif a.cmd == "import-catalog":
            n = import_catalog(a.file, a.source)
        elif a.cmd == "import-advice":
            n = import_advice(a.file, a.source)
        elif a.cmd == "import-concepts":
            n = import_simple(a.file, a.source, "concepts.json", "concepts", "concept_id")
        elif a.cmd == "import-glossary":
            n = import_simple(a.file, a.source, "glossary.json", "terms", "term_id")
        else:
            print(status_report())
            return 0
        print(f"registros importados: {n}")
    except (ImportFailed, ValueError, FileNotFoundError) as exc:
        print(f"ERROR: {exc} — no se escribió nada")
        return 1
    return 0
