import unittest

from tests import _helpers  # noqa: F401
from isppr_platform.datastore import DataMode
from subsystems.quality_management.core.product_profile import extract_profile, guess_goal
from subsystems.quality_management.standardization import catalog
from subsystems.quality_management.standardization.knowledge import QualityKnowledge


class CatalogTests(unittest.TestCase):
    def test_three_verdicts(self):
        rule = {"rule_id": "r", "requires_profile_fields": [],
                "applies_when": {"all": [{"field": "role", "in": ["manufactures"]}]}}
        self.assertEqual(catalog.evaluate_rule(rule, {"role": "manufactures"})["verdict"], catalog.APPLIES)
        self.assertEqual(catalog.evaluate_rule(rule, {"role": "distributes"})["verdict"], catalog.NOT_APPLIES)
        self.assertEqual(catalog.evaluate_rule(rule, {"role": None})["verdict"], catalog.POSSIBLE)

    def test_normal_mode_hides_drafts(self):
        kb = QualityKnowledge(DataMode())
        prof = extract_profile(kb, "Fabricamos sillas de oficina y queremos certificarnos")
        results, _ = catalog.recommend(kb, prof.as_rule_input("certification"))
        self.assertEqual(results, [])

    def test_draft_mode_recommends_iso9001(self):
        kb = QualityKnowledge(DataMode(draft=True))
        prof = extract_profile(kb, "Fabricamos sillas de oficina con proveedores de componentes y queremos certificarnos")
        self.assertEqual(prof.role, "manufactures")
        self.assertEqual(prof.critical_suppliers, "yes")
        results, _ = catalog.recommend(kb, prof.as_rule_input("certification"))
        first = results[0]
        self.assertEqual(first["standard"]["standard_id"], "iso_9001")
        self.assertEqual(first["evaluation"]["verdict"], catalog.APPLIES)

    def test_goal_from_problem_text(self):
        kb = QualityKnowledge(DataMode(draft=True))
        self.assertIsNotNone(guess_goal(kb, "queremos obtener la certificación ISO 9001"))

    def test_data_validates(self):
        kb = QualityKnowledge(DataMode(draft=True))
        self.assertEqual(kb.validate() if hasattr(kb, "validate") else [], [])


if __name__ == "__main__":
    unittest.main()
