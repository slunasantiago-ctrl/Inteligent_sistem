"""Adaptador del subsistema 2 — SIADEC — a la plataforma (B26)."""
from __future__ import annotations

from isppr_platform.subsystem import Subsystem


class QualityManagementSubsystem(Subsystem):
    id = "quality_management"
    name = "Управление качеством продукции"
    status = "active"

    def run(self, session, io) -> str:
        from .interface.cli import SiadecCLI
        return SiadecCLI(session, io).run()
