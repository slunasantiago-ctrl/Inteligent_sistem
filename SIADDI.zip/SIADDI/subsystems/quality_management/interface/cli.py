"""Interfaz de terminal del subsistema 2 — SIADEC (B7–B11, B21, B22, B26–B30).

Solo presenta y pregunta. Las recomendaciones salen del motor determinista
(standardization/) y todos los textos de interfaz de locales/*.json.
"""
from __future__ import annotations

import datetime as dt
import os

from isppr_platform import exchange, language_select, terminal
from isppr_platform.datastore import DataMode, save_json
from isppr_platform.dialog import Dialog
from isppr_platform.i18n import number, pick
from isppr_platform.subsystem import RESULT_MENU, ReturnToMenu

from ..core import line_analysis
from ..core.evaluation import SCALE, Criterion
from ..core.product_profile import extract_profile, guess_goal
from ..core.quality_plan import DECISIONS, build_plan, plan_by_section
from ..core.session import QualityState
from ..language.manager import translator
from ..standardization import advice_library, catalog
from ..standardization.knowledge import SUB_ROOT, QualityKnowledge

SUBSYSTEM_ID = "quality_management"
HEADER = ("SIADEC", "Sistema Inteligente de Apoyo a Decisiones", "de Estandarización y Calidad del Producto")
OUTPUT_DIR = os.path.join(SUB_ROOT, "output")
SUBSYSTEM_VERSION = "2.0"
MAX_QUOTE = 120   # B30: límite corto de cita literal (no se reproducen normas)


class SiadecCLI:
    def __init__(self, session, io, kb: QualityKnowledge = None):
        self.session = session
        self.io = io
        self.kb = kb or QualityKnowledge(DataMode(session.demo, session.draft))
        self.dlg = Dialog(io, session, translator())
        self.state = session.state_for(SUBSYSTEM_ID, QualityState)
        if not self.state.edition_id:
            ed = self.kb.default_edition()
            self.state.edition_id = ed["edition_id"] if ed else None

    # ------------------------------------------------------------- helpers
    def t(self, key, **kw):
        return self.dlg.t(key, **kw)

    @property
    def lang(self):
        return self.dlg.lang

    def txt(self, texts):
        v = pick(texts, self.lang)
        return v if v else self.t("translation_pending_text")

    def list_name(self, list_key, item_id):
        for it in self.kb.profile_lists.get(list_key, []):
            if it["id"] == item_id:
                return pick(it["names"], self.lang) or item_id
        return self.t("not_declared") if item_id in (None, "") else item_id

    def labelled(self, who, text):
        key = {"student": "label_student", "system": "label_system", "decision": "label_decision"}[who]
        self.dlg.say(terminal.style(f"[{self.t(key)}]", "accent2") + " " + text)

    def item_label(self, item):
        lab = self.kb.label(item)
        if lab == "DEMO":
            return terminal.style(" [DEMO]", "warn")
        if lab == "draft":
            return terminal.style(" [" + self.t("draft_label") + "]", "warn")
        return ""

    def demo_notice(self):
        if self.kb.is_demo:
            self.dlg.warn(self.t("demo_notice"))
        elif self.session.draft:
            self.dlg.warn(self.t("draft_notice"))

    def edition(self):
        return self.kb.edition(self.state.edition_id) if self.state.edition_id else None

    def edition_line(self):
        ed = self.edition()
        if not ed:
            return self.t("no_edition")
        return self.t("edition_line", designation=ed["designation"], status=self.t("edstatus_" + ed["status"]),
                      date=ed.get("verified_on") or "—")

    def clause_label(self, cid):
        title = self.kb.clause_title(self.state.edition_id, cid, self.lang)
        if title is None and self.kb.has_structure(self.state.edition_id):
            title = self.t("translation_pending_text")
        return f"{cid} {title}" if title else cid

    # ------------------------------------------------------------- flujo
    def run(self) -> str:
        if not self.session.language:
            self.session.language = language_select.select_language(self.io, HEADER)
        try:
            if self.state.stage > 1:
                self.dlg.title(self.t("resume_title"))
                self.dlg.option("1", self.t("resume_continue", stage=self.state.stage))
                self.dlg.option("2", self.t("resume_new"))
                if self.dlg.choose(["1", "2"]) == "2":
                    self.reset()
            stages = {1: self.stage1, 2: self.stage2, 3: self.stage3, 4: self.stage4, 5: self.stage5, 6: self.stage6}
            while self.state.stage in stages:
                stages[self.state.stage]()
            return RESULT_MENU
        except ReturnToMenu:
            return RESULT_MENU

    def reset(self):
        self.session.subsystem_states[SUBSYSTEM_ID] = QualityState()
        self.state = self.session.subsystem_states[SUBSYSTEM_ID]
        ed = self.kb.default_edition()
        self.state.edition_id = ed["edition_id"] if ed else None

    # ETAPA 1 -------------------------------------------------------------
    def stage1(self):
        self.dlg.title(self.t("stage1_title"))
        self.dlg.hint_globals()
        self.dlg.note(self.t("stage1_help"))
        self.state.context = self.dlg.ask_text("describe_context")
        self.state.profile = extract_profile(self.kb, self.state.context)
        self.edit_profile()
        self.state.stage = 2

    def show_profile(self):
        p = self.state.profile
        self.dlg.section(self.t("profile_title"))
        rows = [
            ("1", "f_product", p.product or self.t("not_declared")),
            ("2", "f_category", self.list_name("categories", p.category_id)),
            ("3", "f_sector", self.list_name("sectors", p.sector_id)),
            ("4", "f_role", self.list_name("roles", p.role)),
            ("5", "f_lifecycle", ", ".join(self.list_name("lifecycle", x) for x in p.lifecycle_ids) or self.t("not_declared")),
            ("6", "f_markets", p.markets_legal or self.t("not_declared")),
            ("7", "f_qms_state", self.list_name("qms_state", p.qms_state)),
            ("8", "f_suppliers", self.t("sup_" + (p.critical_suppliers or "unknown"))),
        ]
        fmap = {"2": "category_id", "3": "sector_id", "4": "role", "5": "lifecycle_ids", "7": "qms_state", "8": "critical_suppliers"}
        for key, label, value in rows:
            mark = terminal.style(" (" + self.t("proposed") + ")", "muted") if fmap.get(key) in p.proposed_by_system else ""
            self.dlg.say(f"  [{terminal.style(key, 'accent')}] {self.t(label)}: {value}{mark}")
        self.dlg.note(self.t("profile_lists_notice"))

    def pick_from_list(self, list_key, multi=False):
        items = self.kb.profile_lists.get(list_key, [])
        for i, it in enumerate(items, start=1):
            self.dlg.option(str(i), pick(it["names"], self.lang) or it["id"])
        if multi:
            nums = self.dlg.ask_int_list("ask_numbers_multi", 1, len(items))
            return [items[n - 1]["id"] for n in nums]
        n = self.dlg.ask_int("ask_number", 1, len(items))
        return items[n - 1]["id"]

    def edit_profile(self):
        p = self.state.profile
        while True:
            self.show_profile()
            self.dlg.say(self.t("edit_profile_prompt"))
            ch = self.dlg.choose(["1", "2", "3", "4", "5", "6", "7", "8"], allow_empty=True)
            if not ch:
                p.proposed_by_system = [f for f in p.proposed_by_system]
                self.state.decisions.append([1, "dec_profile_confirmed", {}])
                return
            field = {"2": "category_id", "3": "sector_id", "4": "role", "5": "lifecycle_ids", "7": "qms_state", "8": "critical_suppliers"}.get(ch)
            if ch == "1":
                p.product = self.dlg.ask_text("ask_product_name")
            elif ch == "6":
                p.markets_legal = self.dlg.ask_text("ask_markets")
            elif ch == "2":
                p.category_id = self.pick_from_list("categories")
            elif ch == "3":
                p.sector_id = self.pick_from_list("sectors")
            elif ch == "4":
                p.role = self.pick_from_list("roles")
            elif ch == "5":
                p.lifecycle_ids = [x for x in self.pick_from_list("lifecycle", multi=True) if x != "unspecified"]
            elif ch == "7":
                p.qms_state = self.pick_from_list("qms_state")
            elif ch == "8":
                for i, k in enumerate(("yes", "no", "unknown"), start=1):
                    self.dlg.option(str(i), self.t("sup_" + k))
                p.critical_suppliers = ("yes", "no", "unknown")[self.dlg.ask_int("ask_number", 1, 3) - 1]
            if field and field in p.proposed_by_system:
                p.proposed_by_system.remove(field)

    # ETAPA 2 -------------------------------------------------------------
    def stage2(self):
        self.dlg.title(self.t("stage2_title"))
        self.state.problem = self.dlg.ask_text("describe_problem")
        self.state.stage = 3

    # ETAPA 3 -------------------------------------------------------------
    def line_title(self, ln):
        line = self.kb.lines.get(ln)
        return f"[{ln}] {self.txt(line.get('central_object'))}" if line else str(ln)

    def theme_title(self, th):
        t = self.kb.themes.get(th)
        return pick(t["names"], self.lang) if t else th

    def stage3(self):
        self.dlg.title(self.t("stage3_title"))
        interp = line_analysis.interpret(self.kb, self.state.context, self.state.problem)
        self.state.interpretation = interp
        self.labelled("student", f"«{self.state.problem}»")
        self.labelled("system", self.t("hypothesis_note"))
        if not interp.lines and not interp.themes:
            self.dlg.warn(self.t("no_candidates"))
        self.dlg.section(self.t("lines_label"))
        for i, (ln, score) in enumerate(interp.lines[:4]):
            role = self.t("principal") if i == 0 else self.t("secondary")
            self.dlg.say(f"  {self.line_title(ln)} — {role} ({number(score, self.lang, 1)})")
        self.dlg.section(self.t("themes_label"))
        for th, score in interp.themes[:5]:
            clauses = ", ".join(self.kb.theme_clauses(th, self.state.edition_id))
            self.dlg.say(f"  {self.theme_title(th)} — {self.t('clauses')}: {clauses or '—'} ({number(score, self.lang, 1)})")
        p = self.state.profile
        self.dlg.say(f"  {self.t('f_lifecycle')}: " + (", ".join(self.list_name('lifecycle', x) for x in p.lifecycle_ids) or self.t("not_declared")))
        self.dlg.say(f"  {self.t('object_label')}: {self.t('object_' + self.guess_object())}")
        self.dlg.say(f"  {self.t('confidence')}: {number(interp.confidence, self.lang)} ({self.t('level_' + interp.level)})")
        if interp.ambiguous:
            self.dlg.warn(self.t("ambiguous_notice"))
        self.state.decision.lines = [ln for ln, _ in interp.lines[:2]]
        self.state.decision.themes = [th for th, _ in interp.themes[:4]]
        while True:
            self.dlg.blank()
            self.dlg.option("c", self.t("opt_confirm"))
            self.dlg.option("l", self.t("opt_edit_lines"))
            self.dlg.option("t", self.t("opt_edit_themes"))
            self.dlg.option("?", self.t("opt_why"))
            ch = self.dlg.choose(["c", "l", "t", "?"])
            if ch == "?":
                for key, concepts in sorted(interp.evidence.items()):
                    words = sorted({w for c in concepts for w in interp.concepts.get(c, [])})
                    kind, ident = key.split(":")
                    label = self.line_title(int(ident)) if kind == "line" else self.theme_title(ident)
                    self.dlg.bullet(self.t("why_link", target=label, concepts=", ".join(concepts), words=", ".join(words)))
                self.dlg.note(self.t("lexicon_notice"))
                continue
            if ch == "l":
                for ln in sorted(self.kb.lines):
                    self.dlg.say("  " + self.line_title(ln))
                ids = self.dlg.ask_int_list("ask_lines", 1, 99, allow_empty=False)
                self.state.decision.lines = [x for x in ids if x in self.kb.lines] or self.state.decision.lines
                self.state.decisions.append([3, "dec_lines_modified", {}])
                continue
            if ch == "t":
                ths = list(self.kb.themes)
                for i, th in enumerate(ths, start=1):
                    self.dlg.option(str(i), self.theme_title(th))
                nums = self.dlg.ask_int_list("ask_numbers_multi", 1, len(ths), allow_empty=False)
                self.state.decision.themes = [ths[n - 1] for n in nums]
                self.state.decisions.append([3, "dec_themes_modified", {}])
                continue
            self.state.decisions.append([3, "dec_interpretation_confirmed", {}])
            self.state.stage = 4
            return

    def guess_object(self):
        concepts = set((self.state.interpretation.concepts if self.state.interpretation else {}).keys())
        if concepts & {"integrated_ms", "audit", "certification"}:
            return "management_system"
        if concepts & {"production", "supplier", "digital"}:
            return "process"
        return "product"

    # ETAPA 4 -------------------------------------------------------------
    def stage4(self):
        d = self.state.decision
        if not d.decision_goal:
            goals = guess_goal(self.kb, self.state.problem) or guess_goal(self.kb, self.state.context)
            d.decision_goal = goals[0] if goals else None
            d.decision_text = self.state.problem
        while True:
            self.dlg.title(self.t("stage4_title"))
            self.show_profile()
            self.dlg.section(self.t("decision_problem_title"))
            self.dlg.say(f"  [{terminal.style('a', 'accent')}] {self.t('f_decision')}: {d.decision_text}")
            self.dlg.say(f"  [{terminal.style('g', 'accent')}] {self.t('f_goal')}: {self.list_name('decision_goals', d.decision_goal)}")
            self.dlg.say(f"  [{terminal.style('l', 'accent')}] {self.t('lines_confirmed')}: " +
                         "; ".join(("★ " if i == 0 else "") + self.line_title(x) for i, x in enumerate(d.lines)))
            self.dlg.say(f"  [{terminal.style('t', 'accent')}] {self.t('themes_label')}: " + "; ".join(self.theme_title(x) for x in d.themes))
            self.dlg.say(f"  [{terminal.style('r', 'accent')}] {self.t('f_restrictions')}: {d.restrictions or self.t('not_declared')}")
            self.dlg.say(f"  [{terminal.style('e', 'accent')}] {self.t('f_edition')}: {self.edition_line()}")
            self.dlg.note("  " + self.t("criteria_later"))
            for ln in d.lines[:1]:
                line = self.kb.lines.get(ln)
                if line:
                    self.dlg.section(self.t("definition") + " — " + self.line_title(ln))
                    self.dlg.say("  " + self.txt(line.get("text")))
                    self.dlg.say("  " + self.t("relation_template", product=self.state.profile.product or "—",
                                               line=self.txt(line.get("central_object"))))
            self.dlg.blank()
            self.dlg.option("p", self.t("opt_edit_profile"))
            self.dlg.option("c", self.t("opt_confirm_decision"))
            ch = self.dlg.choose(["a", "g", "l", "t", "r", "e", "p", "c"])
            if ch == "a":
                d.decision_text = self.dlg.ask_text("ask_decision_text")
            elif ch == "g":
                d.decision_goal = self.pick_from_list("decision_goals")
            elif ch == "l":
                for ln in sorted(self.kb.lines):
                    self.dlg.say("  " + self.line_title(ln))
                ids = self.dlg.ask_int_list("ask_lines", 1, 99, allow_empty=False)
                d.lines = [x for x in ids if x in self.kb.lines] or d.lines
            elif ch == "t":
                ths = list(self.kb.themes)
                for i, th in enumerate(ths, start=1):
                    self.dlg.option(str(i), self.theme_title(th))
                nums = self.dlg.ask_int_list("ask_numbers_multi", 1, len(ths), allow_empty=False)
                d.themes = [ths[n - 1] for n in nums]
            elif ch == "r":
                d.restrictions = self.dlg.ask_text("ask_restrictions")
            elif ch == "e":
                self.choose_edition()
            elif ch == "p":
                self.edit_profile()
            elif ch == "c":
                if not d.decision_goal:
                    self.dlg.warn(self.t("need_goal"))
                    continue
                d.confirmed = True
                self.state.decisions.append([4, "dec_problem_confirmed", {}])
                self.state.stage = 5
                return

    def choose_edition(self):
        for i, e in enumerate(self.kb.editions, start=1):
            self.dlg.option(str(i), f"{e['designation']} — {self.t('edstatus_' + e['status'])}"
                            + ("" if e.get("has_structure") else " · " + self.t("no_structure")))
        n = self.dlg.ask_int("ask_number", 1, len(self.kb.editions))
        self.state.edition_id = self.kb.editions[n - 1]["edition_id"]
        self.state.decisions.append([4, "dec_edition", {"edition": self.kb.editions[n - 1]["designation"]}])

    # ETAPA 5 -------------------------------------------------------------
    def confirmed_clauses(self):
        out = []
        for th in self.state.decision.themes:
            out += [c for c in self.kb.theme_clauses(th, self.state.edition_id) if c not in out]
        return out

    def compute(self):
        prof = self.state.profile.as_rule_input(self.state.decision.decision_goal)
        recs, _without = catalog.recommend(self.kb, prof)
        self.state.recommendations = recs
        concepts = list((self.state.interpretation.concepts if self.state.interpretation else {}).keys())
        selected = advice_library.select(self.kb.visible_advice(), self.state.edition_id, self.confirmed_clauses(),
                                         concepts, self.state.profile.lifecycle_ids, self.state.profile.to_dict(),
                                         self.state.lifecycle_filter)
        self.state.selected_advice = selected
        self.state.plan = build_plan(self.kb, selected, self.state.edition_id, self.state.plan)

    def stage5(self):
        self.dlg.title(self.t("stage5_title"))
        self.demo_notice()
        ed = self.edition()
        self.dlg.say(self.edition_line())
        self.dlg.warn(self.t("check_validity"))
        if ed and ed.get("transition"):
            self.dlg.note(self.t("transition_notice", text=ed["transition"], source=ed.get("source", "—")))
        if not self.kb.has_structure(self.state.edition_id):
            self.dlg.warn(self.t("no_structure_notice"))
        elif getattr(self.kb, "clauses_status", None) == "reference":
            self.dlg.note(self.t("reference_notice"))
        self.compute()
        self.dlg.section(self.t("consult_matrix"))
        for ln in self.state.decision.lines:
            self.dlg.say("  " + self.line_title(ln))
        self.dlg.section(self.t("consult_iso"))
        for c in self.confirmed_clauses():
            self.dlg.say("  " + self.clause_label(c))
        self.dlg.section(self.t("consult_catalog"))
        n_app = sum(1 for r in self.state.recommendations if r["evaluation"]["verdict"] == catalog.APPLIES)
        n_pos = sum(1 for r in self.state.recommendations if r["evaluation"]["verdict"] == catalog.POSSIBLE)
        if not self.state.recommendations:
            self.dlg.warn(self.t("no_rules_notice"))
        else:
            self.dlg.say("  " + self.t("catalog_summary", applies=n_app, possible=n_pos))
        self.dlg.say("  " + self.t("advice_summary", n=len(self.state.selected_advice)))
        if not self.kb.visible_advice():
            self.dlg.warn(self.t("no_advice_notice"))
        self.dlg.pause()
        self.state.stage = 6
        self.state.view = "menu"

    # ETAPA 6 -------------------------------------------------------------
    def stage6(self):
        views = {"menu": self.view_menu, "standards": self.view_standards, "advice": self.view_advice,
                 "lines": self.view_lines, "plan": self.view_plan, "gaps": self.view_gaps,
                 "questions": self.view_questions, "evaluation": self.view_evaluation, "decision": self.view_decision}
        views.get(self.state.view, self.view_menu)()

    def view_menu(self):
        self.dlg.title(self.t("stage6_title"))
        self.demo_notice()
        self.dlg.say(self.t("summary_line", product=self.state.profile.product or "—",
                            goal=self.list_name("decision_goals", self.state.decision.decision_goal)))
        self.dlg.say(self.edition_line())
        opts = [("1", "view_standards"), ("2", "view_advice"), ("3", "view_plan"), ("4", "view_lines"),
                ("5", "view_gaps"), ("6", "view_questions"), ("7", "view_evaluation"), ("8", "view_decision"),
                ("e", "opt_change_edition"), ("c", "opt_lifecycle_filter")]
        for k, lab in opts:
            self.dlg.option(k, self.t(lab))
        self.dlg.hint_globals()
        ch = self.dlg.choose([k for k, _ in opts])
        mapping = {"1": "standards", "2": "advice", "3": "plan", "4": "lines", "5": "gaps", "6": "questions",
                   "7": "evaluation", "8": "decision"}
        if ch in mapping:
            self.state.view = mapping[ch]
            self.state.index = 0
        elif ch == "e":
            self.choose_edition()
            self.compute()
            self.dlg.ok(self.t("recomputed"))
        elif ch == "c":
            items = self.kb.profile_lists.get("lifecycle", [])
            for i, it in enumerate(items, start=1):
                self.dlg.option(str(i), pick(it["names"], self.lang))
            n = self.dlg.ask_int("ask_number", 1, len(items))
            self.state.lifecycle_filter = items[n - 1]["id"]
            self.compute()
            self.dlg.ok(self.t("recomputed"))

    def nav(self, total, extra=()):
        self.dlg.blank()
        base = [("s", "nav_next"), ("a", "nav_prev"), ("v", "nav_back_views")]
        for k, lab in list(extra) + base:
            self.dlg.option(k, self.t(lab))
        self.dlg.hint_globals()
        ch = self.dlg.choose([k for k, _ in list(extra) + base])
        if ch == "s":
            self.state.index = min(self.state.index + 1, max(0, total - 1))
        elif ch == "a":
            self.state.index = max(self.state.index - 1, 0)
        elif ch == "v":
            self.state.view = "menu"
        return ch

    # -- normas
    def view_standards(self):
        recs = self.state.recommendations
        self.dlg.title(self.t("view_standards"))
        self.demo_notice()
        if not recs:
            self.dlg.warn(self.t("no_rules_notice"))
            self.dlg.say(self.t("search_procedure"))
            self.list_student_standards()
            ch = self.nav(0, [("n", "opt_add_standard")])
            if ch == "n":
                self.add_student_standard()
            return
        i = max(0, min(self.state.index, len(recs) - 1))
        r = recs[i]
        s, ev = r["standard"], r["evaluation"]
        self.dlg.say(terminal.style(f"{s['level']}  {s['designation']} — {self.txt(s.get('title'))}", "title")
                     + f"   ({i + 1}/{len(recs)})" + self.item_label({"status": ev["rule_status"]}))
        self.dlg.say(f"  {self.t('edition_word')}: {s.get('edition') or self.t('not_documented')} · "
                     f"{self.t('status')}: {self.t('edstatus_' + (s.get('status') or 'unverified'))} · "
                     f"{self.t('verified_on')}: {s.get('verified_on') or '—'}")
        verdict_txt = self.t("verdict_" + ev["verdict"])
        self.dlg.say(f"  {self.t('verdict')}: " + terminal.style(verdict_txt, "ok" if ev["verdict"] == "applies" else "warn")
                     + f" — {self.t('rule')} {ev['rule_id']}")
        if ev["matched_fields"]:
            vals = self.state.profile.as_rule_input(self.state.decision.decision_goal)
            self.dlg.say(f"  {self.t('activated_by')}: " + "; ".join(f"{self.t('rf_' + f)} = {self.field_value(f, vals.get(f))}" for f in ev["matched_fields"]))
        if ev["missing_fields"]:
            self.dlg.warn(self.t("missing_fields", fields=", ".join(self.t("rf_" + f) for f in ev["missing_fields"])))
        if ev["failed_conditions"]:
            self.dlg.say(f"  {self.t('failed_condition')}: " + "; ".join(self.t("rf_" + c["field"]) for c in ev["failed_conditions"]))
        self.dlg.say(f"  {self.t('what_it_brings')}: {self.txt(s.get('role'))}")
        self.dlg.say(f"  {self.t('relation_iso')}: {self.txt(s.get('relation_to_iso9001'))}")
        self.dlg.note(f"  {self.t('source_label')}: {ev['rule_source']}")
        mark = self.state.standards_marked.get(s["standard_id"])
        if mark:
            self.labelled("decision", self.t("mark_" + mark))
        self.dlg.note("  " + self.t("not_mandatory_notice"))
        if not any(x["standard"].get("level") == "N4" for x in recs):
            self.dlg.note("  " + self.t("n4_missing", category=self.list_name("categories", self.state.profile.category_id)))
        ch = self.nav(len(recs), [("u", "nav_useful"), ("d", "nav_discard"), ("n", "opt_add_standard"),
                                  ("o", "opt_other_standards"), ("?", "opt_why")])
        if ch == "u":
            self.state.standards_marked[s["standard_id"]] = "useful"
            self.state.decisions.append([6, "dec_std_useful", {"std": s["designation"]}])
        elif ch == "d":
            self.state.standards_marked[s["standard_id"]] = "discarded"
            self.state.decisions.append([6, "dec_std_discard", {"std": s["designation"]}])
        elif ch == "n":
            self.add_student_standard()
        elif ch == "o":
            self.list_student_standards()
            self.dlg.pause()
        elif ch == "?":
            for e in r["all_evaluations"]:
                self.dlg.bullet(f"{e['rule_id']}: {self.t('verdict_' + e['verdict'])}")
            self.dlg.say(self.t("why_standard"))
            self.dlg.pause()

    def field_value(self, field, value):
        lists = {"decision_goal": "decision_goals", "sector_id": "sectors", "category_id": "categories",
                 "role": "roles", "qms_state": "qms_state"}
        if field == "lifecycle_id":
            return ", ".join(self.list_name("lifecycle", x) for x in (value or []))
        if field in lists:
            return self.list_name(lists[field], value)
        return str(value)

    def add_student_standard(self):
        des = self.dlg.ask_text("ask_std_designation")
        title = self.dlg.ask("> " + self.t("ask_std_title") + " ")
        self.state.student_standards.append({"designation": des, "title": title, "verified": False})
        self.state.decisions.append([6, "dec_std_added", {"std": des}])
        self.dlg.ok(self.t("std_added_notice"))

    def list_student_standards(self):
        if self.state.student_standards:
            self.dlg.section(self.t("student_standards"))
            for s in self.state.student_standards:
                self.dlg.bullet(f"{s['designation']} {s['title']} — {self.t('not_verified_by_siadec')}")

    # -- consejos
    def view_advice(self):
        sel = self.state.selected_advice
        self.dlg.title(self.t("view_advice"))
        self.demo_notice()
        self.dlg.note(self.t("lifecycle_filter_line", value=self.list_name("lifecycle", self.state.lifecycle_filter)))
        if not sel:
            self.dlg.warn(self.t("no_advice_notice"))
            self.nav(0)
            return
        i = max(0, min(self.state.index, len(sel) - 1))
        item = sel[i]
        a = item["advice"]
        clauses = a["clause_ids"].get(self.state.edition_id, [])
        ed = self.edition()
        self.dlg.say(terminal.style(" · ".join(self.clause_label(c) for c in clauses) + f" ({ed['designation'] if ed else ''})", "title")
                     + f"   ({i + 1}/{len(sel)})" + self.item_label(a))
        self.dlg.say(f"  {self.t('f_lifecycle')}: " + ", ".join(self.t("all_stages") if x == "all" else self.list_name("lifecycle", x) for x in a.get("lifecycle_ids", [])))
        self.dlg.say(f"  {self.t('action')}: {self.txt(a.get('action'))}")
        self.dlg.say(f"  {self.t('evidence')}: {self.txt(a.get('evidence'))}")
        reasons = []
        for kind, vals in item["reasons"]:
            if kind == "concepts":
                words = sorted({w for c in vals for w in (self.state.interpretation.concepts.get(c, []) if self.state.interpretation else [])})
                reasons.append(self.t("reason_concepts", words=", ".join(words) or ", ".join(vals)))
            elif kind == "clauses":
                reasons.append(self.t("reason_clauses", clauses=", ".join(vals)))
            else:
                reasons.append(self.t("reason_lifecycle", stages=", ".join(self.t("all_stages") if x == "all" else self.list_name("lifecycle", x) for x in vals)))
        self.dlg.say(f"  {self.t('why_shown')}: " + "; ".join(reasons))
        self.dlg.note(f"  {self.t('kind')}: {self.t('kind_' + a.get('kind', 'pedagogical'))} · {self.t('status')}: {a.get('status')}")
        q = pick(a.get("question"), self.lang)
        if q:
            self.dlg.say(f"  {self.t('question')}: {q}")
        pi = self.state.plan.get(a["advice_id"])
        if pi:
            self.labelled("decision", f"{self.t('dec_' + pi.decision)}" + (f" · {pi.owner}" if pi.owner else "") + (f" · {pi.deadline}" if pi.deadline else ""))
        ch = self.nav(len(sel), [("1", "plan_adopt"), ("2", "plan_adapt"), ("3", "plan_reject"), ("4", "plan_pending"),
                                 ("r", "plan_details"), ("i", "opt_add_alternative")])
        if ch in ("1", "2", "3", "4") and pi:
            pi.decision = DECISIONS[int(ch) - 1]
            self.state.decisions.append([6, "dec_advice", {"aid": a["advice_id"], "decision": pi.decision}])
        elif ch == "r" and pi:
            pi.owner = self.dlg.ask(self.t("ask_owner") + " ") or pi.owner
            pi.deadline = self.dlg.ask(self.t("ask_deadline") + " ") or pi.deadline
            pi.evidence = self.dlg.ask(self.t("ask_evidence") + " ") or pi.evidence
            pi.notes = self.dlg.ask(self.t("ask_notes") + " ") or pi.notes
        elif ch == "i":
            self.add_alternative()

    # -- enfoques (líneas)
    def view_lines(self):
        lines = [ln for ln in self.state.decision.lines if ln in self.kb.lines] or sorted(self.kb.lines)
        self.dlg.title(self.t("view_lines"))
        i = max(0, min(self.state.index, len(lines) - 1))
        line = self.kb.lines[lines[i]]
        self.dlg.say(terminal.style(f"{self.t('point')} {line['source_point']} — {self.txt(line.get('central_object'))}", "title")
                     + f"   ({i + 1}/{len(lines)})" + self.item_label(line))
        self.dlg.say(f"  RU: {line['text'].get('ru')}")
        if self.lang != "ru":
            self.dlg.say(f"  {self.lang.upper()}: {self.txt(line.get('text'))}")
        self.dlg.say(f"  {self.t('central_object')}: {self.txt(line.get('central_object'))}")
        self.dlg.say(f"  {self.t('std_type')}: {self.txt(line.get('type'))}")
        self.dlg.say(f"  {self.t('application')}: {self.txt(line.get('application'))}")
        self.dlg.say(f"  {self.t('relation_std')}: {self.txt(line.get('relation'))}")
        ev = (self.state.interpretation.evidence if self.state.interpretation else {}).get(f"line:{lines[i]}", [])
        self.dlg.say(f"  {self.t('link_problem')}: " + (", ".join(ev) if ev else self.t("no_direct_link")))
        if lines[i] == 11 and self.kb.observations:
            self.dlg.note("  " + self.txt(self.kb.observations.get("check")))
        self.dlg.note(f"  {self.t('source_label')}: {line.get('source')}")
        self.nav(len(lines))

    # -- plan
    def view_plan(self):
        self.dlg.title(self.t("view_plan"))
        self.demo_notice()
        if not self.state.plan:
            self.dlg.warn(self.t("no_advice_notice"))
        for sec, items in plan_by_section(self.kb, self.state.plan):
            self.dlg.section(pick(sec["names"], self.lang))
            if not items:
                self.dlg.note("  " + self.t("plan_empty_section"))
            for it in items:
                adv = next((a for a in self.kb.advice if a["advice_id"] == it.advice_id), {})
                self.dlg.bullet(f"[{self.t('dec_' + it.decision)}] {self.txt(adv.get('action'))}"
                                + (f" — {self.t('owner')}: {it.owner}" if it.owner else "")
                                + (f" — {self.t('deadline')}: {it.deadline}" if it.deadline else ""))
        self.dlg.note(self.t("plan_limits"))
        self.nav(0)

    def view_gaps(self):
        self.dlg.title(self.t("view_gaps"))
        missing, missing_life = advice_library.gaps(self.kb, self.state.edition_id, self.state.selected_advice,
                                                    self.state.profile.lifecycle_ids)
        if missing:
            self.dlg.warn(self.t("gaps_clauses"))
            for c in missing:
                self.dlg.bullet(self.clause_label(c))
        if missing_life:
            self.dlg.warn(self.t("gaps_lifecycle", stages=", ".join(self.list_name("lifecycle", x) for x in missing_life)))
        if not missing and not missing_life:
            self.dlg.ok(self.t("no_gaps"))
        self.dlg.note(self.t("gaps_note"))
        self.nav(0)

    def view_questions(self):
        self.dlg.title(self.t("view_questions"))
        self.dlg.note(self.t("pedagogical_label"))
        if self.kb.pedagogical_visible():
            qs = pick(self.kb.pedagogical.get("guiding_questions", {}).get("default"), self.lang) or []
            for q in qs:
                self.dlg.bullet(q)
        for key in ("q_product", "q_problem", "q_lifecycle", "q_actors", "q_norm"):
            self.dlg.bullet(self.t(key, product=self.state.profile.product or "—"))
        ch = self.nav(0, [("i", "opt_add_alternative")])
        if ch == "i":
            self.add_alternative()

    # -- evaluación
    def add_alternative(self):
        name = self.dlg.ask_text("ask_alternative")
        just = self.dlg.ask(self.t("ask_justification_optional") + " ")
        aid = f"A{len(self.state.evaluation.alternatives) + 1}"
        self.state.evaluation.alternatives.append({"aid": aid, "name": name, "justification": just})
        self.dlg.ok(self.t("alternative_added", aid=aid))

    def add_criterion(self):
        ev = self.state.evaluation
        if self.kb.pedagogical_visible() and self.kb.pedagogical.get("criteria_templates"):
            self.dlg.note(self.t("templates_available"))
            temps = self.kb.pedagogical["criteria_templates"]
            for i, c in enumerate(temps, start=1):
                self.dlg.option(str(i), (pick(c["names"], self.lang) or c["id"]) + f" ({self.t('sense_' + c['sense'])})")
            self.dlg.option("0", self.t("own_criterion"))
            n = self.dlg.ask_int("ask_number", 0, len(temps), default=0)
            if n > 0:
                c = temps[n - 1]
                w = self.dlg.ask_float("ask_weight", 0, 100, default=1)
                ev.criteria.append(Criterion(f"C{len(ev.criteria) + 1}", pick(c["names"], self.lang) or c["id"], "", c["sense"], w))
                return
        name = self.dlg.ask_text("ask_criterion_name")
        desc = self.dlg.ask(self.t("ask_criterion_desc") + " ")
        self.dlg.say(self.t("ask_sense"))
        self.dlg.option("1", self.t("sense_max"))
        self.dlg.option("2", self.t("sense_min"))
        sense = "max" if self.dlg.ask_int("ask_number", 1, 2) == 1 else "min"
        w = self.dlg.ask_float("ask_weight", 0, 100, default=1)
        ev.criteria.append(Criterion(f"C{len(ev.criteria) + 1}", name, desc, sense, w))

    def view_evaluation(self):
        ev = self.state.evaluation
        self.dlg.title(self.t("view_evaluation"))
        self.dlg.note(self.t("evaluation_method", lo=SCALE[0], hi=SCALE[1]))
        self.dlg.section(self.t("criteria"))
        for c in ev.criteria:
            self.dlg.bullet(f"{c.cid} {c.name} ({self.t('sense_' + c.sense)}) — {self.t('weight')} {number(c.weight, self.lang)}")
        self.dlg.section(self.t("alternatives"))
        for a in ev.alternatives:
            row = ev.scores.get(a["aid"], {})
            sc = ", ".join(f"{c.cid}={row[c.cid]}" for c in ev.criteria if c.cid in row)
            self.dlg.bullet(f"{a['aid']} {a['name']}" + (f" — {sc}" if sc else ""))
        opts = [("c", "opt_add_criterion"), ("i", "opt_add_alternative"), ("p", "opt_score"), ("w", "opt_weights"),
                ("k", "opt_margin"), ("r", "opt_compute"), ("v", "nav_back_views")]
        for k, lab in opts:
            self.dlg.option(k, self.t(lab))
        ch = self.dlg.choose([k for k, _ in opts])
        if ch == "c":
            self.add_criterion()
        elif ch == "i":
            self.add_alternative()
        elif ch == "p":
            if not ev.criteria or not ev.alternatives:
                self.dlg.warn(self.t("need_criteria_alternatives"))
                return
            for a in ev.alternatives:
                ev.scores.setdefault(a["aid"], {})
                for c in ev.criteria:
                    ev.scores[a["aid"]][c.cid] = self.dlg.ask_float("ask_score", SCALE[0], SCALE[1],
                                                                    default=ev.scores[a["aid"]].get(c.cid),
                                                                    alt=a["name"], crit=c.name)
        elif ch == "w":
            for c in ev.criteria:
                c.weight = self.dlg.ask_float("ask_weight_for", 0, 100, default=c.weight, crit=c.name)
        elif ch == "k":
            ev.margin = self.dlg.ask_float("ask_margin", 1, 90, default=round(ev.margin * 100)) / 100
        elif ch == "r":
            self.show_computation()
        elif ch == "v":
            self.state.view = "menu"

    def show_computation(self):
        ev = self.state.evaluation
        if not ev.complete():
            self.dlg.warn(self.t("need_complete_scores"))
            return
        try:
            totals, steps, rank, sens = ev.compute()
        except ValueError as exc:
            self.dlg.warn(self.t("eval_error", error=str(exc)))
            return
        names = {a["aid"]: a["name"] for a in ev.alternatives}
        cnames = {c.cid: c.name for c in ev.criteria}
        self.labelled("system", self.t("arithmetic"))
        for aid, rows in steps.items():
            self.dlg.say(f"  {aid} {names[aid]}:")
            for cid, raw, q, w, part in rows:
                self.dlg.say(f"     {cnames[cid]}: {self.t('score')} {number(raw, self.lang, 1)} → q={number(q, self.lang, 3)} × "
                             f"w={number(w, self.lang, 3)} = {number(part, self.lang, 3)}")
            self.dlg.say(f"     {self.t('total')} = {number(totals[aid], self.lang, 3)}")
        self.dlg.section(self.t("ranking"))
        for i, aid in enumerate(rank, start=1):
            self.dlg.say(f"  {i}. {aid} {names[aid]} — {number(totals[aid], self.lang, 3)}")
        self.dlg.section(self.t("sensitivity", margin=int(ev.margin * 100)))
        if sens["stable"]:
            self.dlg.ok(self.t("ranking_stable"))
        else:
            self.dlg.warn(self.t("ranking_fragile"))
            for chg in sens["changes"][:6]:
                self.dlg.bullet(self.t("sens_change", crit=cnames[chg["criterion"]], factor=number(chg["factor"], self.lang),
                                       rank=" > ".join(chg["ranking"])))
        self.dlg.note(self.t("not_the_correct"))
        self.dlg.pause()

    # -- decisión y registro
    def view_decision(self):
        self.dlg.title(self.t("view_decision"))
        for line in self.summary_lines():
            self.dlg.say(line)
        opts = [("d", "opt_decide"), ("g", "opt_save_record"), ("x", "opt_export"), ("n", "resume_new"), ("v", "nav_back_views")]
        for k, lab in opts:
            self.dlg.option(k, self.t(lab))
        ch = self.dlg.choose([k for k, _ in opts])
        if ch == "d":
            self.state.final_decision = self.dlg.ask_text("ask_final_decision")
            self.state.final_justification = self.dlg.ask_text("ask_final_justification")
            self.state.decisions.append([6, "dec_final", {}])
        elif ch == "g":
            self.dlg.ok(self.t("saved_to", path=self.save_record()))
        elif ch == "x":
            self.dlg.ok(self.t("exported_to", path=self.export()))
        elif ch == "n":
            self.reset()
        elif ch == "v":
            self.state.view = "menu"

    def summary_lines(self):
        s = self.state
        out = [terminal.style(self.t("label_student") + ":", "bold"), "  " + s.context, "  " + s.problem]
        out.append(terminal.style(self.t("label_system") + ":", "bold"))
        out.append("  " + self.edition_line())
        for r in s.recommendations:
            out.append(f"  {r['standard']['level']} {r['standard']['designation']}: {self.t('verdict_' + r['evaluation']['verdict'])} ({r['evaluation']['rule_id']})")
        out.append(f"  {self.t('advice_summary', n=len(s.selected_advice))}")
        out.append(terminal.style(self.t("label_decision") + ":", "bold"))
        for stage, key, kw in s.decisions:
            out.append(f"  ({self.t('stage')} {stage}) {self.decision_text(key, kw)}")
        counts = {d: sum(1 for p in s.plan.values() if p.decision == d) for d in DECISIONS}
        out.append("  " + self.t("plan_counts", **{k: v for k, v in counts.items()}))
        if s.final_decision:
            out.append(f"  {self.t('final_decision')}: {s.final_decision}")
            out.append(f"  {self.t('justification')}: {s.final_justification}")
        return out

    def decision_text(self, key, kw):
        kw = {k: (self.t("dec_" + v) if v in DECISIONS else v) for k, v in kw.items()}
        return self.t(key, **kw)

    def record(self):
        s = self.state
        ed = self.edition()
        marked = []
        for r in s.recommendations:
            st = r["standard"]
            if s.standards_marked.get(st["standard_id"]) == "useful":
                marked.append({"standard_id": st["standard_id"], "designation": st["designation"],
                               "edition": st.get("edition"), "status": st.get("status"),
                               "verified_on": st.get("verified_on"), "verdict": r["evaluation"]["verdict"],
                               "rule_id": r["evaluation"]["rule_id"]})
        totals = rank = sens = None
        if s.evaluation.complete():
            try:
                totals, _steps, rank, sens = s.evaluation.compute()
            except ValueError:
                pass
        return {
            "project_id": self.session.project_id, "subsystem_version": SUBSYSTEM_VERSION,
            "context": s.context, "problem": s.problem, "profile": s.profile.to_dict(),
            "decision": {"text": s.decision.decision_text, "goal": s.decision.decision_goal,
                         "final": s.final_decision, "justification": s.final_justification},
            "lines": s.decision.lines, "themes": s.decision.themes, "clauses": self.confirmed_clauses(),
            "restrictions": [s.decision.restrictions] if s.decision.restrictions else [],
            "iso_edition": {"edition_id": s.edition_id, "designation": ed["designation"] if ed else None,
                            "status": ed["status"] if ed else None, "verified_on": ed.get("verified_on") if ed else None},
            "recommendations": [{"standard_id": r["standard"]["standard_id"], "designation": r["standard"]["designation"],
                                 "level": r["standard"]["level"], **r["evaluation"]} for r in s.recommendations],
            "standards_marked": marked,
            "student_standards": s.student_standards,
            "advice_plan": [p.to_dict() for p in s.plan.values()],
            "evaluation": {**s.evaluation.to_dict(), "totals": totals, "ranking": rank, "sensitivity": sens},
            "decisions": [{"stage": st, "key": k, "params": kw, "text": self.decision_text(k, kw)} for st, k, kw in s.decisions],
            "language": self.lang, "date": dt.date.today().isoformat(),
            "sources": [self.kb.matrix_meta.get("source"), self.kb.catalog.get("meta", {}).get("source")],
            "demo": self.kb.is_demo,
        }

    def save_record(self):
        sub = "demo" if self.kb.is_demo else "records"
        stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        base = os.path.join(OUTPUT_DIR, sub, f"siadec_{stamp}")
        save_json(base + ".json", self.record())
        with open(base + ".txt", "w", encoding="utf-8") as fh:
            if self.kb.is_demo:
                fh.write(self.t("demo_notice") + "\n\n")
            fh.write("\n".join(terminal.strip_ansi(x) for x in self.summary_lines()) + "\n\n")
            fh.write(terminal.strip_ansi(self.t("view_plan")) + "\n")
            for sec, items in plan_by_section(self.kb, self.state.plan):
                fh.write(f"\n## {pick(sec['names'], self.lang)}\n")
                for it in items:
                    adv = next((a for a in self.kb.advice if a["advice_id"] == it.advice_id), {})
                    fh.write(f"- [{self.t('dec_' + it.decision)}] {self.txt(adv.get('action'))} | {it.owner} | {it.deadline} | {it.evidence} | {it.notes}\n")
        return base + ".txt"

    def export(self):
        return exchange.write_envelope(SUBSYSTEM_ID, self.lang, self.record())
