"""Atajo t(clave, idioma) del subsistema 2 (A4)."""
from __future__ import annotations

from .manager import translator


def t(key: str, lang: str, **kw) -> str:
    return translator().t(key, lang, **kw)
