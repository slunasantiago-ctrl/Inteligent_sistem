"""Plan de aseguramiento de la calidad del producto (B29.3).

El plan sigue el recorrido de ISO 9001 aplicado al producto. Los campos del plan
(decisión, responsable, plazo, evidencia, notas) son del estudiante: SIADEC no los estima.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass

DECISIONS = ("adopt", "adapt", "reject", "pending")


@dataclass
class PlanItem:
    advice_id: str
    section_id: str
    decision: str = "pending"
    owner: str = ""
    deadline: str = ""
    evidence: str = ""
    notes: str = ""

    def to_dict(self):
        return asdict(self)


def section_for(kb, clause_ids):
    """Primera sección cuyo prefijo coincide con alguna cláusula del consejo."""
    best = None
    for sec in kb.plan_sections:
        for pre in sec["clause_prefixes"]:
            for c in clause_ids:
                if c == pre or c.startswith(pre + "."):
                    if best is None or len(pre) > best[1]:
                        best = (sec["section_id"], len(pre))
    return best[0] if best else kb.plan_sections[-1]["section_id"] if kb.plan_sections else "other"


def build_plan(kb, selected, edition_id, existing=None):
    """Plan con los consejos seleccionados; conserva las decisiones previas del estudiante."""
    existing = existing or {}
    plan = {}
    for item in selected:
        a = item["advice"]
        aid = a["advice_id"]
        if aid in existing:
            plan[aid] = existing[aid]
        else:
            plan[aid] = PlanItem(aid, section_for(kb, a["clause_ids"].get(edition_id, [])))
    return plan


def plan_by_section(kb, plan):
    out = []
    for sec in kb.plan_sections:
        items = [p for p in plan.values() if p.section_id == sec["section_id"]]
        out.append((sec, items))
    return out
