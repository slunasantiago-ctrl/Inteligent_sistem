"""Etapa 3: interpretación del problema sobre las líneas de estandarización y los temas de ISO 9001 (B7, B13).

La asociación concepto -> línea/tema proviene solo del léxico cargado (con traza).
"""
from __future__ import annotations

from dataclasses import dataclass, field

W_PROBLEM = 1.0
W_CONTEXT = 0.5


@dataclass
class LineInterpretation:
    lines: list            # [(line_id, score)]
    themes: list           # [(theme_id, score)]
    concepts: dict         # concept_id -> palabras
    evidence: dict = field(default_factory=dict)   # line/theme -> conceptos
    confidence: float = 0.0
    ambiguous: bool = False

    @property
    def level(self):
        c = self.confidence
        return "high" if c >= 0.7 else ("medium" if c >= 0.5 else "low")


def interpret(kb, context: str, problem: str) -> LineInterpretation:
    lines, themes, ev = {}, {}, {}
    concepts_all = {}
    for text, weight in ((problem, W_PROBLEM), (context, W_CONTEXT)):
        matched = kb.match_concepts(text or "")
        for cid, words in matched.items():
            concepts_all.setdefault(cid, [])
            concepts_all[cid] += [w for w in words if w not in concepts_all[cid]]
            concept = next(c for c in kb.concepts["concepts"] if c["concept_id"] == cid)
            for ln in concept.get("lines", []):
                if ln in kb.lines:
                    lines[ln] = lines.get(ln, 0) + weight * len(words)
                    ev.setdefault(f"line:{ln}", set()).add(cid)
            for th in concept.get("themes", []):
                if th in kb.themes:
                    themes[th] = themes.get(th, 0) + weight * len(words)
                    ev.setdefault(f"theme:{th}", set()).add(cid)
    lr = sorted(lines.items(), key=lambda kv: (-kv[1], kv[0]))
    tr = sorted(themes.items(), key=lambda kv: (-kv[1], kv[0]))
    if lr:
        top = lr[0][1]
        second = lr[1][1] if len(lr) > 1 else 0
        conf = round(top / (top + second + 0.5), 2)
        ambiguous = len(lr) > 1 and second >= 0.85 * top
    else:
        conf, ambiguous = 0.0, True
    return LineInterpretation(lr, tr, concepts_all, {k: sorted(v) for k, v in ev.items()}, conf, ambiguous)
