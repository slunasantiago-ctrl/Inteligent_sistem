"""Evaluador multicriterio de SIADEC (B11): usa el método común declarado en isppr_platform.mcda.

Los criterios, pesos y puntuaciones provienen solo del estudiante.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

from isppr_platform import mcda

SCALE = (1, 5)


@dataclass
class Criterion:
    cid: str
    name: str
    description: str = ""
    sense: str = "max"   # "max" | "min"
    weight: float = 1.0


@dataclass
class Evaluation:
    criteria: list = field(default_factory=list)
    alternatives: list = field(default_factory=list)   # [{"aid", "name", "justification"}]
    scores: dict = field(default_factory=dict)         # {aid: {cid: value}}
    margin: float = 0.2

    def criteria_map(self):
        return {c.cid: c.sense for c in self.criteria}

    def weights(self):
        return {c.cid: c.weight for c in self.criteria}

    def complete(self) -> bool:
        return bool(self.criteria and self.alternatives) and all(
            c.cid in self.scores.get(a["aid"], {}) for a in self.alternatives for c in self.criteria)

    def compute(self):
        totals, steps = mcda.weighted_sum(self.criteria_map(), self.weights(), self.scores, *SCALE)
        sens = mcda.sensitivity(self.criteria_map(), self.weights(), self.scores, self.margin, *SCALE)
        return totals, steps, mcda.ranking(totals), sens

    def to_dict(self):
        return {"criteria": [asdict(c) for c in self.criteria], "alternatives": self.alternatives,
                "scores": self.scores, "margin": self.margin, "scale": SCALE}
