"""Problema de decisión estructurado (B8)."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field


@dataclass
class DecisionProblem:
    decision_text: str = ""
    decision_goal: str = None
    lines: list = field(default_factory=list)      # [line_id] (el primero es la principal)
    themes: list = field(default_factory=list)     # [theme_id]
    restrictions: str = ""
    confirmed: bool = False

    def to_dict(self):
        return asdict(self)
