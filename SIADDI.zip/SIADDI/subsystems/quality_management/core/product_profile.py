"""Perfil del producto declarado por el estudiante (B7 etapa 1, B8).

SIADEC propone valores a partir del texto (hipótesis) y el estudiante los corrige.
No infiere requisitos legales ni de mercado: solo registra lo que se declara.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

from isppr_platform import textnorm

FIELDS = ("category_id", "sector_id", "role", "lifecycle_ids", "qms_state", "critical_suppliers")


@dataclass
class ProductProfile:
    product: str = ""
    category_id: str = None
    sector_id: str = None
    role: str = None
    lifecycle_ids: list = field(default_factory=list)
    markets_legal: str = ""
    qms_state: str = None
    critical_suppliers: str = None     # "yes" | "no" | "unknown"
    proposed_by_system: list = field(default_factory=list)   # campos propuestos por SIADEC

    def to_dict(self):
        return asdict(self)

    def as_rule_input(self, decision_goal=None):
        """Diccionario de campos para el motor de reglas (B28.3)."""
        return {"decision_goal": decision_goal, "sector_id": self.sector_id, "category_id": self.category_id,
                "role": self.role, "lifecycle_id": self.lifecycle_ids, "qms_state": self.qms_state,
                "critical_suppliers": self.critical_suppliers}


def _best(items, text):
    scored = []
    for it in items:
        hits = textnorm.match_stems(text, it.get("stems", {}))
        if hits:
            scored.append((len(hits), it["id"]))
    scored.sort(reverse=True)
    return [i for _n, i in scored]


def extract_profile(kb, text: str) -> ProductProfile:
    lists = kb.profile_lists
    prof = ProductProfile(product=" ".join(text.split()[:12]))
    cat = _best(lists.get("categories", []), text)
    if cat:
        prof.category_id = cat[0]
        prof.proposed_by_system.append("category_id")
    sec = _best(lists.get("sectors", []), text)
    if sec:
        prof.sector_id = sec[0]
        prof.proposed_by_system.append("sector_id")
    roles = _best(lists.get("roles", []), text)
    if "designs" in roles and "manufactures" in roles:
        prof.role = "both"
    elif roles:
        prof.role = roles[0]
    if prof.role:
        prof.proposed_by_system.append("role")
    life = _best(lists.get("lifecycle", []), text)
    order = ["design", "production", "service"]
    prof.lifecycle_ids = [x for x in order if x in life]
    if prof.lifecycle_ids:
        prof.proposed_by_system.append("lifecycle_ids")
    qms = _best(lists.get("qms_state", []), text)
    if qms:
        prof.qms_state = qms[0]
        prof.proposed_by_system.append("qms_state")
    if textnorm.match_stems(text, {"es": ["proveedor"], "en": ["supplier"], "ru": ["поставщик"]}):
        prof.critical_suppliers = "yes"
        prof.proposed_by_system.append("critical_suppliers")
    return prof


def guess_goal(kb, text: str):
    goals = _best(kb.profile_lists.get("decision_goals", []), text)
    return goals
