"""Estado propio del subsistema 2 (B26): se conserva al ir y volver al menú."""
from __future__ import annotations

from dataclasses import dataclass, field

from .decision_problem import DecisionProblem
from .evaluation import Evaluation
from .product_profile import ProductProfile


@dataclass
class QualityState:
    stage: int = 1
    context: str = ""
    problem: str = ""
    profile: ProductProfile = field(default_factory=ProductProfile)
    interpretation: object = None
    decision: DecisionProblem = field(default_factory=DecisionProblem)
    edition_id: str = None
    lifecycle_filter: str = "unspecified"
    recommendations: list = field(default_factory=list)
    standards_marked: dict = field(default_factory=dict)   # standard_id -> "useful" | "discarded"
    student_standards: list = field(default_factory=list)  # añadidas por el estudiante (no verificadas)
    selected_advice: list = field(default_factory=list)
    plan: dict = field(default_factory=dict)
    evaluation: Evaluation = field(default_factory=Evaluation)
    final_decision: str = ""
    final_justification: str = ""
    decisions: list = field(default_factory=list)          # [etapa, clave, parámetros]
    view: str = "standards"
    index: int = 0
