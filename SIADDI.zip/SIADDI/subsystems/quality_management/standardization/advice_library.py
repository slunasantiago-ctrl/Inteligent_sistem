"""Selección determinista de consejos de aseguramiento de la calidad (B29.2).

Activación por cláusulas/temas confirmados, etapa del ciclo de vida, conceptos del problema y
campos del perfil. Orden: vinculados al problema -> por etapa (diseño -> producción -> servicio) -> resto.
"""
from __future__ import annotations

LIFECYCLE_ORDER = {"design": 0, "production": 1, "service": 2, "all": 3}


def _profile_ok(triggers: dict, profile: dict) -> bool:
    for field, allowed in (triggers or {}).items():
        v = profile.get(field)
        if v in (None, "", []):
            continue  # campo no declarado: no excluye
        values = v if isinstance(v, (list, tuple)) else [v]
        if not any(x in allowed for x in values):
            return False
    return True


def select(advice_list, edition_id: str, confirmed_clauses, matched_concepts, lifecycle_ids, profile: dict,
           lifecycle_filter: str = None):
    out = []
    clauses = set(confirmed_clauses or [])
    concepts = set(matched_concepts or [])
    life = set(lifecycle_ids or [])
    for a in advice_list:
        a_clauses = (a.get("clause_ids") or {}).get(edition_id)
        if a_clauses is None:
            continue  # B27.3: sin numeración para esta edición no se muestra
        if not _profile_ok((a.get("triggers") or {}).get("profile"), profile):
            continue
        a_life = set(a.get("lifecycle_ids") or [])
        if lifecycle_filter and lifecycle_filter != "unspecified":
            if lifecycle_filter not in a_life and "all" not in a_life:
                continue
        reasons = []
        problem_link = sorted(concepts & set((a.get("triggers") or {}).get("concepts", [])))
        if problem_link:
            reasons.append(("concepts", problem_link))
        clause_link = sorted(clauses & set(a_clauses))
        if clause_link:
            reasons.append(("clauses", clause_link))
        life_link = sorted(life & a_life) or (["all"] if "all" in a_life and life else [])
        if life_link:
            reasons.append(("lifecycle", life_link))
        if not reasons:
            continue
        first_stage = min(LIFECYCLE_ORDER.get(x, 9) for x in a_life) if a_life else 9
        out.append({"advice": a, "reasons": reasons, "problem_linked": bool(problem_link),
                    "sort": (0 if problem_link else 1, first_stage, a.get("advice_id"))})
    out.sort(key=lambda x: x["sort"])
    return out


def gaps(kb, edition_id: str, visible_selected, lifecycle_ids):
    """Cláusulas de nivel 2 sin consejo aprobado visible (B27.2 punto 6)."""
    covered = set()
    for item in kb.visible_advice():
        covered |= set((item.get("clause_ids") or {}).get(edition_id, []))
    missing_clauses = [c for c in kb.level2_clauses(edition_id) if c not in covered]
    covered_life = set()
    for item in kb.visible_advice():
        covered_life |= set(item.get("lifecycle_ids") or [])
    missing_life = [l for l in (lifecycle_ids or []) if l not in covered_life and "all" not in covered_life
                    and l != "unspecified"]
    return missing_clauses, missing_life
