"""Base de conocimiento de SIADEC: matriz, núcleo ISO 9001, catálogo, consejos (B9, B16, B17, B30).

Motor determinista sin idioma. Carga y valida; no genera contenido normativo.
"""
from __future__ import annotations

import os

from isppr_platform import textnorm
from isppr_platform.datastore import DataMode, load_json
from isppr_platform.i18n import pick

SUB_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class QualityKnowledge:
    def __init__(self, mode: DataMode = None, root: str = None):
        self.mode = mode or DataMode()
        self.root = root or SUB_ROOT
        d = self.mode.data_dir(self.root)
        self.data_dir = d
        m = load_json(os.path.join(d, "standardization_matrix.json"), {"lines": [], "meta": {}})
        self.matrix_meta = m.get("meta", {})
        self.lines = {int(x["line_id"]): x for x in m.get("lines", []) if self.mode.visible(x)}
        self.observations = m.get("observations")
        self.editions = load_json(os.path.join(d, "iso9001", "editions.json"), {"editions": []})["editions"]
        self.clauses = {}
        for ed in self.editions:
            if ed.get("has_structure"):
                data = load_json(os.path.join(d, "iso9001", f"clauses_{ed['edition_id']}.json"))
                if data:
                    self.clauses[ed["edition_id"]] = {c["clause_id"]: c for c in data["clauses"]}
                    self.clauses_status = data.get("status")
        self.qm_principles = load_json(os.path.join(d, "iso9001", "principles.json"), {"principles": []})
        self.themes = {t["theme_id"]: t for t in load_json(os.path.join(d, "iso9001", "themes.json"), {"themes": []})["themes"]}
        self.plan_sections = load_json(os.path.join(d, "iso9001", "plan_sections.json"), {"sections": []})["sections"]
        self.catalog = load_json(os.path.join(d, "standards_catalog.json"), {"standards": []})
        self.advice = load_json(os.path.join(d, "advice_library.json"), {"advice": []})["advice"]
        self.profile_lists = load_json(os.path.join(d, "product_categories.json"), {})
        self.concepts = load_json(os.path.join(d, "concepts.json"), {"concepts": []})
        self.pedagogical = load_json(os.path.join(d, "pedagogical_templates.json"), {})
        self.glossary = load_json(os.path.join(d, "glossary.json"), {"terms": []})

    # -------------------------------------------------------------- ediciones
    @property
    def is_demo(self):
        return self.mode.demo

    def edition(self, edition_id):
        for e in self.editions:
            if e["edition_id"] == edition_id:
                return e
        return None

    def default_edition(self):
        """Por defecto: vigente y verificada; si ninguna lo está, la marcada por defecto con aviso (B30)."""
        for e in self.editions:
            if e.get("status") in ("current", "verified") and e.get("has_structure"):
                return e
        for e in self.editions:
            if e.get("default"):
                return e
        return self.editions[0] if self.editions else None

    def has_structure(self, edition_id) -> bool:
        return edition_id in self.clauses

    def clause_title(self, edition_id, clause_id, lang):
        c = self.clauses.get(edition_id, {}).get(clause_id)
        return pick(c.get("title"), lang) if c else None

    def level2_clauses(self, edition_id):
        return [cid for cid, c in self.clauses.get(edition_id, {}).items() if c.get("level") == 2]

    def theme_clauses(self, theme_id, edition_id):
        t = self.themes.get(theme_id)
        return (t or {}).get("clauses", {}).get(edition_id, [])

    # -------------------------------------------------------------- catálogo y consejos
    def visible_rule(self, rule) -> bool:
        return self.mode.visible(rule)

    def visible_advice(self):
        return [a for a in self.advice if self.mode.visible(a)]

    def pedagogical_visible(self) -> bool:
        return self.mode.visible(self.pedagogical)

    def label(self, item):
        return self.mode.label(item)

    # -------------------------------------------------------------- léxico
    def match_concepts(self, text: str):
        out = {}
        for c in self.concepts.get("concepts", []):
            hits = textnorm.match_stems(text, c.get("stems", {}))
            if hits:
                out[c["concept_id"]] = [h[0] for h in hits]
        return out

    def validate(self):
        errors = []
        clause_sets = {ed: set(cl) for ed, cl in self.clauses.items()}
        for a in self.advice:
            if not a.get("source"):
                errors.append(f"advice_without_source:{a.get('advice_id')}")
            for ed, cl in (a.get("clause_ids") or {}).items():
                if ed in clause_sets:
                    bad = [c for c in cl if c not in clause_sets[ed]]
                    if bad:
                        errors.append(f"advice_bad_clause:{a.get('advice_id')}:{bad}")
        for s in self.catalog.get("standards", []):
            for r in s.get("rules", []):
                if not r.get("source"):
                    errors.append(f"rule_without_source:{r.get('rule_id')}")
        return errors
