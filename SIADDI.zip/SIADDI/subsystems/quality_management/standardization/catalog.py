"""Motor de reglas de aplicabilidad del catálogo de normas (B28).

Tres veredictos por norma: aplica según la regla / posible (falta un dato del perfil) /
no aplica según la regla. Solo se evalúan reglas visibles (aprobadas, o borrador en --draft).
"""
from __future__ import annotations

APPLIES = "applies"
POSSIBLE = "possible"
NOT_APPLIES = "not_applies"
LEVEL_ORDER = {"N1": 1, "N2": 2, "N3": 3, "N4": 4}
VERDICT_ORDER = {APPLIES: 0, POSSIBLE: 1, NOT_APPLIES: 2}


def _value(profile: dict, field: str):
    v = profile.get(field)
    if v in ("", None, [], "unknown"):
        return None
    return v


def _condition_holds(profile, cond):
    v = _value(profile, cond["field"])
    if v is None:
        return None
    allowed = cond.get("in", [])
    if isinstance(v, (list, tuple, set)):
        return any(x in allowed for x in v)
    return v in allowed


def evaluate_rule(rule: dict, profile: dict) -> dict:
    aw = rule.get("applies_when", {})
    missing = [f for f in rule.get("requires_profile_fields", []) if _value(profile, f) is None]
    matched, failed = [], []
    for cond in aw.get("all", []):
        ok = _condition_holds(profile, cond)
        if ok is None:
            if cond["field"] not in missing:
                missing.append(cond["field"])
        elif ok:
            matched.append(cond["field"])
        else:
            failed.append(cond)
    any_conds = aw.get("any", [])
    any_ok = None
    if any_conds:
        results = [_condition_holds(profile, c) for c in any_conds]
        if any(r is True for r in results):
            any_ok = True
            matched += [c["field"] for c, r in zip(any_conds, results) if r]
        elif all(r is None for r in results):
            any_ok = None
            for c in any_conds:
                if c["field"] not in missing:
                    missing.append(c["field"])
        else:
            any_ok = False
            failed += [c for c, r in zip(any_conds, results) if r is False]
    if failed:
        verdict = NOT_APPLIES
    elif missing:
        verdict = POSSIBLE
    else:
        verdict = APPLIES if (any_ok in (True, None) or not any_conds) else NOT_APPLIES
    return {"rule_id": rule.get("rule_id"), "verdict": verdict, "missing_fields": missing,
            "matched_fields": matched, "failed_conditions": failed, "rule_status": rule.get("status"),
            "rule_source": rule.get("source")}


def recommend(kb, profile: dict):
    """Lista ordenada N1..N4, «aplica» antes que «posible». Devuelve también las normas sin regla visible."""
    results, without_rule = [], []
    for std in kb.catalog.get("standards", []):
        rules = [r for r in std.get("rules", []) if kb.visible_rule(r)]
        if not rules:
            without_rule.append(std["standard_id"])
            continue
        evaluations = [evaluate_rule(r, profile) for r in rules]
        best = sorted(evaluations, key=lambda e: VERDICT_ORDER[e["verdict"]])[0]
        results.append({"standard": std, "evaluation": best, "all_evaluations": evaluations})
    results.sort(key=lambda r: (LEVEL_ORDER.get(r["standard"].get("level"), 9),
                                VERDICT_ORDER[r["evaluation"]["verdict"]], r["standard"]["standard_id"]))
    return results, without_rule


def n4_available(kb, profile: dict) -> bool:
    return any(s.get("level") == "N4" and kb.visible_rule((s.get("rules") or [{}])[0])
               for s in kb.catalog.get("standards", []))
