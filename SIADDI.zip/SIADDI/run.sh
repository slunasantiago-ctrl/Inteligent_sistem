#!/bin/bash
# Inicia ИСППР-ПД en la terminal. Acepta los mismos argumentos que main.py:
#   ./run.sh --demo | --draft | --lang es|en|ru | --ascii | --no-color | --project ID | --dossier ID
cd "$(dirname "$0")"
export PYTHONIOENCODING=utf-8
if [ "$(uname)" = "Darwin" ] && [ -z "$LC_ALL" ] && [ -z "$LC_CTYPE" ]; then
  export LC_CTYPE=UTF-8   # Terminal.app sin locale configurado: forzar UTF-8 para el cirílico y los marcos
fi
PY=python3
for cand in python3 /usr/bin/python3 /opt/homebrew/bin/python3 /usr/local/bin/python3; do
  if command -v "$cand" >/dev/null 2>&1 && "$cand" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
    PY="$cand"; break
  fi
done
exec "$PY" main.py "$@"
