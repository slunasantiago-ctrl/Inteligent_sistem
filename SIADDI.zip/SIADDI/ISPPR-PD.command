#!/bin/bash
# Doble clic en Finder para abrir ИСППР-ПД en Terminal.app
cd "$(dirname "$0")"
./run.sh "$@"
echo
read -n 1 -s -r -p "Pulse una tecla para cerrar / Press any key to close"
