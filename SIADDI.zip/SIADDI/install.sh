#!/bin/bash
# Instalación de ИСППР-ПД en macOS (también sirve en Linux).
# Uso:  bash install.sh
set -e
cd "$(dirname "$0")"

echo "== ИСППР-ПД 0.0.1 — instalación =="

PY=""
for cand in python3 /usr/bin/python3 /opt/homebrew/bin/python3 /usr/local/bin/python3; do
  if command -v "$cand" >/dev/null 2>&1; then
    if "$cand" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
      PY="$cand"; break
    fi
  fi
done

if [ -z "$PY" ]; then
  echo "No se encontró Python 3.9 o superior."
  echo "En macOS: ejecute  xcode-select --install  (instala python3 de Apple)"
  echo "o instale Python desde https://www.python.org/downloads/macos/  o con  brew install python"
  exit 1
fi
echo "Python encontrado: $PY ($("$PY" --version 2>&1))"

chmod +x run.sh "ISPPR-PD.command" main.py setup_data.py 2>/dev/null || true
# Quita la marca de cuarentena de macOS para que el .command se pueda abrir con doble clic
if command -v xattr >/dev/null 2>&1; then
  xattr -dr com.apple.quarantine . 2>/dev/null || true
fi

mkdir -p exchange projects

echo "Comprobando la plataforma..."
PYTHONIOENCODING=utf-8 "$PY" run_tests.py 2>&1 | tail -3 || true

if [ "$1" = "--optional" ]; then
  echo "Instalando dependencias opcionales (cairosvg)..."
  "$PY" -m pip install --user cairosvg || echo "No se pudo instalar cairosvg (opcional): el programa funciona igual."
fi

echo
echo "Listo. Para iniciar:"
echo "  ./run.sh            (o doble clic en ISPPR-PD.command)"
echo "  ./run.sh --demo     (datos de demostración)"
echo "  ./run.sh --draft    (mostrar contenidos en borrador)"
