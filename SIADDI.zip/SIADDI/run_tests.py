#!/usr/bin/env python3
"""Ejecuta todas las pruebas de la plataforma y de los tres subsistemas (P12).

    python3 run_tests.py
"""
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
os.environ.setdefault("NO_COLOR", "1")

if __name__ == "__main__":
    suite = unittest.TestSuite()
    loader = unittest.TestLoader()
    for start in ("tests", "subsystems/conceptual_design/tests", "subsystems/quality_management/tests",
                  "subsystems/form_synthesis/tests"):
        suite.addTests(loader.discover(os.path.join(ROOT, start), pattern="test_*.py", top_level_dir=ROOT))
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
