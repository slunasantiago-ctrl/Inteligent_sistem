#!/usr/bin/env python3
"""ИСППР-ПД — punto de entrada de la plataforma (A26.9).

main.py solo orquesta: banner -> menú -> subsistema elegido.

Uso:
    python3 main.py                 # modo normal (solo datos aprobados)
    python3 main.py --demo          # datos de demostración rotulados DEMO (A26.11.2, P9)
    python3 main.py --draft         # muestra también contenidos en borrador rotulados BORRADOR
    python3 main.py --dossier ID    # expediente integrado del proyecto ID (P11)
"""
from __future__ import annotations

import argparse
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import branding  # noqa: E402
from interface import banner, main_menu  # noqa: E402
from isppr_platform import dossier, registry, terminal  # noqa: E402
from isppr_platform.io import ConsoleIO, EndOfInput  # noqa: E402
from isppr_platform.session import PlatformSession  # noqa: E402
from isppr_platform.subsystem import RESULT_EXIT, ReturnToMenu  # noqa: E402

GOODBYE = "Hasta pronto / Goodbye / До свидания"


def parse_args(argv=None):
    p = argparse.ArgumentParser(prog="isppr", description=branding.banner_text())
    p.add_argument("--demo", action="store_true", help="datos de demostración (DEMO)")
    p.add_argument("--draft", action="store_true", help="mostrar contenidos en borrador (BORRADOR)")
    p.add_argument("--ascii", action="store_true", help="forzar salida ASCII simple")
    p.add_argument("--no-color", action="store_true", help="desactivar colores")
    p.add_argument("--lang", choices=["es", "en", "ru"], help="idioma inicial")
    p.add_argument("--project", help="identificador de proyecto para las exportaciones (P11)")
    p.add_argument("--dossier", metavar="PROJECT_ID", help="generar el expediente integrado y salir")
    p.add_argument("--version", action="store_true", help="mostrar la versión y salir")
    return p.parse_args(argv)


def run(session: PlatformSession, io) -> int:
    banner.render_banner(io, session)
    while True:
        main_menu.render_main_menu(io, session)
        choice = main_menu.read_choice(io)
        if choice == "exit":
            io.say(GOODBYE)
            return 0
        session.active_subsystem = choice
        try:
            subsystem = registry.get(choice)
            result = subsystem.run(session, io)
        except ReturnToMenu:
            result = "menu"
        except EndOfInput:
            raise
        except Exception as exc:  # un subsistema nunca debe cerrar la plataforma
            io.say(terminal.style(f"Error: {exc.__class__.__name__}: {exc}", "err"))
            if os.environ.get("ISPPR_DEBUG"):
                raise
            result = "menu"
        if result == RESULT_EXIT:
            io.say(GOODBYE)
            return 0
        # A26.2: al volver solo se redibuja el menú, nunca el banner.


def main(argv=None) -> int:
    terminal.configure_utf8()
    args = parse_args(argv)
    if args.no_color:
        os.environ["NO_COLOR"] = "1"
    if args.ascii:
        terminal.force_level(terminal.LEVEL_ASCII)
    if args.version:
        print(branding.banner_text())
        return 0
    if args.dossier:
        result = dossier.build(args.dossier)
        print(result["text"])
        print(f"\n-> {result['path']}")
        return 0
    session = PlatformSession(language=args.lang, demo=args.demo, draft=args.draft,
                              project_id=args.project)
    io = ConsoleIO()
    try:
        return run(session, io)
    except EndOfInput:
        io.say("")
        io.say(GOODBYE)
        return 0


if __name__ == "__main__":
    sys.exit(main())
