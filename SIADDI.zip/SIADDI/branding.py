"""Constantes de identidad de la plataforma ИСППР-ПД (A26.4, P1, P4).

El texto del banner y los nombres de los subsistemas viven solo aquí.
No se traducen (A26.3): son constantes de identidad, no textos de interfaz.
"""
from __future__ import annotations

APP_NAME = "ИСППР-ПД"
APP_VERSION = "0.0.1"
APP_VERSION_LABEL = "версия"

# Nombre descriptivo (P1). Solo informativo: el banner no lo muestra.
APP_DESCRIPTIVE_NAME = {
    "es": "Sistema Inteligente de Apoyo a Decisiones Estratégicas en Diseño Industrial",
    "en": "Intelligent Decision Support System for Strategic Decisions in Industrial Design",
    "ru": "Интеллектуальная система поддержки принятия решений в промышленном дизайне",
}

# (identificador interno estable, nombre visible constante) — A26.4 y P4.
SUBSYSTEMS = (
    ("conceptual_design", "Diseño conceptual (TRIZ)"),
    ("quality_management", "Управление качеством продукции"),
    ("standardization", "Стандартизация"),
)

# Correspondencia identificador -> carpeta del subsistema (P4, C26.1).
# Mientras no se apruebe el cambio de nombre de la opción [3], se conserva el
# identificador «standardization» y el código vive en «form_synthesis/».
SUBSYSTEM_FOLDERS = {
    "conceptual_design": "conceptual_design",
    "quality_management": "quality_management",
    "standardization": "form_synthesis",
}


def banner_text() -> str:
    """Cadena literal exigida por A26.1."""
    return f"{APP_NAME} {APP_VERSION_LABEL} {APP_VERSION}"
