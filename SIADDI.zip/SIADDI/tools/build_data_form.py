"""Genera los datos del subsistema 3 — SIADEF (C16, C17, Anexo C).

Todo lo que el prompt marca como ilustrativo o borrador se guarda con estado «draft».
Los valores de capacidad de proceso (σ) y la tabla de tolerancias SOLO existen en data/demo/,
rotulados DEMO: en data/ quedan vacíos hasta que el responsable académico los entregue (C17, C32).
"""
import copy
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SUB = os.path.join(ROOT, "subsystems", "form_synthesis")
DATA = os.path.join(SUB, "data")
DEMO = os.path.join(DATA, "demo")
TEAM = "Borrador del equipo de desarrollo basado en el Anexo C; pendiente de aprobación del responsable académico"


def tri(es=None, en=None, ru=None):
    return {"es": es, "en": en, "ru": ru}


def rect(x0, y0, x1, y1):
    return [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]


def el(eid, pts, labels, role="body"):
    return {"eid": eid, "points": pts, "labels": labels, "role": role, "holes": [], "attrs": {}}


SHAPES = [
    {"shape_id": "shape_lamp", "stems": {"es": ["lampara", "luminaria", "flexo"], "en": ["lamp", "luminaire"], "ru": ["ламп", "светильн"]}, "names": tri("Lámpara: base + brazo", "Lamp: base + arm", "Лампа: основание + кронштейн"),
     "description": tri("Polígono «base» y polígono alargado «brazo» (divisible) unidos por una unión candidata (C.2).",
                        "A «base» polygon and an elongated «arm» polygon (divisible) joined by a candidate joint (C.2).",
                        "Многоугольник «основание» и вытянутый «кронштейн» (делимый), соединённые возможным шарниром (C.2)."),
     "shape": {"elements": [el("e1", rect(0.25, 0.0, 0.75, 0.08), ["base", "edge_ext"], "base"),
                            el("e2", rect(0.46, 0.08, 0.54, 0.95), ["divisible", "edge_ext", "arm"], "arm")],
               "anchors": [{"aid": "a1", "point": [0.5, 0.08], "labels": ["joint_candidate"], "attrs": {}}], "counter": 3}},
    {"shape_id": "shape_chair", "stems": {"es": ["silla", "taburete", "asiento"], "en": ["chair", "stool", "seat"], "ru": ["стул", "табурет", "кресл"]}, "names": tri("Silla: vista lateral", "Chair: side view", "Стул: вид сбоку"),
     "description": tri("Asiento, respaldo y dos patas con uniones candidatas.", "Seat, backrest and two legs with candidate joints.",
                        "Сиденье, спинка и две ножки с возможными соединениями."),
     "shape": {"elements": [el("e1", rect(0.10, 0.45, 0.90, 0.53), ["divisible", "edge_ext", "seat"], "seat"),
                            el("e2", rect(0.82, 0.53, 0.90, 1.00), ["edge_ext", "back", "divisible"], "back"),
                            el("e3", rect(0.12, 0.0, 0.18, 0.45), ["edge_ext", "leg", "repeatable"], "leg"),
                            el("e4", rect(0.82, 0.0, 0.88, 0.45), ["edge_ext", "leg"], "leg")],
               "anchors": [{"aid": "a1", "point": [0.86, 0.53], "labels": ["joint_candidate"], "attrs": {}},
                           {"aid": "a2", "point": [0.15, 0.45], "labels": ["joint_candidate"], "attrs": {}}], "counter": 7}},
    {"shape_id": "shape_block", "stems": {}, "default": True, "names": tri("Bloque genérico", "Generic block", "Типовой блок"),
     "description": tri("Cuadrado divisible para explorar sin forma de partida.", "Divisible square to explore without a starting form.",
                        "Делимый квадрат для свободного поиска."),
     "shape": {"elements": [el("e1", rect(0.2, 0.2, 0.8, 0.8), ["divisible", "edge_ext", "body"])], "anchors": [], "counter": 2}},
    {"shape_id": "shape_panel", "stems": {"es": ["panel", "estante", "repisa", "tabla", "mesa"], "en": ["panel", "shelf", "board", "table"], "ru": ["панел", "полк", "стол"]}, "names": tri("Panel alargado", "Elongated panel", "Вытянутая панель"),
     "description": tri("Rectángulo horizontal divisible y perforable.", "Horizontal divisible and perforable rectangle.",
                        "Горизонтальный делимый и перфорируемый прямоугольник."),
     "shape": {"elements": [el("e1", rect(0.0, 0.35, 1.0, 0.65), ["divisible", "edge_ext", "body", "repeatable"])], "anchors": [], "counter": 2}},
]

FAMILIES = [
    ("fam_segmentation", "Segmentación", "Segmentation", "Сегментация"),
    ("fam_extraction", "Extracción", "Taking out", "Извлечение"),
    ("fam_local_variation", "Calidad local", "Local quality", "Местное качество"),
    ("fam_asymmetry", "Asimetría", "Asymmetry", "Асимметрия"),
    ("fam_merging", "Fusión", "Merging", "Объединение"),
    ("fam_multifunction", "Universalidad", "Universality", "Универсальность"),
    ("fam_nesting", "Anidamiento", "Nesting", "Вложение"),
    ("fam_inversion", "Inversión", "Inversion", "Инверсия"),
    ("fam_curvature", "Curvatura", "Curvature", "Кривизна"),
    ("fam_articulation", "Articulación (dinamismo)", "Articulation (dynamics)", "Шарнирность (динамичность)"),
    ("fam_dimension_change", "Otra dimensión", "Another dimension", "Другое измерение"),
    ("fam_repetition", "Repetición (copia)", "Repetition (copying)", "Повторение (копирование)"),
    ("fam_shell", "Cáscara de pared delgada", "Thin-walled shell", "Тонкостенная оболочка"),
    ("fam_perforation", "Perforación", "Perforation", "Перфорация"),
    ("fam_parametric_scale", "Cambio de parámetros", "Parameter change", "Изменение параметров"),
]


def rule(rid, fam, op, labels, params, names, desc, kind="element", exclude=None, pre=None, post=None, weight=1.0):
    return {"rule_id": rid, "family_id": fam, "lhs": {"kind": kind, "labels": labels, "exclude": exclude or []},
            "operation": op, "parameters": params, "guards_pre": pre or [], "guards_post": post or [],
            "weight": weight, "names": names, "description": desc, "source": TEAM, "status": "draft", "author": "equipo de desarrollo"}


RULES = [
    rule("r_segment_divide", "fam_segmentation", "divide", ["divisible"],
         {"n_parts": {"type": "int", "min": 2, "max": 4}, "gap": {"type": "float", "min": 0.02, "max": 0.08}},
         tri("Dividir en segmentos", "Divide into segments", "Разделить на сегменты"),
         tri("Divide un elemento divisible en 2 a 4 partes con una separación.", "Splits a divisible element into 2–4 parts with a gap.",
             "Делит делимый элемент на 2–4 части с зазором."), post=["g_min_feature"], weight=1.5),
    rule("r_repeat_linear", "fam_repetition", "repeat", ["repeatable"],
         {"count": {"type": "int", "min": 2, "max": 3}, "spacing": {"type": "float", "min": 0.3, "max": 1.0}},
         tri("Repetir en patrón lineal", "Repeat in a linear pattern", "Повторить линейным массивом"),
         tri("Copia el elemento en paralelo.", "Copies the element in parallel.", "Копирует элемент параллельно."), post=["g_inside_frame"]),
    rule("r_extract_holes", "fam_perforation", "subtract", ["edge_ext"],
         {"count": {"type": "int", "min": 1, "max": 3}, "radius": {"type": "float", "min": 0.2, "max": 0.5}},
         tri("Perforar (aligerar)", "Perforate (lighten)", "Перфорировать (облегчить)"),
         tri("Abre de 1 a 3 agujeros a lo largo del eje del elemento.", "Opens 1–3 holes along the element axis.",
             "Делает 1–3 отверстия вдоль оси элемента."), exclude=["joint", "perforated", "shell"], post=["g_min_feature"]),
    rule("r_fillet_external", "fam_curvature", "fillet", ["edge_ext"],
         {"radius": {"type": "float", "min": 0.01, "max": 0.08, "series": "R10"}},
         tri("Redondear aristas exteriores", "Round external edges", "Скруглить наружные рёбра"),
         tri("Redondea las esquinas con un radio de la serie de números preferidos.", "Rounds corners with a radius from the preferred-number series.",
             "Скругляет углы радиусом из ряда предпочтительных чисел."), exclude=["rounded", "joint"], post=["g_fillet_vs_wall"]),
    rule("r_replace_ellipse", "fam_curvature", "replace", ["edge_ext"], {},
         tri("Sustituir por elipse", "Replace by an ellipse", "Заменить эллипсом"),
         tri("Sustituye el elemento por la elipse inscrita en su marco.", "Replaces the element by the ellipse inscribed in its frame.",
             "Заменяет элемент вписанным эллипсом."), exclude=["elliptic", "joint", "rounded", "shell"], weight=0.6),
    rule("r_chamfer_local", "fam_local_variation", "chamfer", ["edge_ext"],
         {"distance": {"type": "float", "min": 0.01, "max": 0.05}},
         tri("Achaflanar localmente", "Local chamfer", "Местная фаска"),
         tri("Corta las esquinas con un chaflán.", "Cuts the corners with a chamfer.", "Срезает углы фаской."), exclude=["chamfered", "rounded", "joint"]),
    rule("r_asym_taper", "fam_asymmetry", "deform", ["edge_ext"],
         {"taper": {"type": "float", "min": 0.55, "max": 0.9}},
         tri("Estrechar de forma asimétrica", "Asymmetric taper", "Асимметричное сужение"),
         tri("Estrecha el elemento hacia uno de sus extremos.", "Tapers the element towards one end.", "Сужает элемент к одному концу."),
         exclude=["asymmetric", "joint", "base"], post=["g_min_feature"]),
    rule("r_merge_adjacent", "fam_merging", "add", ["segment"],
         {"mode": {"type": "const", "value": "merge"}},
         tri("Fusionar con el vecino", "Merge with the neighbour", "Объединить с соседним"),
         tri("Une el segmento con el elemento más próximo (envolvente).", "Joins the segment with the nearest element (hull).",
             "Объединяет сегмент с ближайшим элементом (оболочка)."), weight=0.5),
    rule("r_nest_offset", "fam_nesting", "offset_nest", ["edge_ext"],
         {"thickness": {"type": "float", "min": 0.12, "max": 0.25}, "gap": {"type": "float", "min": 0.05, "max": 0.12},
          "insert": {"type": "const", "value": "yes"}},
         tri("Anidar una pieza dentro de otra", "Nest one part inside another", "Вложить деталь в другую"),
         tri("Convierte el elemento en cáscara e inserta una pieza interior.", "Turns the element into a shell and inserts an inner part.",
             "Превращает элемент в оболочку и вкладывает внутреннюю деталь."), exclude=["shell", "nested", "joint", "perforated"], post=["g_min_wall"]),
    rule("r_shell", "fam_shell", "offset_nest", ["edge_ext"],
         {"thickness": {"type": "float", "min": 0.1, "max": 0.2}, "gap": {"type": "const", "value": 0.0},
          "insert": {"type": "const", "value": "no"}},
         tri("Vaciar en cáscara", "Hollow into a shell", "Сделать оболочку"),
         tri("Vacía el elemento dejando una pared delgada.", "Hollows the element leaving a thin wall.", "Полая оболочка с тонкой стенкой."),
         exclude=["shell", "nested", "joint", "perforated"], post=["g_min_wall"]),
    rule("r_articulate_joint", "fam_articulation", "articulate", ["joint_candidate"],
         {"radius": {"type": "float", "min": 0.015, "max": 0.035}},
         tri("Convertir la unión en articulación", "Turn the joint into an articulation", "Превратить соединение в шарнир"),
         tri("Añade un eje circular en la unión candidata.", "Adds a circular axis at the candidate joint.", "Добавляет круглую ось в возможном соединении."),
         kind="anchor", weight=1.5),
    rule("r_fold_segment", "fam_articulation", "rotate", ["segment"],
         {"angle": {"type": "float", "min": -40, "max": 40}, "pivot": {"type": "const", "value": "joint"}},
         tri("Plegar un segmento", "Fold a segment", "Сложить сегмент"),
         tri("Gira un segmento alrededor de la articulación más próxima.", "Rotates a segment about the nearest joint.",
             "Поворачивает сегмент вокруг ближайшего шарнира."), post=["g_no_overlap"]),
    rule("r_mirror_element", "fam_inversion", "mirror", ["edge_ext"], {"axis": {"type": "const", "value": "shape"}},
         tri("Invertir (espejo)", "Invert (mirror)", "Инвертировать (зеркально)"),
         tri("Refleja el elemento respecto al eje vertical de la forma.", "Mirrors the element about the vertical axis of the shape.",
             "Отражает элемент относительно вертикальной оси формы."), exclude=["mirrored", "base", "joint"], post=["g_no_overlap"], weight=0.6),
    rule("r_rotate_quarter", "fam_dimension_change", "rotate", ["edge_ext"],
         {"angle": {"type": "choice", "choices": [90, -90]}, "pivot": {"type": "const", "value": "centroid"}},
         tri("Girar 90°", "Rotate 90°", "Повернуть на 90°"),
         tri("Cambia la orientación del elemento (otra dimensión en 2D).", "Changes the element orientation (another dimension in 2D).",
             "Меняет ориентацию элемента (другое измерение в 2D)."), exclude=["joint", "base"], post=["g_no_overlap", "g_inside_frame"], weight=0.5),
    rule("r_scale_param", "fam_parametric_scale", "scale", ["edge_ext"],
         {"factor": {"type": "float", "min": 0.8, "max": 1.2}},
         tri("Escalar el elemento", "Scale the element", "Масштабировать элемент"),
         tri("Cambia el tamaño del elemento.", "Changes the element size.", "Изменяет размер элемента."), exclude=["joint"], post=["g_inside_frame", "g_no_overlap"], weight=0.7),
]

GUARDS = [
    {"guard_id": "g_no_self_intersection", "type": "geometric", "expr": "self_intersections == 0", "units": "rel",
     "names": tri("Sin autointersecciones", "No self-intersections", "Без самопересечений"), "source": "Validez del modelo geométrico (sin fuente normativa)", "status": "approved"},
    {"guard_id": "g_min_feature", "type": "geometric", "expr": "min_feature_width >= 0.015", "units": "rel",
     "names": tri("Anchura mínima de elemento", "Minimum element width", "Минимальная ширина элемента"), "source": "Validez del modelo geométrico (tamaño mínimo configurado)", "status": "approved"},
    {"guard_id": "g_inside_frame", "type": "geometric", "expr": "bbox_w <= 2.2 and bbox_h <= 2.2", "units": "rel",
     "names": tri("Dentro del marco de trabajo", "Inside the working frame", "В пределах рабочей области"), "source": "Validez del modelo geométrico", "status": "approved"},
    {"guard_id": "g_max_elements", "type": "geometric", "expr": "n_elements <= 16", "units": "rel",
     "names": tri("Número máximo de elementos", "Maximum number of elements", "Максимальное число элементов"), "source": "Límite configurado del motor (C10.6)", "status": "approved"},
    {"guard_id": "g_no_overlap", "type": "geometric", "expr": "overlaps == 0", "units": "rel",
     "names": tri("Sin solapes entre piezas", "No overlap between parts", "Без наложения деталей"), "source": "Validez del modelo geométrico", "status": "approved"},
    {"guard_id": "g_fillet_vs_wall", "type": "process", "expr": "fillet_radius == 0 or fillet_radius >= 0.5 * wall_thickness", "units": "rel",
     "process_ids": ["process_injection_moulding"], "names": tri("Radio ≥ 0,5 × espesor de pared", "Radius ≥ 0.5 × wall thickness", "Радиус ≥ 0,5 × толщины стенки"),
     "source": "Regla de diseño para inyección citada en C.2; pendiente de fuente (C43 punto 6)", "status": "draft"},
    {"guard_id": "g_min_wall", "type": "process", "expr": "min_wall == 0 or min_wall >= 0.012", "units": "rel",
     "names": tri("Espesor mínimo de pared (relativo)", "Minimum wall thickness (relative)", "Минимальная толщина стенки (отн.)"),
     "source": "Borrador del equipo; pendiente de fuente por proceso y material (C43 punto 6)", "status": "draft"},
    {"guard_id": "g_min_wall_mm", "type": "process", "expr": "min_wall_mm == 0 or min_wall_mm >= 1.0", "units": "mm",
     "process_ids": ["process_injection_moulding"], "names": tri("Espesor mínimo de pared ≥ 1,0 mm", "Minimum wall ≥ 1.0 mm", "Мин. толщина стенки ≥ 1,0 мм"),
     "source": "Borrador del equipo; pendiente de fuente (C43 punto 6)", "status": "draft"},
    {"guard_id": "g_min_feature_mm", "type": "process", "expr": "min_feature_width_mm >= 2.0", "units": "mm",
     "process_ids": ["process_injection_moulding", "process_fdm_printing"], "names": tri("Anchura mínima ≥ 2,0 mm", "Minimum width ≥ 2.0 mm", "Мин. ширина ≥ 2,0 мм"),
     "source": "Borrador del equipo; pendiente de fuente (C43 punto 6)", "status": "draft"},
    {"guard_id": "g_student_height", "type": "student", "expr": "height <= max_height", "units": "rel",
     "names": tri("Altura máxima declarada", "Declared maximum height", "Заявленная максимальная высота"), "source": "Declarada por el estudiante", "status": "approved"},
    {"guard_id": "g_student_width", "type": "student", "expr": "width <= max_width", "units": "rel",
     "names": tri("Anchura máxima declarada", "Declared maximum width", "Заявленная максимальная ширина"), "source": "Declarada por el estudiante", "status": "approved"},
]

TRIZ_MAP = [
    (1, ["fam_segmentation", "fam_repetition"], "direct", "Dividir el objeto en partes independientes o desmontables."),
    (2, ["fam_extraction", "fam_perforation"], "direct", "Extraer la parte que molesta o aligerar quitando material."),
    (3, ["fam_local_variation"], "partial", "Cambiar las condiciones de una zona concreta."),
    (4, ["fam_asymmetry"], "direct", "Pasar de forma simétrica a asimétrica."),
    (5, ["fam_merging"], "direct", "Unir elementos contiguos."),
    (6, ["fam_multifunction"], "partial", "Un elemento cumple varias funciones."),
    (7, ["fam_nesting"], "direct", "Colocar un objeto dentro de otro."),
    (13, ["fam_inversion"], "direct", "Invertir la disposición."),
    (14, ["fam_curvature"], "direct", "Pasar de formas rectas a curvas."),
    (15, ["fam_articulation"], "direct", "Hacer las partes móviles o ajustables."),
    (17, ["fam_dimension_change"], "partial", "Cambiar la orientación o la dimensión de trabajo (en 2D)."),
    (26, ["fam_repetition"], "partial", "Usar copias."),
    (30, ["fam_shell"], "partial", "Usar cáscaras y paredes delgadas."),
    (31, ["fam_perforation"], "partial", "Hacer el objeto poroso o perforado."),
    (35, ["fam_parametric_scale"], "partial", "Cambiar parámetros (tamaño)."),
]

PREFERRED = {
    "status": "draft", "standard": "ISO 3 / ГОСТ 8032", "edition": None, "verified_on": None,
    "source": "Series de Renard de números preferidos; valores a verificar contra la norma antes de aprobarlos (C29.4, C43 punto 8)",
    "series": {
        "R5": [1.00, 1.60, 2.50, 4.00, 6.30],
        "R10": [1.00, 1.25, 1.60, 2.00, 2.50, 3.15, 4.00, 5.00, 6.30, 8.00],
        "R20": [1.00, 1.12, 1.25, 1.40, 1.60, 1.80, 2.00, 2.24, 2.50, 2.80, 3.15, 3.55, 4.00, 4.50, 5.00, 5.60, 6.30, 7.10, 8.00, 9.00],
        "R40": [1.00, 1.06, 1.12, 1.18, 1.25, 1.32, 1.40, 1.50, 1.60, 1.70, 1.80, 1.90, 2.00, 2.12, 2.24, 2.36, 2.50, 2.65, 2.80, 3.00,
                3.15, 3.35, 3.55, 3.75, 4.00, 4.25, 4.50, 4.75, 5.00, 5.30, 5.60, 6.00, 6.30, 6.70, 7.10, 7.50, 8.00, 8.50, 9.00, 9.50],
    },
    "decade_extension": True,
}

PROCESSES = [
    {"process_id": "process_injection_moulding", "names": tri("Inyección de plástico", "Injection moulding", "Литьё под давлением"),
     "stems": {"es": ["inyecc", "inyect"], "en": ["injection", "moulded", "molded"], "ru": ["литье под давлением", "литьем под давлением", "литьё"]},
     "wall_thickness_rel": 0.02},
    {"process_id": "process_cnc_milling", "names": tri("Fresado CNC", "CNC milling", "Фрезерование на ЧПУ"),
     "stems": {"es": ["fresad", "cnc", "mecaniz"], "en": ["milling", "cnc", "machin"], "ru": ["фрезер", "чпу", "механообработ"]}, "wall_thickness_rel": 0.01},
    {"process_id": "process_sheet_metal", "names": tri("Chapa plegada", "Sheet metal", "Листовой металл"),
     "stems": {"es": ["chapa", "plegad", "lamina"], "en": ["sheet metal", "bent", "sheet"], "ru": ["листов", "гибк"]}, "wall_thickness_rel": 0.008},
    {"process_id": "process_fdm_printing", "names": tri("Impresión 3D FDM", "FDM 3D printing", "3D-печать FDM"),
     "stems": {"es": ["impresion 3d", "impres", "fdm"], "en": ["3d print", "printing", "fdm"], "ru": ["3d-печат", "печат", "fdm"]}, "wall_thickness_rel": 0.02},
    {"process_id": "process_wood_cnc", "names": tri("Corte CNC de tablero", "CNC panel cutting", "Раскрой плит на ЧПУ"),
     "stems": {"es": ["madera", "contrachap", "tablero"], "en": ["wood", "plywood", "board"], "ru": ["древес", "фанер", "плит"]}, "wall_thickness_rel": 0.03},
]

MATERIALS = [
    {"material_id": "material_pp", "names": tri("Polipropileno (PP)", "Polypropylene (PP)", "Полипропилен (PP)"),
     "stems": {"es": ["polipropileno", "pp"], "en": ["polypropylene", "pp"], "ru": ["полипропилен"]}},
    {"material_id": "material_abs", "names": tri("ABS", "ABS", "ABS"), "stems": {"es": ["abs"], "en": ["abs"], "ru": ["abs", "абс"]}},
    {"material_id": "material_pla", "names": tri("PLA", "PLA", "PLA"), "stems": {"es": ["pla"], "en": ["pla"], "ru": ["pla"]}},
    {"material_id": "material_aluminium", "names": tri("Aluminio", "Aluminium", "Алюминий"),
     "stems": {"es": ["alumin"], "en": ["alumin"], "ru": ["алюмин"]}},
    {"material_id": "material_steel", "names": tri("Acero", "Steel", "Сталь"), "stems": {"es": ["acero"], "en": ["steel"], "ru": ["стал"]}},
    {"material_id": "material_plywood", "names": tri("Contrachapado", "Plywood", "Фанера"),
     "stems": {"es": ["contrachap", "madera"], "en": ["plywood", "wood"], "ru": ["фанер", "древес"]}},
]

CAPABILITY_DEMO = []


def cap(cid, proc, mat, ftype, lo, hi, sigma):
    CAPABILITY_DEMO.append({"capability_id": cid, "process_id": proc, "material_id": mat, "feature_type": ftype,
                            "range_mm": [lo, hi], "sigma_mm": sigma, "mean_shift_mm": 0.0, "distribution": "normal",
                            "data_quality": "C_derived_from_IT_grade",
                            "derivation_note": tri("DEMO: valor ilustrativo para mostrar el cálculo; no usar en la tesis.",
                                                   "DEMO: illustrative value to show the calculation; do not use in the thesis.",
                                                   "ДЕМО: иллюстративное значение для показа расчёта; не использовать в диссертации."),
                            "sample_size": None, "source": "DEMO — valores ilustrativos, no son datos de capacidad reales", "verified_on": None,
                            "status": "demo"})


for i, (lo, hi, s) in enumerate([(0, 10, 0.02), (10, 50, 0.04), (50, 200, 0.08), (200, 1000, 0.15)]):
    cap(f"demo_inj_pp_lin_{i}", "process_injection_moulding", "material_pp", "linear", lo, hi, s)
for i, (lo, hi, s) in enumerate([(0, 10, 0.015), (10, 50, 0.03), (50, 200, 0.06)]):
    cap(f"demo_inj_pp_dia_{i}", "process_injection_moulding", "material_pp", "diameter", lo, hi, s)
for i, (lo, hi, s) in enumerate([(0, 50, 0.008), (50, 200, 0.012), (200, 1000, 0.02)]):
    cap(f"demo_cnc_al_lin_{i}", "process_cnc_milling", "material_aluminium", "linear", lo, hi, s)
cap("demo_cnc_al_dia_0", "process_cnc_milling", "material_aluminium", "diameter", 0, 100, 0.006)
for i, (lo, hi, s) in enumerate([(0, 50, 0.06), (50, 300, 0.1)]):
    cap(f"demo_fdm_pla_lin_{i}", "process_fdm_printing", "material_pla", "linear", lo, hi, s)
cap("demo_fdm_pla_dia_0", "process_fdm_printing", "material_pla", "diameter", 0, 50, 0.05)
cap("demo_sheet_lin_0", "process_sheet_metal", "material_steel", "linear", 0, 1000, 0.1)
cap("demo_wood_lin_0", "process_wood_cnc", "material_plywood", "linear", 0, 2000, 0.15)

TOLERANCE_DEMO = {"tables": [{"table_id": "demo_general_medium", "standard": "DEMO", "class": "DEMO-medio", "edition": None,
                              "names": tri("DEMO — tolerancia general ilustrativa (no es una norma)", "DEMO — illustrative general tolerance (not a standard)",
                                           "ДЕМО — иллюстративный общий допуск (не стандарт)"),
                              "ranges": [[0, 6, 0.15], [6, 30, 0.25], [30, 120, 0.4], [120, 400, 0.6], [400, 2000, 1.0]],
                              "source": "DEMO — valores ilustrativos inventados para la demostración; no reproducen ninguna norma",
                              "license": "demo", "status": "demo"}]}

INDICATORS = {
    "status": "draft", "source": "Borrador C.6 — pendiente de aprobación (C43 punto 12)",
    "indicators": [
        {"indicator_id": "ind_conformity", "names": tri("Conformidad normativa", "Normative conformity", "Нормативное соответствие"),
         "formula": tri("guardas superadas / guardas activas", "guards passed / active guards", "пройдено ограничений / активных ограничений"),
         "sense": "max", "stage": "abstract", "status": "draft", "source": "C.6"},
        {"indicator_id": "ind_complexity", "names": tri("Complejidad geométrica", "Geometric complexity", "Геометрическая сложность"),
         "formula": tri("0,4·min(1, elementos/12) + 0,3·min(1, vértices/300) + 0,3·min(1, cotas críticas candidatas/8); q = 1 − valor",
                        "0.4·min(1, elements/12) + 0.3·min(1, vertices/300) + 0.3·min(1, candidate CTQ/8); q = 1 − value",
                        "0,4·min(1, элементов/12) + 0,3·min(1, вершин/300) + 0,3·min(1, кандидатов КХК/8); q = 1 − значение"),
         "sense": "min", "stage": "abstract", "coefficients": {"elements": [0.4, 12], "vertices": [0.3, 300], "ctq": [0.3, 8]},
         "status": "draft", "source": "C.6"},
        {"indicator_id": "ind_novelty", "names": tri("Novedad formal", "Formal novelty", "Новизна формы"),
         "formula": tri("1 − máxima intersección sobre unión con las formas de referencia", "1 − maximum intersection-over-union with reference shapes",
                        "1 − максимальное отношение пересечения к объединению с эталонными формами"),
         "sense": "max", "stage": "abstract", "status": "draft", "source": "C.6"},
        {"indicator_id": "ind_unification", "names": tri("Unificación", "Unification", "Унификация"),
         "formula": tri("0,5·(cotas en serie preferida / cotas) + 0,5·(elementos repetidos / elementos)",
                        "0.5·(dimensions in preferred series / dimensions) + 0.5·(repeated elements / elements)",
                        "0,5·(размеры из ряда / размеры) + 0,5·(повторяющиеся элементы / элементы)"),
         "sense": "max", "stage": "dimensioned", "status": "draft", "source": "C.6"},
        {"indicator_id": "ind_reproducibility", "names": tri("Reproducibilidad", "Reproducibility", "Воспроизводимость"),
         "formula": tri("min(1, Cpk previsto mínimo / umbral)", "min(1, minimum predicted Cpk / threshold)", "min(1, мин. прогнозный Cpk / порог)"),
         "sense": "max", "stage": "dimensioned", "status": "draft", "source": "C.6"},
        {"indicator_id": "ind_robustness", "names": tri("Robustez", "Robustness", "Робастность"),
         "formula": tri("cotas que mantienen Cpk ≥ umbral con σ aumentada un {p} % / cotas", "dimensions keeping Cpk ≥ threshold with σ increased by {p} % / dimensions",
                        "размеры с Cpk ≥ порога при σ, увеличенной на {p} % / размеры"),
         "sense": "max", "stage": "dimensioned", "sigma_increase": 0.2, "status": "draft", "source": "C.6 (adaptado: proporción robusta)"},
        {"indicator_id": "ind_consumer", "names": tri("Percepción del consumidor", "Consumer perception", "Восприятие потребителем"),
         "formula": tri("1 − distancia normalizada al perfil objetivo", "1 − normalised distance to the target profile", "1 − нормированное расстояние до целевого профиля"),
         "sense": "max", "stage": "survey", "status": "draft", "source": "C.6"},
    ],
    "risk_index": {"names": tri("Índice heurístico de riesgo (no es Cpk)", "Heuristic risk index (not Cpk)", "Эвристический индекс риска (не Cpk)"),
                   "weights": {"ctq": 0.3, "small_radii": 0.2, "thin_walls": 0.3, "chains": 0.2},
                   "limits": {"ctq": 8, "small_radius": 0.012, "thin_wall": 0.04, "chains": 8},
                   "status": "draft", "source": "C.6 — coeficientes pendientes de aprobación"},
}

SCALES = {"status": "draft", "source": TEAM, "scale": [1, 7], "min_respondents": 30,
          "scales": [
              {"scale_id": "light_heavy", "left": tri("ligero", "light", "лёгкий"), "right": tri("pesado", "heavy", "тяжёлый")},
              {"scale_id": "modern_classic", "left": tri("moderno", "modern", "современный"), "right": tri("clásico", "classic", "классический")},
              {"scale_id": "stable_unstable", "left": tri("estable", "stable", "устойчивый"), "right": tri("inestable", "unstable", "неустойчивый")},
              {"scale_id": "simple_complex", "left": tri("simple", "simple", "простой"), "right": tri("complejo", "complex", "сложный")},
          ]}

REFERENCES = {"status": "draft", "source": "Siluetas genéricas dibujadas por el equipo de desarrollo (sin derechos de terceros)",
              "shapes": [
                  {"ref_id": "ref_lamp_straight", "shape": {"elements": [el("e1", rect(0.25, 0.0, 0.75, 0.08), ["base"]), el("e2", rect(0.46, 0.08, 0.54, 0.95), ["arm"])], "anchors": []}},
                  {"ref_id": "ref_block", "shape": {"elements": [el("e1", rect(0.2, 0.2, 0.8, 0.8), ["body"])], "anchors": []}},
                  {"ref_id": "ref_chair_basic", "shape": {"elements": [el("e1", rect(0.1, 0.45, 0.9, 0.53), ["seat"]), el("e2", rect(0.82, 0.53, 0.9, 1.0), ["back"]),
                                                                       el("e3", rect(0.12, 0.0, 0.18, 0.45), ["leg"]), el("e4", rect(0.82, 0.0, 0.88, 0.45), ["leg"])], "anchors": []}},
                  {"ref_id": "ref_panel", "shape": {"elements": [el("e1", rect(0.0, 0.35, 1.0, 0.65), ["body"])], "anchors": []}},
              ]}

AHP = {"status": "draft", "source": "Índices aleatorios de Saaty (1980), a verificar contra la fuente (C43 punto 14)",
       "random_index": {"1": 0.0, "2": 0.0, "3": 0.58, "4": 0.90, "5": 1.12, "6": 1.24, "7": 1.32, "8": 1.41, "9": 1.45, "10": 1.49},
       "cr_threshold": 0.10}

CONCEPTS = {"status": "provisional", "source": TEAM, "concepts": [
    {"concept_id": "concept_fold", "families": ["fam_articulation", "fam_segmentation"], "stems": {"es": ["plegab", "pleg", "articul", "abatib"], "en": ["fold", "articulat", "hinge"], "ru": ["складн", "складыва", "шарнир"]}},
    {"concept_id": "concept_stack", "families": ["fam_repetition", "fam_nesting"], "stems": {"es": ["apilab", "apilar"], "en": ["stack"], "ru": ["штабел"]}},
    {"concept_id": "concept_compact", "families": ["fam_nesting", "fam_articulation"], "stems": {"es": ["guardar", "compact", "poco espacio", "ocupar poco"], "en": ["store", "compact", "little space"], "ru": ["хранен", "компакт", "мало места"]}},
    {"concept_id": "concept_light", "families": ["fam_perforation", "fam_shell", "fam_extraction"], "stems": {"es": ["liger", "livian", "aligerar"], "en": ["lightweight", "lighter", "light weight"], "ru": ["легк", "облегч"]}},
    {"concept_id": "concept_round", "families": ["fam_curvature"], "stems": {"es": ["curv", "redonde", "organic", "suave"], "en": ["curv", "round", "organic", "soft"], "ru": ["изогн", "кругл", "плавн", "органич"]}},
    {"concept_id": "concept_modular", "families": ["fam_segmentation", "fam_repetition"], "stems": {"es": ["modular", "modulo", "desmont"], "en": ["modular", "module", "detachab"], "ru": ["модул", "разборн"]}},
    {"concept_id": "concept_dynamic", "families": ["fam_asymmetry", "fam_articulation"], "stems": {"es": ["dinamic", "asimetr", "movimiento"], "en": ["dynamic", "asymmetr", "movement"], "ru": ["динамич", "асимметр", "движен"]}},
    {"concept_id": "concept_fewer_parts", "families": ["fam_merging"], "stems": {"es": ["menos piezas", "reducir piezas", "una sola pieza"], "en": ["fewer parts", "single part", "one piece"], "ru": ["меньше деталей", "одна деталь"]}},
    {"concept_id": "concept_adjustable", "families": ["fam_parametric_scale", "fam_articulation"], "stems": {"es": ["ajustab", "regulab", "telescop"], "en": ["adjustab", "telescop"], "ru": ["регулир", "телескоп"]}},
]}

PEDAGOGICAL = {"status": "draft", "kind": "pedagogical", "source": TEAM,
               "improvement_options": ["open_tolerance", "change_process", "redesign_joint", "regenerate"],
               "learning": {"delta": 0.1, "min_weight": 0.2, "max_weight": 3.0, "status": "draft"}}


def write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)


def mark(items, status):
    items = copy.deepcopy(items)
    for it in items:
        it["status"] = status
    return items


def build(base, demo):
    st = "demo" if demo else None
    shapes = mark(SHAPES, st or "draft")
    for s in shapes:
        s["source"] = TEAM
    write(os.path.join(base, "grammar", "initial_shapes.json"), {"shapes": shapes})
    write(os.path.join(base, "grammar", "families.json"),
          {"families": [{"family_id": f, "names": tri(es, en, ru), "source": TEAM, "status": st or "draft"} for f, es, en, ru in FAMILIES]})
    write(os.path.join(base, "grammar", "rules.json"), {"rules": mark(RULES, "demo") if demo else copy.deepcopy(RULES)})
    guards = copy.deepcopy(GUARDS)
    if demo:
        for g in guards:
            g["status"] = "demo"
    write(os.path.join(base, "grammar", "guards.json"), {"guards": guards})
    write(os.path.join(base, "grammar", "triz_family_map.json"),
          {"map": [{"principle_id": p, "family_ids": fs, "strength": s, "justification": tri(j), "author": "equipo de desarrollo",
                    "approved_by": None, "status": st or "draft", "source": "Borrador C.5 (pendiente de aprobación)"} for p, fs, s, j in TRIZ_MAP]})
    pn = copy.deepcopy(PREFERRED)
    if demo:
        pn["status"] = "demo"
    write(os.path.join(base, "standards", "preferred_numbers.json"), pn)
    write(os.path.join(base, "standards", "tolerance_tables.json"), TOLERANCE_DEMO if demo else {"tables": []})
    write(os.path.join(base, "process_catalog.json"), {"status": "provisional", "source": TEAM, "processes": PROCESSES})
    write(os.path.join(base, "material_catalog.json"), {"status": "provisional", "source": TEAM, "materials": MATERIALS})
    write(os.path.join(base, "process_capability.json"), {"records": CAPABILITY_DEMO if demo else [],
                                                          "note": "Sin datos de capacidad cargados: el Cpk previsto no se calcula (C17, C32)." if not demo else "DEMO"})
    ind = copy.deepcopy(INDICATORS)
    if demo:
        ind["status"] = "demo"
        ind["risk_index"]["status"] = "demo"
        for i in ind["indicators"]:
            i["status"] = "demo"
    write(os.path.join(base, "indicators.json"), ind)
    sc = copy.deepcopy(SCALES)
    ref = copy.deepcopy(REFERENCES)
    ahp = copy.deepcopy(AHP)
    ped = copy.deepcopy(PEDAGOGICAL)
    if demo:
        for d in (sc, ref, ahp, ped):
            d["status"] = "demo"
        ped["learning"]["status"] = "demo"
    write(os.path.join(base, "semantic_scales.json"), sc)
    write(os.path.join(base, "reference_shapes", "references.json"), ref)
    write(os.path.join(base, "ahp_random_index.json"), ahp)
    write(os.path.join(base, "concepts.json"), CONCEPTS)
    write(os.path.join(base, "pedagogical_templates.json"), ped)
    write(os.path.join(base, "glossary.json"), {"terms": [
        {"term_id": "shape_grammar", "values": tri("gramática de formas", "shape grammar", "грамматика форм"), "status": "provisional", "source": TEAM},
        {"term_id": "cpk", "values": tri("índice de capacidad del proceso", "process capability index", "индекс воспроизводимости процесса"), "status": "provisional", "source": TEAM},
        {"term_id": "ctq", "values": tri("característica crítica para la calidad", "critical-to-quality characteristic", "критически важная для качества характеристика"), "status": "provisional", "source": TEAM},
        {"term_id": "dim_chain", "values": tri("cadena dimensional", "dimensional chain", "размерная цепь"), "status": "provisional", "source": TEAM},
        {"term_id": "preferred_numbers", "values": tri("números preferidos", "preferred numbers", "предпочтительные числа"), "status": "provisional", "source": TEAM},
        {"term_id": "qualimetry", "values": tri("cualimetría", "qualimetry", "квалиметрия"), "status": "provisional", "source": TEAM},
        {"term_id": "integral_index", "values": tri("índice integral", "integral index", "комплексный показатель"), "status": "provisional", "source": TEAM},
    ]})


def main():
    build(DATA, False)
    build(DEMO, True)
    print("datos del subsistema 3 generados")


if __name__ == "__main__":
    main()
