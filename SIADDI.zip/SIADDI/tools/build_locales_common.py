"""Textos de interfaz comunes a los tres subsistemas (isppr_platform/locales)."""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

T = {
    "hint_globals": ["[0] cambiar idioma · [m] volver al menú principal",
                     "[0] change language · [m] back to main menu",
                     "[0] сменить язык · [m] вернуться в главное меню"],
    "err_empty": ["Escribe una respuesta.", "Please type an answer.", "Введите ответ."],
    "err_invalid_option": ["Opción no válida. Inténtalo de nuevo.", "Invalid option. Please try again.",
                           "Неверный вариант. Попробуйте ещё раз."],
    "err_number": ["Escribe un número válido.", "Please type a valid number.", "Введите корректное число."],
    "err_range": ["El valor debe estar entre {lo} y {hi}.", "The value must be between {lo} and {hi}.",
                  "Значение должно быть от {lo} до {hi}."],
    "yes_no_default_yes": ["[S/n]", "[Y/n]", "[Д/н]"],
    "yes_no_default_no": ["[s/N]", "[y/N]", "[д/Н]"],
    "press_enter": ["Pulsa Intro para continuar… ", "Press Enter to continue… ", "Нажмите Enter, чтобы продолжить… "],
    "language_changed": ["Idioma cambiado. Tus datos se conservan.", "Language changed. Your data is kept.",
                         "Язык изменён. Ваши данные сохранены."],
    "resume_title": ["Proyecto en curso", "Project in progress", "Текущий проект"],
    "resume_continue": ["Continuar el proyecto actual (etapa {stage})", "Continue the current project (stage {stage})",
                        "Продолжить текущий проект (этап {stage})"],
    "resume_new": ["Empezar un proyecto nuevo", "Start a new project", "Начать новый проект"],
    "opt_menu": ["Volver al menú principal", "Back to main menu", "Вернуться в главное меню"],
    "opt_confirm": ["Confirmar", "Confirm", "Подтвердить"],
    "opt_modify": ["Modificar", "Modify", "Изменить"],
    "opt_why": ["¿Por qué? (ver el razonamiento)", "Why? (see the reasoning)", "Почему? (показать рассуждение)"],
    "opt_save_record": ["Guardar el registro (texto y JSON)", "Save the record (text and JSON)",
                        "Сохранить протокол (текст и JSON)"],
    "opt_export": ["Exportar al archivo de intercambio de la plataforma", "Export to the platform exchange file",
                   "Экспортировать в файл обмена платформы"],
    "saved_to": ["Guardado en: {path}", "Saved to: {path}", "Сохранено в: {path}"],
    "exported_to": ["Exportado en: {path}", "Exported to: {path}", "Экспортировано в: {path}"],
    "source_label": ["Fuente", "Source", "Источник"],
    "confidence": ["Confianza", "Confidence", "Уверенность"],
    "level_high": ["alta", "high", "высокая"],
    "level_medium": ["media", "medium", "средняя"],
    "level_low": ["baja", "low", "низкая"],
    "alternatives": ["Alternativas", "Alternatives", "Альтернативы"],
    "explanation": ["Explicación", "Explanation", "Объяснение"],
    "stage": ["etapa", "stage", "этап"],
    "draft_label": ["BORRADOR", "DRAFT", "ЧЕРНОВИК"],
    "draft_notice": ["BORRADOR — contenido pendiente de aprobación del responsable académico; no es dato definitivo.",
                     "DRAFT — content pending approval by the academic supervisor; not definitive data.",
                     "ЧЕРНОВИК — содержание ожидает утверждения научным руководителем; не окончательные данные."],
    "reference_notice": ["Dato de referencia del prompt maestro, pendiente de verificar contra la fuente oficial.",
                         "Reference data from the master prompt, pending verification against the official source.",
                         "Справочные данные из мастер-промпта, требуют проверки по официальному источнику."],
    "translation_pending": ["(traducción pendiente de verificación)", "(translation pending verification)",
                            "(перевод ожидает проверки)"],
    "label_student_generic": ["Información del estudiante", "Student information", "Информация студента"],
    "label_decision": ["Decisión del estudiante", "Student decision", "Решение студента"],
    "label_student": ["Información del estudiante", "Student information", "Информация студента"],
    "idea": ["Idea", "Idea", "Идея"],
    "yes": ["sí", "yes", "да"],
    "no": ["no", "no", "нет"],
    "none": ["ninguno", "none", "нет"],
    "missing_name": ["(nombre no documentado)", "(name not documented)", "(название не задокументировано)"],
    "no_documented_info": ["sin información documentada", "no documented information", "нет задокументированной информации"],
    "file_label": ["Archivo", "File", "Файл"],
}


def main():
    out = os.path.join(ROOT, "isppr_platform", "locales")
    os.makedirs(out, exist_ok=True)
    for i, lang in enumerate(("es", "en", "ru")):
        with open(os.path.join(out, f"{lang}.json"), "w", encoding="utf-8") as fh:
            json.dump({k: v[i] for k, v in T.items()}, fh, ensure_ascii=False, indent=2)
    print("locales comunes:", len(T))


if __name__ == "__main__":
    main()
