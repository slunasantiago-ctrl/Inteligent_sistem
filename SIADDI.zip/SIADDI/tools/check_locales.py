"""Comprueba que toda clave de texto usada en el código existe en es/en/ru (A4, A20)."""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from isppr_platform.i18n import Translator  # noqa: E402

PAT_TUPLE = re.compile(r"""\(\s*['"][a-z0-9?\-]{1,4}['"],\s*['"]([a-z_]+)['"]\)""")
PAT_LOG = re.compile(r"""(?:log\(\d,|decisions\.append\(\[\d,)\s*['"]([a-z_]+)['"]""")
PAT = re.compile(r"""(?:\bt|ask_text|ask_int|ask_int_list|ask_float|yes_no|ask_choice_key)\(\s*['"]([a-z0-9_]+)['"]""")
FALSE = {"accent", "pedagogical", "base", "body", "element", "float", "shape", "frequency", "names", "source", "instance_count", "clave", "x", "_sheet", "cr_threshold", "data_quality", "description", "designation", "edition", "improving", "worsening", "mean_shift_mm", "min_respondents", "parameters", "principle_names", "principles", "rejections", "restrictions", "scale", "standards", "status", "type", "units", "wall_thickness_rel", "distribution", "categories", "check", "criteria_templates", "decision_goals", "default", "guiding_questions", "has_structure", "kind", "level", "lifecycle", "lifecycle_ids", "meta", "qms_state", "relation", "relation_to_iso9001", "role", "roles", "ru", "sectors", "text", "title", "transition", "verified_on", "evidence", "action", "question", "central_object", "application"}


def keys_in(paths):
    found = set()
    for base in paths:
        for dirpath, _d, files in os.walk(base):
            if "tests" in dirpath:
                continue
            for f in files:
                if f.endswith(".py"):
                    with open(os.path.join(dirpath, f), encoding="utf-8") as fh:
                        src = fh.read()
                        found |= set(PAT.findall(src)) | set(PAT_TUPLE.findall(src)) | set(PAT_LOG.findall(src))
    return {k for k in found - FALSE if not k.endswith("_")}


def check(sub):
    tr = Translator(os.path.join(ROOT, "subsystems", sub, "locales"))
    keys = keys_in([os.path.join(ROOT, "subsystems", sub), os.path.join(ROOT, "isppr_platform")])
    missing = {lang: sorted(k for k in keys if k not in tr.keys(lang)) for lang in ("es", "en", "ru")}
    return missing


if __name__ == "__main__":
    bad = False
    for sub in sys.argv[1:] or ["conceptual_design", "quality_management", "form_synthesis"]:
        if not os.path.isdir(os.path.join(ROOT, "subsystems", sub)):
            continue
        miss = check(sub)
        for lang, keys in miss.items():
            if keys:
                bad = True
                print(f"{sub} [{lang}] faltan: {', '.join(keys)}")
    print("OK" if not bad else "HAY CLAVES FALTANTES")
    sys.exit(1 if bad else 0)
