"""Genera los archivos de datos del subsistema 1 a partir del Anexo A (A28–A31).

Se conserva en el proyecto para que la procedencia de cada dato sea trazable.
No añade contenido TRIZ que no esté en el prompt maestro (A17, A27.4).
"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SUB = os.path.join(ROOT, "subsystems", "conceptual_design")
DATA = os.path.join(SUB, "data")
DEMO = os.path.join(DATA, "demo")

SRC_A1 = ("Anexo A.1 del prompt maestro (nombres de referencia); pendiente de verificar contra "
          "«TRIZ 40 Inventive Principles — Structured» (A28)")
SRC_A2 = ("Anexo A.2 del prompt maestro (nombres, frecuencia e instancias de referencia); pendiente de "
          "verificar contra «TRIZ 40 Inventive Principles — Structured» (A28)")

PARAMS = [
    (1, "Peso del objeto móvil", "Weight of moving object", "Вес движущегося объекта"),
    (2, "Peso del objeto estacionario", "Weight of stationary object", "Вес неподвижного объекта"),
    (3, "Longitud del objeto móvil", "Length of moving object", "Длина движущегося объекта"),
    (4, "Longitud del objeto estacionario", "Length of stationary object", "Длина неподвижного объекта"),
    (5, "Área del objeto móvil", "Area of moving object", "Площадь движущегося объекта"),
    (6, "Área del objeto estacionario", "Area of stationary object", "Площадь неподвижного объекта"),
    (7, "Volumen del objeto móvil", "Volume of moving object", "Объём движущегося объекта"),
    (8, "Volumen del objeto estacionario", "Volume of stationary object", "Объём неподвижного объекта"),
    (9, "Velocidad", "Speed", "Скорость"),
    (10, "Fuerza (Intensidad)", "Force (Intensity)", "Сила (интенсивность)"),
    (11, "Tensión o presión", "Stress or pressure", "Напряжение или давление"),
    (12, "Forma", "Shape", "Форма"),
    (13, "Estabilidad del objeto", "Stability of the object", "Устойчивость объекта"),
    (14, "Resistencia", "Strength", "Прочность"),
    (15, "Durabilidad del objeto móvil", "Durability of moving object", "Долговечность движущегося объекта"),
    (16, "Durabilidad del objeto no móvil", "Durability of non moving object", "Долговечность неподвижного объекта"),
    (17, "Temperatura", "Temperature", "Температура"),
    (18, "Intensidad de iluminación", "Illumination intensity", "Интенсивность освещения"),
    (19, "Uso de energía por objeto móvil", "Use of energy by moving object", "Использование энергии движущимся объектом"),
    (20, "Uso de energía por objeto estacionario", "Use of energy by stationary object", "Использование энергии неподвижным объектом"),
    (21, "Potencia", "Power", "Мощность"),
    (22, "Pérdida de energía", "Loss of Energy", "Потеря энергии"),
    (23, "Pérdida de sustancia", "Loss of substance", "Потеря вещества"),
    (24, "Pérdida de información", "Loss of Information", "Потеря информации"),
    (25, "Pérdida de tiempo", "Loss of Time", "Потеря времени"),
    (26, "Cantidad de sustancia/material", "Quantity of substance/the matter", "Количество вещества"),
    (27, "Fiabilidad", "Reliability", "Надёжность"),
    (28, "Precisión de medición", "Measurement accuracy", "Точность измерения"),
    (29, "Precisión de fabricación", "Manufacturing precision", "Точность изготовления"),
    (30, "Factores dañinos actuando sobre el objeto", "Object-affected harmful", "Вредные факторы, действующие на объект"),
    (31, "Factores dañinos generados por el objeto", "Object-generated harmful", "Вредные факторы, генерируемые объектом"),
    (32, "Facilidad de fabricación", "Ease of manufacture", "Простота изготовления"),
    (33, "Facilidad de operación", "Ease of operation", "Удобство эксплуатации"),
    (34, "Facilidad de reparación", "Ease of repair", "Простота ремонта"),
    (35, "Adaptabilidad o versatilidad", "Adaptability or versatility", "Адаптивность или универсальность"),
    (36, "Complejidad del dispositivo", "Device complexity", "Сложность устройства"),
    (37, "Dificultad de detección", "Difficulty of detecting", "Сложность обнаружения"),
    (38, "Extensión de automatización", "Extent of automation", "Степень автоматизации"),
    (39, "Productividad", "Productivity", "Производительность"),
]

FREQ = {
    "Muy usado": {"es": "Muy usado", "en": "Very frequently used", "ru": "Очень часто используемый"},
    "Moderadamente usado": {"es": "Moderadamente usado", "en": "Moderately used", "ru": "Умеренно используемый"},
    "Raramente usado": {"es": "Raramente usado", "en": "Rarely used", "ru": "Редко используемый"},
}

PRINCIPLES = [
    (1, "Segmentación", "Segmentation", "Сегментация", "Muy usado", 222),
    (2, "Extracción", "Taking Out", "Извлечение", "Muy usado", 222),
    (3, "Calidad local", "Local Quality", "Местное качество", "Moderadamente usado", 127),
    (4, "Asimetría", "Asymmetry", "Асимметрия", "Raramente usado", 75),
    (5, "Fusión", "Merging", "Объединение", "Raramente usado", 35),
    (6, "Universalidad", "Universality", "Универсальность", "Moderadamente usado", 127),
    (7, "Muñeca rusa", "Nested Doll", "Матрёшка", "Raramente usado", 36),
    (8, "Contrapeso", "Anti-Weight", "Антивес", "Raramente usado", 44),
    (9, None, "Preliminary Anti-Action", "Предварительное антидействие", "Moderadamente usado", 274),
    (10, "Acción previa", "Preliminary Action", "Предварительное действие", "Muy usado", 274),
    (11, "Amortiguación previa", "Beforehand Cushioning", "Предварительная амортизация", "Raramente usado", 49),
    (12, "Equipotencialidad", "Equipotentiality", "Эквипотенциальность", "Raramente usado", 32),
    (13, "Inversión", "The Other Way Round", "Наоборот", "Moderadamente usado", 141),
    (14, "Esferoidalidad - Curvatura", "Spheroidality - Curvature", "Сфероидальность - кривизна", "Raramente usado", 83),
    (15, "Dinamismo", "Dynamics", "Динамичность", "Moderadamente usado", 159),
    (16, "Acciones parciales o excesivas", "Partial or Excessive Actions", "Частичные или избыточные действия", "Moderadamente usado", 99),
    (17, "Otra dimensión", "Another Dimension", "Другое измерение", "Raramente usado", 87),
    (18, "Vibración mecánica", "Mechanical Vibration", "Механическая вибрация", "Moderadamente usado", 163),
    (19, "Acción periódica", "Periodic Action", "Периодическое действие", "Moderadamente usado", 158),
    (20, "Continuidad de acción útil", "Continuity of Useful Action", "Непрерывность полезного действия", "Raramente usado", 19),
    (21, "Salto", "Skipping", "Пропуск", "Raramente usado", 19),
    (22, "Bendición disfrazada", "Blessing in Disguise", "Извлечение пользы из вреда", "Raramente usado", 84),
    (23, "Retroalimentación", "Feedback", "Обратная связь", "Raramente usado", 35),
    (24, "Intermediario", "Intermediary", "Посредник", "Raramente usado", 92),
    (25, "Autoservicio", "Self-Service", "Самообслуживание", "Raramente usado", 49),
    (26, "Copia", "Copying", "Копирование", "Moderadamente usado", 140),
    (27, "Objetos baratos de corta vida", "Cheap Short-Living Objects", "Дешёвые недолговечные объекты", "Moderadamente usado", 122),
    (28, "Sustitución de mecánica", "Mechanics Substitution", "Замена механики", "Muy usado", 229),
    (29, "Neumática e hidráulica", "Pneumatics and Hydraulics", "Пневматика и гидравлика", "Moderadamente usado", 118),
    (30, "Películas flexibles y membranas", "Flexible Shells and Thin Films", "Гибкие оболочки и тонкие плёнки", "Raramente usado", 67),
    (31, "Materiales porosos", "Porous Materials", "Пористые материалы", "Raramente usado", 47),
    (32, "Cambios de color", "Color Changes", "Изменение цвета", "Moderadamente usado", 147),
    (33, "Homogeneidad", "Homogeneity", "Однородность", "Raramente usado", 31),
    (34, "Desecho y recuperación", "Discarding and Recovering", "Отбрасывание и восстановление", "Moderadamente usado", 105),
    (35, "Cambios de parámetros", "Parameter Changes", "Изменение параметров", "Muy usado", 413),
    (36, "Transiciones de fase", "Phase Transitions", "Фазовые переходы", "Raramente usado", 60),
    (37, "Expansión térmica", "Thermal Expansion", "Тепловое расширение", "Raramente usado", 60),
    (38, "Oxidantes fuertes", "Strong Oxidants", "Сильные окислители", "Raramente usado", 48),
    (39, "Atmósfera inerte", "Inert Atmosphere", "Инертная атмосфера", "Raramente usado", 77),
    (40, "Materiales compuestos", "Composite Materials", "Композитные материалы", "Raramente usado", 95),
]

INDUSTRIES = ["aerospace_defense", "food", "automotive_transport", "consumer_goods", "chemistry_materials",
              "construction_building", "electronics_electrical", "energy", "software_it", "medical_pharma"]


def empty3():
    return {"es": None, "en": None, "ru": None}


def parameters():
    items = []
    for pid, es, en, ru in PARAMS:
        items.append({
            "id": pid, "number": pid, "controlled_name": en,
            "names": {"es": es, "en": en, "ru": ru},
            "descriptions": empty3(), "synonyms": {"es": [], "en": [], "ru": []},
            "examples": {"es": [], "en": [], "ru": []},
            "status": "reference", "source": SRC_A1,
        })
    return {"meta": {"source": SRC_A1, "verified_on": None,
                     "note": "Descripciones, sinónimos y ejemplos pendientes (A26.11.4): cargar con "
                             "setup_data.py conceptual_design import-parameters"},
            "parameters": items}


def principles(enriched_demo=False):
    items = []
    for pid, es, en, ru, freq, count in PRINCIPLES:
        item = {
            "id": pid, "number": pid,
            "names": {"es": es, "en": en, "ru": ru},
            "definition": None, "examples": None, "asit_bridge": None,
            "industry_examples": {},
            "frequency": {"label": FREQ[freq], "instance_count": count},
            "contradictions_solved": [],
            "guiding_questions": None,
            "status": "reference", "source": SRC_A2,
        }
        items.append(item)
    if enriched_demo:
        p1 = items[0]
        # Únicamente los ejemplos ilustrativos de A.3 y las preguntas del ejemplo de A10.
        p1["examples"] = {
            "es": ["Aspiradora desmontable", "Montaña rusa multi-coche", "Patinete plegable",
                   "Paracaídas con celdas", "Mueble flat-pack", "Tren articulado"],
            "en": ["Detachable vacuum cleaner", "Multi-car roller coaster", "Folding scooter",
                   "Cell parachute", "Flat-pack furniture", "Articulated train"],
            "ru": ["Разборный пылесос", "Многовагонные американские горки", "Складной самокат",
                   "Секционный парашют", "Мебель в плоской упаковке", "Сочленённый поезд"],
        }
        p1["guiding_questions"] = {
            "es": ["¿Puedes dividir el producto en partes?",
                   "¿Puedes hacer que sus componentes sean desmontables?",
                   "¿Puede cada componente cumplir una función diferente?"],
            "en": ["Can you divide the product into parts?",
                   "Can you make its components detachable?",
                   "Can each component perform a different function?"],
            "ru": ["Можно ли разделить изделие на части?",
                   "Можно ли сделать его компоненты съёмными?",
                   "Может ли каждый компонент выполнять свою функцию?"],
        }
        p1["source"] = "DEMO: ejemplos ilustrativos de A.3 y preguntas del ejemplo de A10 (no verificados)"
        for it in items:
            it["status"] = "demo"
    return {"meta": {"source": SRC_A2, "verified_on": None,
                     "note": "Contenido enriquecido de 27.2 pendiente de la fuente (A27.4, A26.11.3)",
                     "industries": INDUSTRIES},
            "principles": items}


GLOSSARY = {
    "meta": {"note": "Términos TRIZ cuya traducción se ha decidido (A26.11.5)."},
    "terms": [
        {"term_id": "principle_9_name", "target": {"kind": "principle", "id": 9, "field": "names"},
         "values": {"es": "Antiacción previa", "en": "Preliminary Anti-Action", "ru": "Предварительное антидействие"},
         "status": "provisional",
         "source": "Nota 2 del Anexo A.2: «Antiacción previa» es más fiel a Preliminary Anti-Action; "
                   "pendiente de aprobación del responsable académico"},
        {"term_id": "parameter_26_en", "target": {"kind": "parameter", "id": 26, "field": "names"},
         "values": {"en": "Quantity of substance/the matter"}, "status": "provisional",
         "source": "Nota 1 del Anexo A.1: nombre TRIZ estándar; verificar contra la fuente"},
    ],
}

MATRIX_EMPTY = {
    "meta": {"matrix_status": "empty", "source": None, "verified_on": None,
             "format": "cells['mejora x empeora'] = [principios]; cargar con setup_data.py "
                       "conceptual_design import-matrix archivo.csv --source \"...\" (A26.11.1)"},
    "cells": {},
}

MATRIX_DEMO = {
    "meta": {"matrix_status": "partial", "source": "DEMO — valor ilustrativo del documento 2 citado en A.3 "
             "(14 × 2 → 1, 10, 35). No es la matriz real.", "verified_on": None},
    "cells": {"14x2": [1, 10, 35]},
}

# Léxico de la capa de interpretación lingüística (A12, A13, A26.11.6).
# No es contenido TRIZ: asocia palabras del estudiante con IDs de parámetros.
CONCEPTS = {
    "meta": {"status": "provisional",
             "source": "Léxico redactado por el equipo de desarrollo para la interpretación (A26.11.6); "
                       "revisar y aprobar por el responsable académico",
             "note": "stems = raíces; coinciden por prefijo tras normalizar (minúsculas, sin acentos)."},
    "concepts": [
        {"concept_id": "strength", "parameter_ids": [14, 13], "stems": {
            "es": ["resisten", "robust", "solid", "fuerte", "rigid", "aguant", "soport", "firme"],
            "en": ["strong", "strength", "robust", "sturd", "rigid", "durab", "withstand", "solid"],
            "ru": ["прочн", "крепк", "жестк", "выдерж"]}},
        {"concept_id": "weight", "parameter_ids": [2, 1], "stems": {
            "es": ["peso", "pesad", "liger", "livian", "lever"],
            "en": ["weight", "weigh", "heavy", "heavier", "lightweight", "lighter"],
            "ru": ["вес", "тяжел", "легк", "легч"]}},
        {"concept_id": "transport", "parameter_ids": [1, 2], "stems": {
            "es": ["transport", "portatil", "llevar", "mover", "cargar", "traslad"],
            "en": ["transport", "portab", "carry", "move", "moving", "mobil"],
            "ru": ["транспорт", "переноси", "переносн", "перемещ", "носить", "переноз"]}},
        {"concept_id": "size_length", "parameter_ids": [4, 3], "stems": {
            "es": ["largo", "longitud", "alto", "altura", "corto"],
            "en": ["long", "length", "tall", "height", "short"],
            "ru": ["длин", "высот", "коротк"]}},
        {"concept_id": "area", "parameter_ids": [6, 5], "stems": {
            "es": ["area", "superficie", "ancho"],
            "en": ["area", "surface", "wide", "width", "footprint"],
            "ru": ["площад", "поверхност", "ширин"]}},
        {"concept_id": "volume_space", "parameter_ids": [8, 7], "stems": {
            "es": ["volumen", "espacio", "compact", "pequen", "voluminos", "grande", "guardar", "almacen", "ocupa"],
            "en": ["volume", "space", "compact", "small", "bulky", "large", "store", "storage"],
            "ru": ["объем", "мест", "компакт", "небольш", "маленьк", "громозд", "больш", "хранен", "занима"]}},
        {"concept_id": "speed", "parameter_ids": [9], "stems": {
            "es": ["velocidad", "rapid", "lento"], "en": ["speed", "fast", "quick", "slow"],
            "ru": ["скорост", "быстр", "медлен"]}},
        {"concept_id": "force", "parameter_ids": [10], "stems": {
            "es": ["fuerza", "empuj"], "en": ["force", "push", "pull"], "ru": ["сил", "усили"]}},
        {"concept_id": "stress", "parameter_ids": [11], "stems": {
            "es": ["presion", "tension"], "en": ["pressure", "stress"], "ru": ["давлен", "напряжен"]}},
        {"concept_id": "shape", "parameter_ids": [12], "stems": {
            "es": ["forma", "estetic", "apariencia"], "en": ["shape", "form", "aesthetic", "appearance"],
            "ru": ["форм", "эстетик", "внешн"]}},
        {"concept_id": "stability", "parameter_ids": [13], "stems": {
            "es": ["estab", "equilibr", "vuelc", "tambale"], "en": ["stab", "balance", "tip over", "wobbl"],
            "ru": ["устойчив", "равновес", "опрокид", "шата"]}},
        {"concept_id": "durability", "parameter_ids": [16, 15], "stems": {
            "es": ["durabil", "duradero", "dure", "vida util", "desgast"], "en": ["durab", "lasting", "lifespan", "wear"],
            "ru": ["долговеч", "износ", "срок служб"]}},
        {"concept_id": "temperature", "parameter_ids": [17], "stems": {
            "es": ["temperatura", "calor", "calient", "frio"], "en": ["temperature", "heat", "hot", "cold"],
            "ru": ["температур", "тепл", "горяч", "холод"]}},
        {"concept_id": "illumination", "parameter_ids": [18], "stems": {
            "es": ["ilumin", "luz", "luminos", "brillo"], "en": ["illumin", "light output", "bright", "lighting"],
            "ru": ["освещ", "свет", "ярк"]}},
        {"concept_id": "energy", "parameter_ids": [20, 19, 22], "stems": {
            "es": ["energia", "consum", "bateria", "electric"], "en": ["energy", "consumption", "battery", "electric"],
            "ru": ["энерг", "потреблен", "батаре", "электр"]}},
        {"concept_id": "power", "parameter_ids": [21], "stems": {
            "es": ["potencia"], "en": ["power"], "ru": ["мощност"]}},
        {"concept_id": "material_waste", "parameter_ids": [23, 26], "stems": {
            "es": ["material", "desperdic", "residu"], "en": ["material", "waste"], "ru": ["материал", "отход"]}},
        {"concept_id": "time", "parameter_ids": [25], "stems": {
            "es": ["tiempo", "demora", "tard"], "en": ["time", "delay"], "ru": ["время", "времени", "задерж"]}},
        {"concept_id": "reliability", "parameter_ids": [27], "stems": {
            "es": ["fiab", "confiab", "falla", "averi"], "en": ["reliab", "failure", "fail"],
            "ru": ["надежн", "отказ", "поломк"]}},
        {"concept_id": "precision", "parameter_ids": [29, 28], "stems": {
            "es": ["precision", "exactitud", "toleranc"], "en": ["precision", "accuracy", "tolerance"],
            "ru": ["точност", "допуск"]}},
        {"concept_id": "harm", "parameter_ids": [31, 30], "stems": {
            "es": ["dano", "danin", "segur", "peligr", "lesion"], "en": ["harm", "damage", "safety", "danger", "injur"],
            "ru": ["вред", "безопас", "опасн", "травм"]}},
        {"concept_id": "manufacture", "parameter_ids": [32], "stems": {
            "es": ["fabric", "produc", "manufact", "costo", "barat"], "en": ["manufactur", "produc", "cost", "cheap"],
            "ru": ["изготовл", "производ", "стоимост", "дешев"]}},
        {"concept_id": "ease_of_use", "parameter_ids": [33], "stems": {
            "es": ["facil de usar", "comod", "ergonom", "uso", "usar", "manej"],
            "en": ["easy to use", "comfort", "ergonom", "usab", "handl"],
            "ru": ["удобн", "эргоном", "пользован", "эксплуатац"]}},
        {"concept_id": "repair", "parameter_ids": [34], "stems": {
            "es": ["repar", "mantenim", "desmont"], "en": ["repair", "maintain", "maintenance", "disassembl"],
            "ru": ["ремонт", "обслужив", "разбор"]}},
        {"concept_id": "versatility", "parameter_ids": [35], "stems": {
            "es": ["versatil", "adapt", "ajustab", "modular", "plegab"],
            "en": ["versatil", "adapt", "adjustab", "modular", "fold"],
            "ru": ["универсал", "адаптив", "регулир", "модульн", "складн"]}},
        {"concept_id": "complexity", "parameter_ids": [36], "stems": {
            "es": ["complej", "complic", "piezas"], "en": ["complex", "complicat", "parts"],
            "ru": ["сложн", "детал"]}},
        {"concept_id": "productivity", "parameter_ids": [39], "stems": {
            "es": ["productiv", "rendimiento"], "en": ["productiv", "throughput", "output"],
            "ru": ["производительн"]}},
    ],
}

MARKERS = {
    "meta": {"status": "provisional", "source": "A26.11.6 (marcadores enumerados en el prompt maestro) "
             "+ variantes del equipo de desarrollo"},
    "contrast": {
        "es": ["pero", "aunque", "sin embargo", "a costa de", "pero tambien", "mientras que", "no obstante", "a la vez"],
        "en": ["but", "however", "while", "at the expense of", "yet", "although", "whereas"],
        "ru": ["но", "однако", "при этом", "за счет", "хотя", "а также", "вместе с тем"],
    },
    "worsen_cues": {
        "es": ["pesad", "aumenta", "mas pesad", "fragil", "se rompe", "complic", "caro", "dificil", "lento", "empeora"],
        "en": ["heavy", "heavier", "increase", "fragile", "breaks", "complicat", "expensive", "difficult", "slow", "worse"],
        "ru": ["тяжел", "увелич", "хрупк", "ломает", "дорог", "трудн", "медлен", "ухудш"],
    },
    "direction_increase": {"es": ["aumentar", "mas", "mayor"], "en": ["increase", "more", "greater"],
                           "ru": ["увеличить", "больше", "выше"]},
    "direction_decrease": {"es": ["reducir", "menos", "menor", "disminuir"], "en": ["reduce", "less", "lower", "decrease"],
                           "ru": ["уменьшить", "меньше", "снизить"]},
    "negations": {"es": ["no", "sin", "nunca"], "en": ["not", "no", "without", "never"], "ru": ["не", "без", "нет"]},
}

EVAL_SENTENCES = {
    "meta": {"status": "provisional", "source": "Oraciones anotadas por el equipo de desarrollo (A26.11.6); "
             "no son datos TRIZ. Ampliar y anotar por el equipo académico."},
    "sentences": [
        {"lang": "es", "text": "La silla debe ser resistente pero también fácil de transportar.", "improve": 14, "worsen": [2, 1]},
        {"lang": "en", "text": "The chair must be strong but also easy to transport.", "improve": 14, "worsen": [2, 1]},
        {"lang": "ru", "text": "Стул должен быть прочным, но при этом легко транспортироваться.", "improve": 14, "worsen": [2, 1]},
        {"lang": "es", "text": "Quiero que la lámpara ilumine mucho, pero consume demasiada energía.", "improve": 18, "worsen": [20, 19, 22]},
        {"lang": "en", "text": "I want the lamp to give bright lighting, but it uses too much energy.", "improve": 18, "worsen": [20, 19, 22]},
        {"lang": "ru", "text": "Лампа должна ярко освещать стол, но потребляет слишком много энергии.", "improve": 18, "worsen": [20, 19, 22]},
        {"lang": "es", "text": "La mesa es muy estable, pero ocupa demasiado espacio en el apartamento.", "improve": 13, "worsen": [8, 7]},
        {"lang": "en", "text": "The table is very stable, but it takes too much space in the apartment.", "improve": 13, "worsen": [8, 7]},
        {"lang": "ru", "text": "Стол очень устойчивый, но занимает слишком много места в квартире.", "improve": 13, "worsen": [8, 7]},
    ],
}


def write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)


def main():
    for base, demo in ((DATA, False), (DEMO, True)):
        p = parameters()
        if demo:
            for it in p["parameters"]:
                it["status"] = "demo"
        write(os.path.join(base, "parameters.json"), p)
        write(os.path.join(base, "principles.json"), principles(enriched_demo=demo))
        write(os.path.join(base, "glossary.json"), GLOSSARY)
        write(os.path.join(base, "contradiction_matrix.json"), MATRIX_DEMO if demo else MATRIX_EMPTY)
        write(os.path.join(base, "concepts.json"), CONCEPTS)
        write(os.path.join(base, "markers.json"), MARKERS)
        write(os.path.join(base, "evaluation_sentences.json"), EVAL_SENTENCES)
    print("datos del subsistema 1 generados")


if __name__ == "__main__":
    main()
