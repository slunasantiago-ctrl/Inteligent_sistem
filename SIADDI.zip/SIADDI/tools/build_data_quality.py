"""Genera los datos del subsistema 2 — SIADEC — a partir del Anexo B (B31–B37).

Reproduce la matriz fuente (B.1), la estructura de referencia de ISO 9001:2015 (B.4,
solo números y títulos), las normas candidatas (B.4) y el borrador de consejos (B.5).
Todo lo que el prompt marca como «a verificar» o «borrador» se guarda con ese estado.
"""
import copy
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SUB = os.path.join(ROOT, "subsystems", "quality_management")
DATA = os.path.join(SUB, "data")
DEMO = os.path.join(DATA, "demo")
TODAY = "2026-10-17"

SRC_B1 = "Documento fuente de la matriz de estandarización entregado por el usuario (Anexo B.1)"
SRC_B4 = ("Anexo B.4 del prompt maestro — referencia a verificar contra el texto oficial de ISO 9001 "
          "(solo números y títulos, sin texto de la norma, B30)")
SRC_TEAM = "Redactado por el equipo de desarrollo; pendiente de aprobación del responsable académico"


def tri(es=None, en=None, ru=None):
    return {"es": es, "en": en, "ru": ru}


LINES = [
    {"line_id": 2, "source_point": 2,
     "text": tri("Bases científico-prácticas de la regulación técnica, estandarización, tipificación, catalogación, aseguramiento metrológico, gestión de la calidad y confirmación de conformidad.",
                 None,
                 "Научно-практические основы технического регулирования, стандартизации, типизации, каталогизации, метрологического обеспечения, управления качеством и подтверждения соответствия."),
     "central_object": tri("Regulación técnica y estandarización"),
     "type": tri("Estandarización normativa, metrológica y de conformidad"),
     "application": tri("Productos, servicios y sistemas de calidad"),
     "relation": tri("Directa y nuclear: la estandarización es uno de los ejes explícitos junto con la regulación técnica y la metrología.")},
    {"line_id": 3, "source_point": 3,
     "text": tri("Bases científicas y perfeccionamiento de los métodos de estandarización de la gestión de la calidad (control, gestión, aseguramiento, mejora, planificación de la calidad) de objetos y servicios en las distintas etapas del ciclo de vida del producto.",
                 None,
                 "Научные основы и совершенствование методов стандартизации менеджмента качества (контроль, управление, обеспечение, повышение, планирование качества) объектов и услуг на различных стадиях жизненного цикла продукции."),
     "central_object": tri("Métodos de estandarización aplicados a la gestión de la calidad"),
     "type": tri("Estandarización de procesos y sistemas de gestión"),
     "application": tri("Ciclo de vida del producto (diseño, producción, servicio, etc.)"),
     "relation": tri("Directa: la estandarización se aplica a todos los componentes de la gestión de la calidad.")},
    {"line_id": 5, "source_point": 5,
     "text": tri("Métodos de evaluación de la calidad de objetos, estandarización y procesos de gestión de la calidad.",
                 None, "Методы оценки качества объектов, стандартизации и процессов управления качеством."),
     "central_object": tri("Métodos de evaluación y estandarización"),
     "type": tri("Estandarización de métodos de evaluación y procesos"),
     "application": tri("Objetos, procesos y sistemas de gestión de la calidad"),
     "relation": tri("Directa: la estandarización aparece como componente explícito de los métodos de evaluación y gestión.")},
    {"line_id": 6, "source_point": 6,
     "text": tri("Métodos de estandarización y gestión de la calidad en tecnologías CALS, sistemas de producción automatizados y digitales.",
                 None, "Методы стандартизации и управления качеством в CALS-технологиях, автоматизированных, цифровых производственных системах."),
     "central_object": tri("Estandarización en entornos digitales y automatizados"),
     "type": tri("Estandarización de tecnologías de la información y producción digital"),
     "application": tri("CALS, sistemas automatizados y digitales de producción"),
     "relation": tri("Directa: la estandarización es el medio para integrar calidad y tecnologías digitales.")},
    {"line_id": 11, "source_point": 11,
     "text": tri("Creación y desarrollo de sistemas de gestión, incluidos los integrados (IMS) sobre la base de ISO 9001, ISO 14001, ISO 45001 y estándares internacionales y nacionales sectoriales afines.",
                 None, "Создание и развитие систем менеджмента, в том числе интегрированных (ИСМ) на основе ИСО 9001, ИСО 14001, ИСО 45001 и смежных отраслевых международных и отечественных стандартов."),
     "central_object": tri("Sistemas de gestión basados en estándares"),
     "type": tri("Estandarización internacional y sectorial"),
     "application": tri("Sistemas integrados de gestión (calidad, ambiente, seguridad laboral)"),
     "relation": tri("Directa: se fundamenta explícitamente en normas ISO y estándares nacionales/sectoriales.")},
]

OBSERVATIONS = {
    "status": "reference", "source": "Observaciones clave que acompañan al documento fuente (Anexo B.2)",
    "items": tri(["Punto 2: la estandarización es parte de un conjunto más amplio (regulación técnica, metrología, conformidad).",
                  "Punto 3: la estandarización se aplica específicamente a los métodos de gestión de la calidad.",
                  "Punto 5: la estandarización se integra en los métodos de evaluación y procesos.",
                  "Punto 6: la estandarización se orienta a tecnologías digitales y automatizadas.",
                  "Punto 11: la estandarización se concreta en normas ISO y sistemas integrados de gestión."]),
    "check": tri("Punto a verificar: la observación 2 agrupa el punto 11 bajo «procesos y sistemas de gestión», "
                 "mientras que la tabla B.1 lo clasifica como «Estandarización internacional y sectorial». "
                 "SIADEC muestra el tipo declarado en la matriz y señala la observación como complementaria."),
}

CLAUSES_2015 = [
    ("4", "Contexto de la organización", "Context of the organization", 1),
    ("4.1", "Comprensión de la organización y de su contexto", "Understanding the organization and its context", 2),
    ("4.2", "Comprensión de las necesidades y expectativas de las partes interesadas", "Understanding the needs and expectations of interested parties", 2),
    ("4.3", "Alcance del sistema de gestión de la calidad", "Determining the scope of the quality management system", 2),
    ("4.4", "Sistema de gestión de la calidad y sus procesos", "Quality management system and its processes", 2),
    ("5", "Liderazgo", "Leadership", 1),
    ("5.1", "Liderazgo y compromiso", "Leadership and commitment", 2),
    ("5.2", "Política", "Policy", 2),
    ("5.3", "Roles, responsabilidades y autoridades", "Organizational roles, responsibilities and authorities", 2),
    ("6", "Planificación", "Planning", 1),
    ("6.1", "Acciones para abordar riesgos y oportunidades", "Actions to address risks and opportunities", 2),
    ("6.2", "Objetivos de la calidad y planificación para lograrlos", "Quality objectives and planning to achieve them", 2),
    ("6.3", "Planificación de los cambios", "Planning of changes", 2),
    ("7", "Apoyo", "Support", 1),
    ("7.1", "Recursos", "Resources", 2),
    ("7.2", "Competencia", "Competence", 2),
    ("7.3", "Toma de conciencia", "Awareness", 2),
    ("7.4", "Comunicación", "Communication", 2),
    ("7.5", "Información documentada", "Documented information", 2),
    ("8", "Operación", "Operation", 1),
    ("8.1", "Planificación y control operacional", "Operational planning and control", 2),
    ("8.2", "Requisitos para los productos y servicios", "Requirements for products and services", 2),
    ("8.3", "Diseño y desarrollo de los productos y servicios", "Design and development of products and services", 2),
    ("8.4", "Control de los procesos, productos y servicios suministrados externamente", "Control of externally provided processes, products and services", 2),
    ("8.5", "Producción y provisión del servicio", "Production and service provision", 2),
    ("8.6", "Liberación de los productos y servicios", "Release of products and services", 2),
    ("8.7", "Control de las salidas no conformes", "Control of nonconforming outputs", 2),
    ("9", "Evaluación del desempeño", "Performance evaluation", 1),
    ("9.1", "Seguimiento, medición, análisis y evaluación", "Monitoring, measurement, analysis and evaluation", 2),
    ("9.2", "Auditoría interna", "Internal audit", 2),
    ("9.3", "Revisión por la dirección", "Management review", 2),
    ("10", "Mejora", "Improvement", 1),
    ("10.1", "Generalidades", "General", 2),
    ("10.2", "No conformidad y acción correctiva", "Nonconformity and corrective action", 2),
    ("10.3", "Mejora continua", "Continual improvement", 2),
]

EDITIONS = [
    {"edition_id": "iso9001_2015", "designation": "ISO 9001:2015", "year": 2015, "amendments": ["Amd 1:2024"],
     "status": "unverified", "verified_on": TODAY, "has_structure": True, "transition": None,
     "source": "Anexo B.4: las fuentes consultadas no coinciden sobre la vigencia; confirmar en ISO o en el organismo nacional",
     "default": True},
    {"edition_id": "iso9001_2026", "designation": "ISO 9001:2026", "year": 2026, "amendments": [],
     "status": "unverified", "verified_on": TODAY, "has_structure": False,
     "transition": "Algunas fuentes indican publicación en septiembre de 2026 con periodo de transición; no confirmado",
     "source": "Anexo B.4: estado no confirmado en la página oficial de ISO; no se carga estructura hasta contar con el texto oficial"},
]

QM_PRINCIPLES = [
    ("customer_focus", "Enfoque al cliente", "Customer focus"),
    ("leadership", "Liderazgo", "Leadership"),
    ("engagement", "Compromiso de las personas", "Engagement of people"),
    ("process_approach", "Enfoque a procesos", "Process approach"),
    ("improvement", "Mejora", "Improvement"),
    ("evidence_based", "Toma de decisiones basada en la evidencia", "Evidence-based decision making"),
    ("relationship", "Gestión de las relaciones", "Relationship management"),
]

THEMES = [
    ("context", ["4.1", "4.2", "4.3", "4.4"], "Contexto y partes interesadas", "Context and interested parties", "Контекст и заинтересованные стороны"),
    ("leadership", ["5.1", "5.2", "5.3"], "Liderazgo y responsabilidades", "Leadership and responsibilities", "Лидерство и ответственность"),
    ("planning_risk", ["6.1", "6.2", "6.3"], "Planificación y riesgos", "Planning and risks", "Планирование и риски"),
    ("support_resources", ["7.1", "7.2", "7.3", "7.4", "7.5"], "Recursos, competencia e información documentada", "Resources, competence and documented information", "Ресурсы, компетентность и документированная информация"),
    ("requirements", ["8.2"], "Requisitos del producto", "Product requirements", "Требования к продукции"),
    ("design_development", ["8.3"], "Diseño y desarrollo", "Design and development", "Проектирование и разработка"),
    ("suppliers", ["8.4"], "Proveedores externos", "External providers", "Внешние поставщики"),
    ("production", ["8.1", "8.5"], "Producción y control", "Production and control", "Производство и управление"),
    ("release", ["8.6"], "Liberación del producto", "Product release", "Выпуск продукции"),
    ("nonconforming", ["8.7", "10.2"], "Producto no conforme y acción correctiva", "Nonconforming output and corrective action", "Несоответствующая продукция и корректирующие действия"),
    ("monitoring_customer", ["9.1"], "Seguimiento y satisfacción del cliente", "Monitoring and customer satisfaction", "Мониторинг и удовлетворённость потребителей"),
    ("internal_audit", ["9.2"], "Auditoría interna", "Internal audit", "Внутренний аудит"),
    ("management_review", ["9.3"], "Revisión por la dirección", "Management review", "Анализ со стороны руководства"),
    ("improvement", ["10.1", "10.3"], "Mejora continua", "Continual improvement", "Постоянное улучшение"),
]

PLAN_SECTIONS = [
    ("ps_context", ["4", "8.2"], "Contexto y requisitos del cliente", "Context and customer requirements", "Контекст и требования потребителя"),
    ("ps_planning", ["6"], "Planificación y riesgos", "Planning and risks", "Планирование и риски"),
    ("ps_support", ["7"], "Recursos, competencia e información documentada", "Resources, competence and documented information", "Ресурсы, компетентность и документированная информация"),
    ("ps_design", ["8.3"], "Diseño y desarrollo", "Design and development", "Проектирование и разработка"),
    ("ps_suppliers", ["8.4"], "Proveedores", "Suppliers", "Поставщики"),
    ("ps_production", ["8.1", "8.5"], "Producción y control", "Production and control", "Производство и управление"),
    ("ps_release", ["8.6"], "Liberación del producto", "Product release", "Выпуск продукции"),
    ("ps_nonconforming", ["8.7"], "Productos no conformes", "Nonconforming products", "Несоответствующая продукция"),
    ("ps_monitoring", ["9"], "Seguimiento, satisfacción del cliente y auditoría", "Monitoring, customer satisfaction and audit", "Мониторинг, удовлетворённость и аудит"),
    ("ps_improvement", ["10"], "Mejora y acciones correctivas", "Improvement and corrective actions", "Улучшение и корректирующие действия"),
]

PROFILE_LISTS = {
    "status": "provisional", "source": SRC_TEAM,
    "roles": [
        {"id": "designs", "names": tri("diseña", "designs", "проектирует"), "stems": {"es": ["diseño", "diseña", "disen"], "en": ["design"], "ru": ["проект", "разраб"]}},
        {"id": "manufactures", "names": tri("fabrica", "manufactures", "изготавливает"), "stems": {"es": ["fabric", "produc", "taller", "manufact"], "en": ["manufactur", "produc", "workshop", "make"], "ru": ["изготав", "производ", "мастерск"]}},
        {"id": "both", "names": tri("diseña y fabrica", "designs and manufactures", "проектирует и изготавливает"), "stems": {}},
        {"id": "service", "names": tri("presta servicio", "provides a service", "оказывает услугу"), "stems": {"es": ["servicio"], "en": ["service"], "ru": ["услуг", "сервис"]}},
    ],
    "lifecycle": [
        {"id": "design", "names": tri("diseño", "design", "проектирование"), "stems": {"es": ["diseñ", "disen", "desarroll"], "en": ["design", "develop"], "ru": ["проектир", "разработ"]}},
        {"id": "production", "names": tri("producción", "production", "производство"), "stems": {"es": ["fabric", "produc", "lote", "taller", "montaj"], "en": ["manufactur", "produc", "batch", "assembl"], "ru": ["производ", "изготов", "парти", "сборк"]}},
        {"id": "service", "names": tri("servicio", "service", "обслуживание"), "stems": {"es": ["servicio", "cliente", "devol", "reclam", "garant", "entreg"], "en": ["service", "customer", "return", "complain", "warranty", "deliver"], "ru": ["обслуж", "клиент", "вернул", "возврат", "жалоб", "гарант", "постав"]}},
        {"id": "unspecified", "names": tri("no especificada", "unspecified", "не указан"), "stems": {}},
    ],
    "qms_state": [
        {"id": "none", "names": tri("ninguna", "none", "отсутствует"), "stems": {"es": ["no tengo", "ningun sistema", "no hay sistema", "desorden"], "en": ["no system", "nothing in place"], "ru": ["нет системы", "отсутств"]}},
        {"id": "informal", "names": tri("informal", "informal", "неформальная"), "stems": {"es": ["ordenar", "informal", "no se que normas", "organizar"], "en": ["organize", "informal", "don't know which standards", "organise"], "ru": ["навести порядок", "неформаль", "не знаю"]}},
        {"id": "implemented", "names": tri("implantada", "implemented", "внедрена"), "stems": {"es": ["implantad", "tenemos un sistema", "ya aplicamos"], "en": ["implemented", "we have a system"], "ru": ["внедрен", "уже есть система"]}},
        {"id": "certifying", "names": tri("en certificación", "in certification", "в процессе сертификации"), "stems": {"es": ["certific"], "en": ["certif"], "ru": ["сертифик"]}},
    ],
    "decision_goals": [
        {"id": "implement_qms", "names": tri("implantar un sistema de gestión de la calidad", "implement a quality management system", "внедрить систему менеджмента качества"), "stems": {"es": ["implantar", "sistema de gestion", "implementar"], "en": ["implement", "quality management system"], "ru": ["внедр", "систем менеджмент"]}},
        {"id": "organize_quality", "names": tri("ordenar la calidad", "organise quality", "навести порядок в качестве"), "stems": {"es": ["ordenar", "organizar"], "en": ["organize", "organise"], "ru": ["навести порядок", "организ"]}},
        {"id": "control_defect", "names": tri("controlar un defecto", "control a defect", "устранить дефект"), "stems": {"es": ["defect", "devol", "flojo", "falla", "reclam", "no conform"], "en": ["defect", "return", "loose", "fail", "complain", "nonconform"], "ru": ["дефект", "вернул", "возврат", "расшат", "брак", "жалоб"]}},
        {"id": "evaluate_suppliers", "names": tri("evaluar proveedores", "evaluate suppliers", "оценить поставщиков"), "stems": {"es": ["proveedor"], "en": ["supplier", "vendor"], "ru": ["поставщик"]}},
        {"id": "prepare_audit", "names": tri("prepararse para una auditoría", "prepare for an audit", "подготовиться к аудиту"), "stems": {"es": ["auditor"], "en": ["audit"], "ru": ["аудит"]}},
        {"id": "certification", "names": tri("buscar la certificación", "seek certification", "пройти сертификацию"), "stems": {"es": ["certific"], "en": ["certif"], "ru": ["сертифик"]}},
        {"id": "integrate_ms", "names": tri("integrar sistemas de gestión", "integrate management systems", "интегрировать системы менеджмента"), "stems": {"es": ["integrad", "ambiental", "14001", "45001", "seguridad laboral"], "en": ["integrated", "environmental", "14001", "45001", "occupational"], "ru": ["интегрир", "экологич", "14001", "45001", "охран труда"]}},
        {"id": "design_control", "names": tri("controlar el diseño", "control the design", "управлять проектированием"), "stems": {"es": ["control del diseno", "verificar el diseno", "validar"], "en": ["design control", "verify the design", "validate"], "ru": ["верификац", "валидац"]}},
    ],
    "sectors": [
        {"id": "consumer_goods", "names": tri("bienes de consumo", "consumer goods", "потребительские товары"), "stems": {"es": ["mueble", "silla", "mesa", "lampara", "hogar", "juguet", "oficina"], "en": ["furniture", "chair", "table", "lamp", "home", "toy", "office"], "ru": ["мебел", "стул", "стол", "ламп", "дом", "игрушк", "офис"]}},
        {"id": "medical", "names": tri("dispositivos médicos", "medical devices", "медицинские изделия"), "stems": {"es": ["medic", "hospital", "clinic"], "en": ["medical", "hospital", "clinic"], "ru": ["медицин", "больниц", "клиник"]}},
        {"id": "automotive", "names": tri("automoción", "automotive", "автомобильная отрасль"), "stems": {"es": ["automo", "vehicul", "coche"], "en": ["automotive", "vehicle", "car "], "ru": ["автомоб", "транспортн средств"]}},
        {"id": "aerospace", "names": tri("aeroespacial", "aerospace", "аэрокосмическая отрасль"), "stems": {"es": ["aeroespac", "aeronau", "avion"], "en": ["aerospace", "aircraft"], "ru": ["авиа", "аэрокосм"]}},
        {"id": "food", "names": tri("alimentación", "food", "пищевая отрасль"), "stems": {"es": ["aliment", "comida", "bebida"], "en": ["food", "beverage"], "ru": ["пищев", "продукт питан", "напит"]}},
        {"id": "construction", "names": tri("construcción", "construction", "строительство"), "stems": {"es": ["construcc", "obra"], "en": ["construction", "building"], "ru": ["строит"]}},
        {"id": "electronics", "names": tri("electrónica", "electronics", "электроника"), "stems": {"es": ["electron", "electric"], "en": ["electronic", "electrical"], "ru": ["электрон", "электрич"]}},
        {"id": "general_manufacturing", "names": tri("manufactura general", "general manufacturing", "общее производство"), "stems": {}},
    ],
    "categories": [
        {"id": "furniture", "names": tri("mobiliario", "furniture", "мебель"), "stems": {"es": ["mueble", "silla", "mesa", "estante", "mobiliario"], "en": ["furniture", "chair", "table", "shelf"], "ru": ["мебел", "стул", "стол", "полк"]}},
        {"id": "lighting", "names": tri("iluminación", "lighting", "освещение"), "stems": {"es": ["lampara", "luminaria", "ilumin"], "en": ["lamp", "luminaire", "lighting"], "ru": ["ламп", "светильн", "освещ"]}},
        {"id": "electronic_product", "names": tri("producto electrónico", "electronic product", "электронное изделие"), "stems": {"es": ["electron", "dispositivo"], "en": ["electronic", "device"], "ru": ["электрон", "устройств"]}},
        {"id": "toy", "names": tri("juguete", "toy", "игрушка"), "stems": {"es": ["juguet"], "en": ["toy"], "ru": ["игрушк"]}},
        {"id": "medical_device", "names": tri("dispositivo médico", "medical device", "медицинское изделие"), "stems": {"es": ["medic"], "en": ["medical"], "ru": ["медицин"]}},
        {"id": "packaging", "names": tri("envase y embalaje", "packaging", "упаковка"), "stems": {"es": ["envase", "embalaj"], "en": ["packag"], "ru": ["упаков"]}},
        {"id": "machinery", "names": tri("maquinaria", "machinery", "машины и оборудование"), "stems": {"es": ["maquin"], "en": ["machine"], "ru": ["машин", "станок", "оборудован"]}},
        {"id": "other", "names": tri("no listada", "not listed", "не в списке"), "stems": {}},
    ],
}

CONCEPTS = {
    "status": "provisional", "source": SRC_TEAM + " (asociaciones derivadas de las palabras de cada línea y del título de cada cláusula, B13)",
    "concepts": [
        {"concept_id": "supplier", "lines": [3], "themes": ["suppliers"], "stems": {"es": ["proveedor", "suministr", "compra"], "en": ["supplier", "vendor", "purchas"], "ru": ["поставщик", "закупк"]}},
        {"concept_id": "defect", "lines": [3, 5], "themes": ["nonconforming", "production", "design_development"], "stems": {"es": ["defect", "flojo", "falla", "roto", "fallo", "no conform"], "en": ["defect", "loose", "fail", "broken", "nonconform"], "ru": ["дефект", "расшат", "брак", "сломан", "несоответств"]}},
        {"concept_id": "complaint", "lines": [5], "themes": ["monitoring_customer", "nonconforming"], "stems": {"es": ["devol", "reclam", "queja", "cliente"], "en": ["return", "complain", "customer"], "ru": ["вернул", "возврат", "жалоб", "претенз", "клиент"]}},
        {"concept_id": "audit", "lines": [5, 11], "themes": ["internal_audit"], "stems": {"es": ["auditor"], "en": ["audit"], "ru": ["аудит"]}},
        {"concept_id": "certification", "lines": [2, 11], "themes": ["context", "leadership"], "stems": {"es": ["certific", "conformidad"], "en": ["certif", "conformity"], "ru": ["сертифик", "соответств"]}},
        {"concept_id": "standards", "lines": [2, 11], "themes": ["requirements"], "stems": {"es": ["norma", "estandar", "iso"], "en": ["standard", "iso", "norm"], "ru": ["стандарт", "норм", "исо", "гост"]}},
        {"concept_id": "design", "lines": [3], "themes": ["design_development", "requirements"], "stems": {"es": ["diseno", "disena", "prototip"], "en": ["design", "prototyp"], "ru": ["проектир", "прототип", "конструкц"]}},
        {"concept_id": "production", "lines": [3], "themes": ["production", "release"], "stems": {"es": ["fabric", "produc", "lote", "taller", "montaj"], "en": ["manufactur", "production", "batch", "workshop", "assembl"], "ru": ["производ", "изготов", "парти", "мастерск", "сборк"]}},
        {"concept_id": "measurement", "lines": [2, 5], "themes": ["support_resources", "monitoring_customer"], "stems": {"es": ["medic", "medir", "calibr", "metrolog", "inspecc", "ensayo"], "en": ["measur", "calibrat", "metrolog", "inspect", "test"], "ru": ["измер", "калибр", "метролог", "контрол", "испытан"]}},
        {"concept_id": "evaluation", "lines": [5], "themes": ["monitoring_customer", "management_review"], "stems": {"es": ["evalu", "indicador", "satisfacc"], "en": ["evaluat", "indicator", "satisfaction", "kpi"], "ru": ["оцен", "показател", "удовлетвор"]}},
        {"concept_id": "digital", "lines": [6], "themes": ["support_resources", "production"], "stems": {"es": ["digital", "automatiz", "cals", "software", "cad", "plm", "erp"], "en": ["digital", "automat", "cals", "software", "cad", "plm", "erp"], "ru": ["цифров", "автоматиз", "cals", "программ", "сапр"]}},
        {"concept_id": "integrated_ms", "lines": [11], "themes": ["context", "planning_risk"], "stems": {"es": ["integrad", "ambiental", "14001", "45001", "seguridad laboral"], "en": ["integrated", "environment", "14001", "45001", "occupational"], "ru": ["интегрир", "экологич", "14001", "45001", "охран труда"]}},
        {"concept_id": "risk", "lines": [3], "themes": ["planning_risk"], "stems": {"es": ["riesgo", "prevenir", "evitar"], "en": ["risk", "prevent", "avoid"], "ru": ["риск", "предотвра", "избежа"]}},
        {"concept_id": "lifecycle", "lines": [3], "themes": ["design_development", "production", "monitoring_customer"], "stems": {"es": ["ciclo de vida"], "en": ["life cycle", "lifecycle"], "ru": ["жизненн цикл", "жизненного цикла"]}},
        {"concept_id": "documentation", "lines": [3], "themes": ["support_resources"], "stems": {"es": ["registro", "document", "procedim", "instrucc"], "en": ["record", "document", "procedure", "instruction"], "ru": ["запис", "документ", "процедур", "инструкц"]}},
        {"concept_id": "competence", "lines": [3], "themes": ["support_resources"], "stems": {"es": ["capacit", "formacion", "personal", "operari"], "en": ["training", "competen", "staff", "operator"], "ru": ["обучен", "компетент", "персонал", "оператор"]}},
        {"concept_id": "improvement", "lines": [3, 5], "themes": ["improvement", "nonconforming"], "stems": {"es": ["mejor", "correctiv", "causa raiz"], "en": ["improv", "corrective", "root cause"], "ru": ["улучш", "корректир", "первопричин"]}},
        {"concept_id": "metrology", "lines": [2], "themes": ["support_resources"], "stems": {"es": ["metrolog", "calibr", "instrumento"], "en": ["metrolog", "calibrat", "instrument"], "ru": ["метролог", "калибр", "прибор"]}},
        {"concept_id": "typification", "lines": [2], "themes": ["requirements"], "stems": {"es": ["tipific", "catalog", "unific"], "en": ["typif", "catalogu", "catalog", "unific"], "ru": ["типизац", "каталогиз", "унификац"]}},
    ],
}


def rule(rule_id, all_=None, any_=None, requires=None):
    return {"rule_id": rule_id, "applies_when": {"all": all_ or [], "any": any_ or []},
            "requires_profile_fields": requires or [], "status": "draft", "source": SRC_TEAM}


ALL_GOALS = ["implement_qms", "organize_quality", "certification", "control_defect", "design_control",
             "evaluate_suppliers", "prepare_audit", "integrate_ms"]

CATALOG = [
    {"standard_id": "iso_9001", "designation": "ISO 9001", "level": "N1", "category": "qms_core",
     "title": tri("Sistemas de gestión de la calidad. Requisitos", "Quality management systems — Requirements", None),
     "edition": "ISO 9001:2015", "edition_id": "iso9001_2015", "status": "unverified", "verified_on": TODAY,
     "role": tri("Marco de requisitos para planificar, controlar y mejorar el diseño, la producción y la entrega."),
     "relation_to_iso9001": tri("Es la norma base del sistema de gestión de la calidad."),
     "rules": [rule("R-QMS-01", [{"field": "decision_goal", "in": ALL_GOALS}],
                    [{"field": "role", "in": ["designs", "manufactures", "both", "service"]}], ["role"])]},
    {"standard_id": "iso_9000", "designation": "ISO 9000", "level": "N2", "category": "qms_support",
     "title": tri("Fundamentos y vocabulario", "Fundamentals and vocabulary", None), "edition": None, "status": "unverified", "verified_on": None,
     "role": tri("Define los términos y los principios en que se basa ISO 9001."), "relation_to_iso9001": tri("Norma de apoyo: vocabulario."),
     "rules": [rule("R-QMS-02", [{"field": "decision_goal", "in": ["implement_qms", "organize_quality", "certification"]}])]},
    {"standard_id": "iso_9004", "designation": "ISO 9004", "level": "N2", "category": "qms_support",
     "title": tri("Orientación para el éxito sostenido de la organización", "Guidance to achieve sustained success", None), "edition": None, "status": "unverified", "verified_on": None,
     "role": tri("Orientación para ir más allá de los requisitos mínimos."), "relation_to_iso9001": tri("Norma de apoyo: orientación de mejora."),
     "rules": [rule("R-QMS-03", [{"field": "qms_state", "in": ["implemented", "certifying"]}], requires=["qms_state"])]},
    {"standard_id": "iso_19011", "designation": "ISO 19011", "level": "N2", "category": "qms_support",
     "title": tri("Directrices para la auditoría de los sistemas de gestión", "Guidelines for auditing management systems", None), "edition": None, "status": "unverified", "verified_on": None,
     "role": tri("Orienta cómo planificar y realizar auditorías internas."), "relation_to_iso9001": tri("Norma de apoyo: auditoría (relación con 9.2)."),
     "rules": [rule("R-AUD-01", [{"field": "decision_goal", "in": ["prepare_audit", "certification"]}])]},
    {"standard_id": "iso_10002", "designation": "ISO 10002 (serie ISO 10001–10004)", "level": "N2", "category": "qms_support",
     "title": tri("Satisfacción del cliente: tratamiento de quejas", "Customer satisfaction — complaints handling", None), "edition": None, "status": "unverified", "verified_on": None,
     "role": tri("Orienta el tratamiento de quejas y la satisfacción del cliente."), "relation_to_iso9001": tri("Norma de apoyo: satisfacción del cliente (relación con 9.1)."),
     "rules": [rule("R-CS-01", [{"field": "decision_goal", "in": ["control_defect"]}])]},
    {"standard_id": "iso_10005", "designation": "ISO 10005", "level": "N2", "category": "qms_support",
     "title": tri("Directrices para los planes de la calidad", "Guidelines for quality plans", None), "edition": None, "status": "unverified", "verified_on": None,
     "role": tri("Orienta cómo redactar un plan de la calidad para un producto."), "relation_to_iso9001": tri("Norma de apoyo: planes de la calidad."),
     "rules": [rule("R-QP-01", [{"field": "decision_goal", "in": ["organize_quality", "design_control", "control_defect"]}])]},
    {"standard_id": "iso_10012", "designation": "ISO 10012", "level": "N2", "category": "qms_support",
     "title": tri("Sistemas de gestión de las mediciones", "Measurement management systems", None), "edition": None, "status": "unverified", "verified_on": None,
     "role": tri("Orienta la gestión de los equipos y procesos de medición."), "relation_to_iso9001": tri("Norma de apoyo: recursos de seguimiento y medición (relación con 7.1)."),
     "rules": [rule("R-MS-01", [{"field": "decision_goal", "in": ["control_defect", "certification"]}],
                    [{"field": "role", "in": ["manufactures", "both"]}], ["role"])]},
    {"standard_id": "iso_14001", "designation": "ISO 14001", "level": "N3", "category": "other_management_system",
     "title": tri("Sistemas de gestión ambiental", "Environmental management systems", None), "edition": None, "status": "unverified", "verified_on": None,
     "role": tri("Sistema de gestión ambiental, integrable con ISO 9001 (línea 11)."), "relation_to_iso9001": tri("Sistema complementario para un sistema integrado."),
     "rules": [rule("R-IMS-01", [{"field": "decision_goal", "in": ["integrate_ms"]}])]},
    {"standard_id": "iso_45001", "designation": "ISO 45001", "level": "N3", "category": "other_management_system",
     "title": tri("Sistemas de gestión de la seguridad y salud en el trabajo", "Occupational health and safety management systems", None), "edition": None, "status": "unverified", "verified_on": None,
     "role": tri("Sistema de gestión de seguridad y salud laboral, integrable con ISO 9001 (línea 11)."), "relation_to_iso9001": tri("Sistema complementario para un sistema integrado."),
     "rules": [rule("R-IMS-02", [{"field": "decision_goal", "in": ["integrate_ms"]}])]},
    {"standard_id": "iso_13485", "designation": "ISO 13485", "level": "N3", "category": "sector_qms",
     "title": tri("Dispositivos médicos — Sistemas de gestión de la calidad", "Medical devices — Quality management systems", None), "edition": None, "status": "unverified", "verified_on": None,
     "role": tri("Sistema de gestión de la calidad específico del sector de dispositivos médicos."), "relation_to_iso9001": tri("Norma sectorial basada en la estructura de gestión de la calidad."),
     "rules": [rule("R-SEC-MED", [{"field": "sector_id", "in": ["medical"]}], requires=["sector_id"])]},
    {"standard_id": "iatf_16949", "designation": "IATF 16949", "level": "N3", "category": "sector_qms",
     "title": tri("Sistema de gestión de la calidad en automoción", "Automotive quality management system", None), "edition": None, "status": "unverified", "verified_on": None,
     "role": tri("Requisitos sectoriales de automoción que complementan ISO 9001."), "relation_to_iso9001": tri("Norma sectorial complementaria de ISO 9001."),
     "rules": [rule("R-SEC-AUTO", [{"field": "sector_id", "in": ["automotive"]}], requires=["sector_id"])]},
    {"standard_id": "iso_22000", "designation": "ISO 22000", "level": "N3", "category": "sector_qms",
     "title": tri("Sistemas de gestión de la inocuidad de los alimentos", "Food safety management systems", None), "edition": None, "status": "unverified", "verified_on": None,
     "role": tri("Sistema de gestión de la inocuidad alimentaria."), "relation_to_iso9001": tri("Norma sectorial complementaria."),
     "rules": [rule("R-SEC-FOOD", [{"field": "sector_id", "in": ["food"]}], requires=["sector_id"])]},
    {"standard_id": "as_9100", "designation": "AS9100 / EN 9100", "level": "N3", "category": "sector_qms",
     "title": tri("Sistemas de gestión de la calidad en aeroespacial", "Aerospace quality management systems", None), "edition": None, "status": "unverified", "verified_on": None,
     "role": tri("Requisitos sectoriales aeroespaciales."), "relation_to_iso9001": tri("Norma sectorial basada en ISO 9001."),
     "rules": [rule("R-SEC-AERO", [{"field": "sector_id", "in": ["aerospace"]}], requires=["sector_id"])]},
]

ADVICE = [
    ("d01", ["4.2", "8.2"], ["design"], [], "Identifica a quienes usan, compran, instalan, mantienen o se ven afectados por el producto y anota sus requisitos de forma verificable.", "Lista de partes interesadas y de requisitos."),
    ("d02", ["8.2"], ["design"], [], "Convierte cada necesidad en un requisito medible, con criterio de aceptación, antes de diseñar.", "Especificación del producto con criterios de aceptación."),
    ("d03", ["6.1"], ["design"], ["risk", "defect"], "Analiza qué puede fallar en el producto, qué tan grave sería y qué tan probable es, y define acciones para reducir los riesgos mayores.", "Registro de riesgos y acciones."),
    ("d04", ["8.3"], ["design"], ["design"], "Planifica el diseño por etapas, con responsables y puntos de revisión.", "Plan de diseño."),
    ("d05", ["8.3"], ["design"], ["design", "defect"], "Realiza revisiones de diseño, verificación (¿cumple lo especificado?) y validación (¿sirve para el uso previsto?) y deja registro.", "Actas de revisión, resultados de pruebas."),
    ("d06", ["8.3"], ["design"], ["design"], "Controla los cambios de diseño: qué cambia, por qué, quién aprueba y qué se vuelve a verificar.", "Registro de cambios."),
    ("d07", ["8.4"], ["production"], ["supplier"], "Evalúa y selecciona proveedores por su capacidad de cumplir tus requisitos; define qué les exiges y cómo verificas lo que recibes.", "Lista de proveedores evaluados y criterios de recepción."),
    ("d08", ["8.5"], ["production"], ["production", "defect"], "Documenta lo necesario para producir de forma repetible: instrucciones, parámetros críticos y controles durante el proceso.", "Instrucciones de trabajo y registros de proceso."),
    ("d09", ["8.5"], ["production"], ["production"], "Si el producto lo exige, identifica lotes y materiales para poder rastrear qué se usó en cada unidad.", "Registro de trazabilidad."),
    ("d10", ["7.1"], ["production"], ["measurement", "metrology"], "Asegura que los instrumentos con que mides y aceptas el producto estén verificados o calibrados y vigentes.", "Registro de calibración o verificación."),
    ("d11", ["8.6"], ["production", "service"], ["production", "defect"], "Define qué verificaciones deben cumplirse antes de entregar un producto y quién autoriza la liberación.", "Registro de liberación."),
    ("d12", ["8.7"], ["production", "service"], ["defect", "complaint"], "Define qué hacer con un producto no conforme: identificarlo, separarlo, decidir (reprocesar, aceptar con autorización, descartar) y registrar.", "Registro de no conformes y decisiones."),
    ("d13", ["9.1"], ["service"], ["complaint", "evaluation"], "Recoge y analiza reclamos, devoluciones y opiniones de los usuarios para detectar problemas de calidad recurrentes.", "Registro y análisis de reclamos."),
    ("d14", ["9.2"], ["all"], ["audit"], "Programa auditorías internas para comprobar que lo que planificaste se cumple.", "Programa y resultados de auditorías."),
    ("d15", ["10.2"], ["all"], ["defect", "complaint", "improvement"], "Ante una no conformidad, corrige, analiza la causa raíz y verifica que la acción haya sido eficaz.", "Registro de acciones correctivas y verificación de eficacia."),
    ("d16", ["7.2", "7.5"], ["all"], ["competence", "documentation"], "Asegura que quien hace tareas críticas esté capacitado y conserva solo la información documentada útil para controlar la calidad.", "Registro de competencias y lista de documentos controlados."),
]

PROFILE_TRIGGERS = {"d04": {"role": ["designs", "both"]}, "d05": {"role": ["designs", "both"]},
                    "d06": {"role": ["designs", "both"]}, "d08": {"role": ["manufactures", "both"]},
                    "d09": {"role": ["manufactures", "both"]}}

PEDAGOGICAL = {
    "status": "draft", "kind": "pedagogical", "source": SRC_TEAM,
    "criteria_templates": [
        {"id": "cost", "names": tri("Costo de implantación", "Implementation cost", "Стоимость внедрения"), "sense": "min"},
        {"id": "time", "names": tri("Tiempo necesario", "Time required", "Необходимое время"), "sense": "min"},
        {"id": "effectiveness", "names": tri("Eficacia sobre el problema", "Effectiveness on the problem", "Эффективность для проблемы"), "sense": "max"},
        {"id": "ease", "names": tri("Facilidad de aplicación", "Ease of application", "Простота применения"), "sense": "max"},
        {"id": "certification_readiness", "names": tri("Preparación para la certificación", "Certification readiness", "Готовность к сертификации"), "sense": "max"},
    ],
    "guiding_questions": {
        "default": tri(["¿Qué procesos de tu taller afectan directamente la calidad del producto?",
                        "¿Qué registros tienes hoy de inspecciones y reclamos?",
                        "¿Qué pasaría si no aplicas esta recomendación?"],
                       ["Which processes in your workshop directly affect product quality?",
                        "What records do you have today of inspections and complaints?",
                        "What would happen if you did not apply this recommendation?"],
                       ["Какие процессы мастерской напрямую влияют на качество изделия?",
                        "Какие записи о контроле и претензиях у вас есть сейчас?",
                        "Что произойдёт, если не применять эту рекомендацию?"]),
    },
}


def write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)


def build(base, demo):
    st_ref = "demo" if demo else "reference"
    lines = copy.deepcopy(LINES)
    for ln in lines:
        ln["status"] = "demo" if demo else "approved"
        ln["source"] = SRC_B1
        ln["short_name"] = tri(None)
    write(os.path.join(base, "standardization_matrix.json"),
          {"meta": {"matrix_status": "complete", "covered_points": [2, 3, 5, 6, 11], "source": SRC_B1,
                    "note": "El documento fuente contiene únicamente los puntos 2, 3, 5, 6 y 11 (B17)."},
           "lines": lines, "observations": OBSERVATIONS})
    eds = copy.deepcopy(EDITIONS)
    if demo:
        for e in eds:
            e["source"] = "DEMO — " + e["source"]
    write(os.path.join(base, "iso9001", "editions.json"), {"editions": eds})
    write(os.path.join(base, "iso9001", "clauses_iso9001_2015.json"),
          {"edition_id": "iso9001_2015", "status": st_ref, "source": SRC_B4,
           "clauses": [{"clause_id": c, "number": c, "title": tri(es, en, None), "level": lvl} for c, es, en, lvl in CLAUSES_2015]})
    write(os.path.join(base, "iso9001", "principles.json"),
          {"status": st_ref, "source": SRC_B4 + "; normalmente en la norma de fundamentos y vocabulario de la serie",
           "principles": [{"principle_id": pid, "names": tri(es, en, None)} for pid, es, en in QM_PRINCIPLES]})
    write(os.path.join(base, "iso9001", "themes.json"),
          {"status": "demo" if demo else "provisional", "source": SRC_TEAM,
           "themes": [{"theme_id": tid, "clauses": {"iso9001_2015": cl}, "names": tri(es, en, ru)} for tid, cl, es, en, ru in THEMES]})
    write(os.path.join(base, "iso9001", "plan_sections.json"),
          {"status": "demo" if demo else "provisional", "source": "Recorrido de ISO 9001 aplicado al producto (B29.3)",
           "sections": [{"section_id": sid, "clause_prefixes": pre, "names": tri(es, en, ru)} for sid, pre, es, en, ru in PLAN_SECTIONS]})
    cat = copy.deepcopy(CATALOG)
    if demo:
        for s in cat:
            for r in s["rules"]:
                r["status"] = "demo"
    write(os.path.join(base, "standards_catalog.json"), {"meta": {"source": SRC_B4 + " (candidatas a verificar)",
                                                                  "note": "N4 (normas técnicas por categoría de producto) pendiente de entrega (B37)"},
                                                         "standards": cat})
    prof = copy.deepcopy(PROFILE_LISTS)
    if demo:
        prof["status"] = "demo"
    write(os.path.join(base, "product_categories.json"), prof)
    conc = copy.deepcopy(CONCEPTS)
    if demo:
        conc["status"] = "demo"
    write(os.path.join(base, "concepts.json"), conc)
    adv = []
    for aid, clauses, life, concepts, action, evidence in ADVICE:
        adv.append({"advice_id": aid, "kind": "normative_derived", "status": "demo" if demo else "draft",
                    "clause_ids": {"iso9001_2015": clauses}, "lifecycle_ids": life,
                    "triggers": {"concepts": concepts, "profile": PROFILE_TRIGGERS.get(aid, {})},
                    "action": tri(action), "evidence": tri(evidence), "question": tri(None),
                    "author": "equipo de desarrollo (borrador B.5)", "approved_by": None,
                    "source": "Anexo B.5 — borrador de consejos; paráfrasis de buenas prácticas, no reproduce la norma"})
    write(os.path.join(base, "advice_library.json"), {"advice": adv})
    ped = copy.deepcopy(PEDAGOGICAL)
    if demo:
        ped["status"] = "demo"
    write(os.path.join(base, "pedagogical_templates.json"), ped)
    write(os.path.join(base, "glossary.json"), {"terms": [
        {"term_id": "ism_ims", "values": tri("SIG (sistema integrado de gestión)", "IMS (integrated management system)", "ИСМ"),
         "status": "provisional", "source": "B.1 nota 2: la sigla ИСМ aparece como «IMS» en la traducción al español"},
        {"term_id": "nonconforming_output", "values": tri("producto no conforme", "nonconforming output", "несоответствующая продукция"), "status": "provisional", "source": SRC_TEAM},
        {"term_id": "corrective_action", "values": tri("acción correctiva", "corrective action", "корректирующее действие"), "status": "provisional", "source": SRC_TEAM},
        {"term_id": "documented_information", "values": tri("información documentada", "documented information", "документированная информация"), "status": "provisional", "source": SRC_TEAM},
        {"term_id": "external_providers", "values": tri("proveedores externos", "external providers", "внешние поставщики"), "status": "provisional", "source": SRC_TEAM},
    ]})


def main():
    build(DATA, False)
    build(DEMO, True)
    print("datos del subsistema 2 generados")


if __name__ == "__main__":
    main()
