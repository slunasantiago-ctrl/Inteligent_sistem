#!/usr/bin/env python3
"""Despachador de carga de datos de la plataforma (P9).

    python3 setup_data.py <subsistema> <comando> [argumentos]
    python3 setup_data.py all status

Subsistemas: conceptual_design (SIADDI), quality_management (SIADEC), form_synthesis (SIADEF).
"""
from __future__ import annotations

import importlib
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

SUBSYSTEMS = {"conceptual_design": "subsystems.conceptual_design.setup_data",
              "quality_management": "subsystems.quality_management.setup_data",
              "form_synthesis": "subsystems.form_synthesis.setup_data",
              "standardization": "subsystems.form_synthesis.setup_data"}


def main(argv=None) -> int:
    from isppr_platform import terminal
    terminal.configure_utf8()
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    target, rest = argv[0], argv[1:]
    if target == "all":
        if rest != ["status"]:
            print("Uso: setup_data.py all status")
            return 1
        for name in ("conceptual_design", "quality_management", "form_synthesis"):
            importlib.import_module(SUBSYSTEMS[name]).main(["status"])
            print()
        return 0
    if target not in SUBSYSTEMS:
        print(f"Subsistema desconocido: {target}. Opciones: {', '.join(SUBSYSTEMS)} o all")
        return 1
    return importlib.import_module(SUBSYSTEMS[target]).main(rest)


if __name__ == "__main__":
    sys.exit(main())
