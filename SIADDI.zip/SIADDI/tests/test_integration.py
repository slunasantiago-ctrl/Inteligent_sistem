"""Pruebas de integración: recorridos completos por la plataforma con entradas guionizadas (P12)."""
import glob
import os
import shutil
import unittest

from tests import _helpers
from isppr_platform import exchange, registry

SIADDI = ["1", "1", "Quiero diseñar una silla para estudiantes que viven en apartamentos pequeños.",
          "La silla debe ser resistente pero también fácil de transportar.", "?", "e", "14", "2", "c",
          "", "s", "a", "u", "i", "Patas desmontables con encastre", "g", "respaldo plegable", "c", "3", "?", "",
          "0", "2", "l", "1", "f", "g", "x", "m", "0"]

SIADEC = ["2", "Diseño y fabrico sillas de madera para oficinas pequeñas. Tengo dos proveedores de madera.", "",
          "Un cliente devolvió un lote con patas flojas y no sé qué normas debo seguir.", "?", "c",
          "g", "3", "c", "",
          "1", "u", "s", "?", "", "v", "2", "1", "r", "Juan", "2 semanas", "acta", "", "s", "v", "3", "v", "5", "v",
          "7", "c", "1", "3", "c", "3", "5", "i", "Implantar solo controles de diseño y proveedores", "", "i",
          "Sistema completo y certificación", "", "p", "4", "5", "2", "4", "3", "2", "5", "3", "r", "", "v",
          "8", "d", "Implantar controles de diseño", "Es lo más eficaz", "g", "x", "v", "m", "0"]

SIADEF = ("3|Quiero diseñar una lámpara de escritorio plegable para estudiantes. Se fabricará en polipropileno inyectado. "
          "Debe iluminar bien la mesa, pero ocupar poco espacio al guardarse.||3|Que se pliegue y ocupe poco espacio||n|c|c|z|4821|c|"
          "|6|i|Brazo articulado de tres tramos|e|q|l|12|e|l|f|d|1|320|s|t|1|c||w|1|||||||1|n||r|1|Es reproducible|s|d|1|320|n|"
          "t|0|-0.6|0.6|-0.05|0.05|-0.1|0.1|-0.4|0.4|0|0.05|-0.05|0.05|c||y|1.0|g|x|z|m|0").split("|")


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.before = set(glob.glob(os.path.join(exchange.EXCHANGE_DIR, "*.json")))

    def tearDown(self):
        for p in set(glob.glob(os.path.join(exchange.EXCHANGE_DIR, "*.json"))) - self.before:
            os.remove(p)
        for sub in ("conceptual_design", "quality_management", "form_synthesis"):
            shutil.rmtree(os.path.join(_helpers.ROOT, "subsystems", sub, "output", "demo"), ignore_errors=True)

    def new_exchange(self):
        return set(glob.glob(os.path.join(exchange.EXCHANGE_DIR, "*.json"))) - self.before

    def test_menu_and_exit(self):
        text = _helpers.run_scripted(["0"])
        self.assertIn("ИСППР-ПД версия 0.0.1", text)
        self.assertIn("Стандартизация", text)

    def test_invalid_menu_option(self):
        text = _helpers.run_scripted(["9", "x", "0"])
        self.assertIn("ИСППР-ПД", text)

    def test_reserved_subsystem_returns_to_menu(self):
        registry.register("fake_reserved", "Ficticio")
        try:
            text = _helpers.run_scripted(["4", "", "0"])
            self.assertIn("Ficticio", text)
        finally:
            registry.unregister("fake_reserved")

    def test_siaddi_full_demo(self):
        text = _helpers.run_scripted(SIADDI)
        self.assertNotIn("Traceback", text)
        self.assertIn("ETAPA 6", text)
        files = self.new_exchange()
        self.assertTrue(any("conceptual_design" in os.path.basename(f) for f in files))
        for f in files:
            exchange.read_envelope(f, demo_mode=True)

    def test_siadec_full_demo(self):
        text = _helpers.run_scripted(SIADEC)
        self.assertNotIn("Traceback", text)
        self.assertIn("ISO 9001", text)
        self.assertTrue(any("quality_management" in os.path.basename(f) for f in self.new_exchange()))

    def test_siadef_full_demo(self):
        text = _helpers.run_scripted(SIADEF)
        self.assertNotIn("Traceback", text)
        self.assertIn("Cpk previsto", text)
        self.assertIn("PPM", text)
        self.assertTrue(any("standardization" in os.path.basename(f) for f in self.new_exchange()))

    def test_english_and_russian_entry(self):
        for lang, word in (("en", "Select module"), ("ru", "Выберите модуль")):
            text = _helpers.run_scripted(["3", "m", "0"], lang=lang)
            self.assertIn(word, text)

    def test_normal_mode_runs_without_data(self):
        text = _helpers.run_scripted(["3", "Una silla apilable de polipropileno inyectado", "", "m", "0"], demo=False)
        self.assertNotIn("Traceback", text)


if __name__ == "__main__":
    unittest.main()
