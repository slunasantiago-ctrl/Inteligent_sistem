"""Utilidades comunes de las pruebas."""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
os.environ.setdefault("NO_COLOR", "1")


def run_scripted(inputs, demo=True, draft=False, lang="es"):
    """Ejecuta la plataforma completa con entradas guionizadas y devuelve el texto mostrado."""
    import main
    from isppr_platform.io import ScriptedIO
    from isppr_platform.session import PlatformSession
    io = ScriptedIO(list(inputs))
    session = PlatformSession(demo=demo, draft=draft, language=lang)
    main.run(session, io)
    return io.text
