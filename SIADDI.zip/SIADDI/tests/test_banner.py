import unittest

from tests import _helpers  # noqa: F401
import branding
from interface.banner import build_banner
from isppr_platform import terminal


class BannerTests(unittest.TestCase):
    def test_version_text(self):
        self.assertEqual(branding.APP_VERSION, "0.0.1")
        self.assertEqual(branding.APP_NAME, "ИСППР-ПД")
        self.assertIn("ИСППР-ПД версия 0.0.1", terminal.strip_ansi(build_banner(level=2, width=80)))

    def test_banner_all_levels(self):
        for level in (0, 1, 2):
            text = terminal.strip_ansi(build_banner(level=level, width=80))
            self.assertTrue(text.strip())
            if level > 0:
                self.assertIn("0.0.1", text)

    def test_ascii_fallback_has_no_unicode_box(self):
        text = terminal.to_ascii(terminal.strip_ansi(build_banner(level=0, width=80)))
        self.assertTrue(all(ord(ch) < 128 or ch in "ИСППРДверсия" for ch in text), repr(text))

    def test_strip_ansi(self):
        self.assertEqual(terminal.strip_ansi("\x1b[1mhola\x1b[0m"), "hola")


if __name__ == "__main__":
    unittest.main()
