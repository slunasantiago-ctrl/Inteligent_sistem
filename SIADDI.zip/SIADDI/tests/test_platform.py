import json
import os
import tempfile
import unittest

from tests import _helpers  # noqa: F401
import branding
from isppr_platform import exchange, i18n, mcda, registry, textnorm
from isppr_platform.subsystem import ReservedSubsystem


class RegistryTests(unittest.TestCase):
    def test_three_subsystems(self):
        ids = [sid for sid, _ in registry.entries()]
        self.assertEqual(ids[:3], ["conceptual_design", "quality_management", "standardization"])

    def test_standardization_lives_in_form_synthesis(self):
        sub = registry.get("standardization")
        self.assertEqual(type(sub).__name__, "FormSynthesisSubsystem")

    def test_dynamic_reserved_subsystem(self):
        registry.register("fake_x", "Ficticio")
        try:
            self.assertIn(("fake_x", "Ficticio"), registry.entries())
            self.assertIsInstance(registry.get("fake_x"), ReservedSubsystem)
        finally:
            registry.unregister("fake_x")
        self.assertNotIn("fake_x", [s for s, _ in registry.entries()])

    def test_unknown(self):
        self.assertIsNone(registry.get("nope"))


class ExchangeTests(unittest.TestCase):
    def test_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            p = exchange.write_envelope("conceptual_design", "es", {"project_id": "p1", "x": 1}, directory=d)
            data = exchange.read_envelope(p)
            self.assertEqual(data["handoff_version"], "1")
            self.assertEqual(data["payload"]["x"], 1)

    def test_rejections(self):
        base = exchange.make_envelope("conceptual_design", "es", {})
        for mutate, reason in ((lambda e: e.pop("origin"), "missing_field"),
                               (lambda e: e.__setitem__("handoff_version", "9"), "unsupported_version"),
                               (lambda e: e.__setitem__("origin", "zzz"), "unknown_origin"),
                               (lambda e: e.__setitem__("language", "fr"), "bad_language")):
            env = json.loads(json.dumps(base))
            mutate(env)
            with self.assertRaises(exchange.EnvelopeError) as cm:
                exchange.validate_envelope(env)
            self.assertIn(reason, str(cm.exception))

    def test_demo_file_outside_demo(self):
        env = exchange.make_envelope("quality_management", "es", {"demo": True})
        with self.assertRaises(exchange.EnvelopeError):
            exchange.validate_envelope(env, demo_mode=False)
        exchange.validate_envelope(env, demo_mode=True)

    def test_invalid_json(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "bad.json")
            with open(p, "w") as fh:
                fh.write("{no")
            with self.assertRaises(exchange.EnvelopeError):
                exchange.read_envelope(p)


class I18nTests(unittest.TestCase):
    def test_number_formats(self):
        self.assertEqual(i18n.number(1234.5, "es", 2), "1.234,50")
        self.assertEqual(i18n.number(1234.5, "en", 2), "1,234.50")
        self.assertEqual(i18n.number(1234.5, "ru", 2), "1\u00a0234,50")
        self.assertEqual(i18n.number(-0.0001, "es", 2), "0,00")
        self.assertEqual(i18n.number(None, "es"), "—")

    def test_textnorm(self):
        self.assertEqual(textnorm.normalize("Lámpara ÑANDÚ"), textnorm.normalize("lampara ñandu"))


class McdaTests(unittest.TestCase):
    def test_normalize_weights(self):
        w = mcda.normalize_weights({"a": 2, "b": 2})
        self.assertAlmostEqual(sum(w.values()), 1.0)

    def test_pareto(self):
        pts = {"A": {"q": 1, "c": 1}, "B": {"q": 2, "c": 2}, "C": {"q": 2, "c": 1}}
        self.assertEqual(mcda.pareto_front(pts, {"q": "max", "c": "min"}), ["C"])

    def test_ahp_consistent(self):
        m = [[1, 2, 4], [0.5, 1, 2], [0.25, 0.5, 1]]
        w, lam, ci = mcda.ahp_weights(m)
        self.assertAlmostEqual(w[0], 4 / 7, places=6)
        self.assertAlmostEqual(lam, 3.0, places=6)
        self.assertAlmostEqual(ci, 0.0, places=6)
        self.assertIsNone(mcda.ahp_consistency_ratio(ci, 3, {}))

    def test_kendall_perfect_agreement(self):
        w, chi2, df, p = mcda.kendall_w([[1, 2, 3, 4], [1, 2, 3, 4], [1, 2, 3, 4]])
        self.assertAlmostEqual(w, 1.0)
        self.assertEqual(df, 3)
        self.assertLess(p, 0.05)

    def test_chi2_sf_known_value(self):
        self.assertAlmostEqual(mcda.chi2_sf(3.841458820694124, 1), 0.05, places=4)
        self.assertAlmostEqual(mcda.chi2_sf(5.991464547107979, 2), 0.05, places=4)

    def test_weighted_sum_and_sensitivity(self):
        crit = {"c1": {"sense": "max"}, "c2": {"sense": "max"}}
        weights = {"c1": 0.5, "c2": 0.5}
        scores = {"A": {"c1": 5, "c2": 1}, "B": {"c1": 3, "c2": 3}}
        totals = mcda.weighted_sum(crit, weights, scores)
        self.assertEqual(len(totals), 2)
        mcda.sensitivity(crit, weights, scores)


class LocalesTests(unittest.TestCase):
    def test_check_locales_passes(self):
        import subprocess
        import sys
        out = subprocess.run([sys.executable, os.path.join(_helpers.ROOT, "tools", "check_locales.py")],
                             capture_output=True, text=True, cwd=_helpers.ROOT)
        self.assertEqual(out.returncode, 0, out.stdout + out.stderr)


if __name__ == "__main__":
    unittest.main()
