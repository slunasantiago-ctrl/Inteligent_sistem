"""Ayudas de diálogo comunes a los tres subsistemas (capa de interfaz).

Gestiona los comandos globales que A1.3, A26.8, B26 y C26.1 piden en todas las
pantallas de un subsistema: [0] cambiar idioma y [m] volver al menú principal.
"""
from __future__ import annotations

from . import language_select, terminal
from .subsystem import ReturnToMenu


class Dialog:
    def __init__(self, io, session, translator, on_language_change=None):
        self.io = io
        self.session = session
        self.tr = translator
        self.on_language_change = on_language_change

    # ----------------------------------------------------------- textos
    @property
    def lang(self) -> str:
        return self.session.language or "es"

    def t(self, key: str, **kw) -> str:
        return self.tr.t(key, self.lang, **kw)

    def say(self, text: str = "") -> None:
        self.io.say(text)

    def blank(self) -> None:
        self.io.say("")

    def title(self, text: str) -> None:
        self.io.say("")
        self.io.say(terminal.style(text, "title"))
        self.io.say(terminal.style(terminal.rule("─", min(terminal.term_width(), 72)), "muted"))

    def section(self, text: str) -> None:
        self.io.say("")
        self.io.say(terminal.style(text, "bold"))

    def note(self, text: str) -> None:
        self.io.say(terminal.style(text, "muted"))

    def warn(self, text: str) -> None:
        mark = "⚠ " if terminal.unicode_enabled() else "! "
        self.io.say(terminal.style(mark + text, "warn"))

    def ok(self, text: str) -> None:
        mark = "✔ " if terminal.unicode_enabled() else "v "
        self.io.say(terminal.style(mark + text, "ok"))

    def bullet(self, text: str, indent: int = 2) -> None:
        mark = "•" if terminal.unicode_enabled() else "*"
        self.io.say(" " * indent + f"{mark} {text}")

    def option(self, key: str, text: str) -> None:
        self.io.say(f"  [{terminal.style(key, 'accent')}] {text}")

    def frame(self, lines, title=None) -> None:
        self.io.say(terminal.frame(lines, width=min(terminal.term_width(), 78), title=title))

    def hint_globals(self) -> None:
        self.note(self.t("hint_globals"))

    # ----------------------------------------------------------- entrada
    def _raw(self, prompt: str) -> str:
        return self.io.ask(prompt)

    def ask(self, prompt: str = "> ", allow_empty: bool = True, globals_enabled: bool = True,
            zero_is_value: bool = False) -> str:
        """Pregunta texto libre. «0» cambia de idioma y «m» vuelve al menú.

        En preguntas numéricas cuyo rango admite el 0, «0» es un valor y no cambia el idioma.
        """
        while True:
            answer = self._raw(prompt).strip()
            if globals_enabled and answer == "0" and not zero_is_value:
                self.change_language()
                continue
            if globals_enabled and answer.lower() == "m":
                raise ReturnToMenu()
            if not answer and not allow_empty:
                self.warn(self.t("err_empty"))
                continue
            return answer

    def ask_text(self, key: str, **kw) -> str:
        self.say(terminal.style(self.t(key, **kw), "bold"))
        return self.ask("> ", allow_empty=False)

    def choose(self, valid, prompt: str = "> ", allow_empty: bool = False) -> str:
        valid = [str(v).lower() for v in valid]
        while True:
            answer = self.ask(prompt, allow_empty=True).lower()
            if not answer and allow_empty:
                return ""
            if answer in valid:
                return answer
            self.warn(self.t("err_invalid_option"))

    def yes_no(self, key: str, default: bool = True, **kw) -> bool:
        suffix = self.t("yes_no_default_yes") if default else self.t("yes_no_default_no")
        self.say(f"{self.t(key, **kw)} {suffix}")
        yes = {"s", "si", "sí", "y", "yes", "д", "да"}
        no = {"n", "no", "н", "нет"}
        while True:
            answer = self.ask("> ").lower()
            if not answer:
                return default
            if answer in yes:
                return True
            if answer in no:
                return False
            self.warn(self.t("err_invalid_option"))

    def ask_int(self, key: str, lo=None, hi=None, default=None, **kw) -> int:
        self.say(self.t(key, **kw) + (f" [{default}]" if default is not None else ""))
        while True:
            answer = self.ask("> ", zero_is_value=_admits_zero(lo, hi))
            if not answer and default is not None:
                return default
            try:
                value = int(answer)
            except ValueError:
                self.warn(self.t("err_number"))
                continue
            if (lo is not None and value < lo) or (hi is not None and value > hi):
                self.warn(self.t("err_range", lo=lo, hi=hi))
                continue
            return value

    def ask_float(self, key: str, lo=None, hi=None, default=None, **kw) -> float:
        self.say(self.t(key, **kw) + (f" [{default}]" if default is not None else ""))
        while True:
            answer = self.ask("> ", zero_is_value=_admits_zero(lo, hi)).replace(",", ".")
            if not answer and default is not None:
                return float(default)
            try:
                value = float(answer)
            except ValueError:
                self.warn(self.t("err_number"))
                continue
            if (lo is not None and value < lo) or (hi is not None and value > hi):
                self.warn(self.t("err_range", lo=lo, hi=hi))
                continue
            return value

    def ask_int_list(self, key: str, lo=None, hi=None, allow_empty=True, **kw):
        self.say(self.t(key, **kw))
        while True:
            answer = self.ask("> ", zero_is_value=_admits_zero(lo, hi))
            if not answer and allow_empty:
                return []
            try:
                values = [int(x) for x in answer.replace(",", " ").split()]
            except ValueError:
                self.warn(self.t("err_number"))
                continue
            if any((lo is not None and v < lo) or (hi is not None and v > hi) for v in values):
                self.warn(self.t("err_range", lo=lo, hi=hi))
                continue
            return values

    def pause(self) -> None:
        self.ask(self.t("press_enter"))

    def change_language(self) -> None:
        new = language_select.change_language(self.io)
        self.session.language = new
        self.ok(self.t("language_changed"))
        if self.on_language_change:
            self.on_language_change()


def _admits_zero(lo, hi) -> bool:
    return (lo is None or lo <= 0) and (hi is None or hi >= 0)
