"""Gestor de traducciones compartido (A4, B4, C4).

Cada subsistema tiene su propia carpeta locales/ con es.json, en.json y ru.json.
La lógica pide textos con t("clave", idioma). Ningún texto de interfaz va en el código.
"""
from __future__ import annotations

import json
import os

LANGUAGES = ("es", "en", "ru")


COMMON_LOCALES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "locales")


def _load(path):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except FileNotFoundError:
        return {}


class Translator:
    """Textos comunes de la plataforma + textos propios del subsistema (estos prevalecen)."""

    def __init__(self, locales_dir: str, common_dir: str = COMMON_LOCALES):
        self.locales_dir = locales_dir
        self.catalogs = {}
        for lang in LANGUAGES:
            cat = dict(_load(os.path.join(common_dir, f"{lang}.json"))) if common_dir else {}
            cat.update(_load(os.path.join(locales_dir, f"{lang}.json")))
            self.catalogs[lang] = cat
        self.missing = set()

    def t(self, key: str, lang: str, **kw) -> str:
        cat = self.catalogs.get(lang or "es", {})
        text = cat.get(key)
        if text is None:
            self.missing.add((lang, key))
            text = self.catalogs.get("es", {}).get(key) or self.catalogs.get("en", {}).get(key) or key
        if isinstance(text, list):
            text = "\n".join(text)
        if kw:
            try:
                text = text.format(**kw)
            except (KeyError, IndexError, ValueError):
                pass
        return text

    def has(self, key: str, lang: str) -> bool:
        return key in self.catalogs.get(lang, {})

    def keys(self, lang: str) -> set:
        return set(self.catalogs.get(lang, {}).keys())


def pick(texts, lang: str):
    """Devuelve el texto en el idioma pedido o None (nunca traduce por su cuenta)."""
    if texts is None:
        return None
    if isinstance(texts, str):
        return texts
    val = texts.get(lang)
    return val if val not in ("", None, []) else None


def number(value, lang: str, digits: int = 2) -> str:
    """Formato de números por idioma, solo en la capa de interfaz (C4)."""
    if value is None:
        return "—"
    if isinstance(value, int) and not isinstance(value, bool):
        s = f"{value:,}"
    else:
        v = float(value)
        if v != v or v in (float("inf"), float("-inf")):
            return "∞" if v > 0 else ("-∞" if v < 0 else "—")
        v = round(v, digits) + 0.0  # evita «-0,00»
        s = f"{v:,.{digits}f}"
        if s.startswith("-") and float(s.replace(",", "")) == 0:
            s = s[1:]
    if lang == "es":   # miles con punto, decimales con coma
        s = s.replace(",", "§").replace(".", ",").replace("§", ".")
    elif lang == "ru":  # miles con espacio, decimales con coma
        s = s.replace(",", " ").replace(".", ",")
    return s
