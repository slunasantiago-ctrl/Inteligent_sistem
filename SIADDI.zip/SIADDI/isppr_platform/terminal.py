"""Utilidades de terminal: UTF-8, colores ANSI, niveles de degradación (A26.1.1, A26.5)."""
from __future__ import annotations

import os
import re
import shutil
import sys
import unicodedata

ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")

# Niveles de degradación (A26.1.1)
LEVEL_FULL = 1      # Unicode + color
LEVEL_UNICODE = 2   # Unicode sin color
LEVEL_ASCII = 3     # ASCII simple

_forced_level = None


def configure_utf8() -> None:
    """Configura la salida en UTF-8; si falla, sustituye caracteres (A26.5)."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except Exception:
            pass
    if os.name == "nt":  # habilitar ANSI en Windows o degradar con gracia
        try:
            os.system("")
        except Exception:
            pass


def force_level(level) -> None:
    global _forced_level
    _forced_level = level


def _stdout_supports_unicode() -> bool:
    enc = (getattr(sys.stdout, "encoding", None) or "").lower()
    if "utf" in enc:
        return True
    try:
        "╔═░▒▓◆ИСППР".encode(enc or "ascii")
        return True
    except Exception:
        return False


def detect_level(stream=None) -> int:
    if _forced_level is not None:
        return _forced_level
    stream = stream or sys.stdout
    if not _stdout_supports_unicode() or os.environ.get("TERM") == "dumb":
        return LEVEL_ASCII
    if os.environ.get("NO_COLOR") is not None:
        return LEVEL_UNICODE
    try:
        if not stream.isatty():
            return LEVEL_UNICODE
    except Exception:
        return LEVEL_UNICODE
    return LEVEL_FULL


def color_enabled() -> bool:
    return detect_level() == LEVEL_FULL


def unicode_enabled() -> bool:
    return detect_level() in (LEVEL_FULL, LEVEL_UNICODE)


# Máximo tres colores de acento (A26.1.1): cian, amarillo y magenta.
_CODES = {
    "bold": "1", "dim": "2", "title": "1;96", "accent": "93", "accent2": "95",
    "ok": "92", "warn": "93", "err": "91", "muted": "90",
}


def style(text: str, *names: str, level=None) -> str:
    lvl = level if level is not None else detect_level()
    if lvl != LEVEL_FULL or not names:
        return text
    codes = ";".join(_CODES[n] for n in names if n in _CODES)
    return f"\x1b[{codes}m{text}\x1b[0m" if codes else text


def strip_ansi(text: str) -> str:
    return ANSI_RE.sub("", text)


def term_width(minimum: int = 60, maximum: int = 80) -> int:
    try:
        cols = shutil.get_terminal_size((80, 24)).columns
    except Exception:
        cols = 80
    return max(minimum, min(maximum, cols))


def display_width(text: str) -> int:
    """Ancho visible aproximado (sin ANSI; los caracteres anchos cuentan 2)."""
    w = 0
    for ch in strip_ansi(text):
        if unicodedata.combining(ch):
            continue
        w += 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
    return w


def pad(text: str, width: int) -> str:
    return text + " " * max(0, width - display_width(text))


def wrap(text: str, width: int) -> list:
    import textwrap
    out = []
    for para in str(text).split("\n"):
        out.extend(textwrap.wrap(para, width) or [""])
    return out


def to_ascii(text: str) -> str:
    """Último recurso cuando la terminal no admite cirílico ni marcos (A26.5)."""
    table = {"═": "=", "║": "|", "╔": "+", "╗": "+", "╚": "+", "╝": "+", "╡": "|", "╞": "|",
             "─": "-", "│": "|", "┌": "+", "┐": "+", "└": "+", "┘": "+", "├": "+", "┤": "+",
             "░": "#", "▒": "#", "▓": "#", "█": "#", "◆": "*", "•": "*", "→": "->", "×": "x",
             "≥": ">=", "≤": "<=", "⚠": "!", "✔": "v", "σ": "s", "μ": "m"}
    return "".join(table.get(ch, ch) for ch in text)


def frame(lines, width=None, title=None, level=None) -> str:
    """Marco de línea simple (┌─┐│└┘) o ASCII según el nivel."""
    lvl = level if level is not None else detect_level()
    width = width or term_width()
    inner = width - 2
    if lvl == LEVEL_ASCII:
        tl, tr, bl, br, h, v, ml, mr = "+", "+", "+", "+", "-", "|", "+", "+"
    else:
        tl, tr, bl, br, h, v, ml, mr = "┌", "┐", "└", "┘", "─", "│", "├", "┤"
    out = [tl + h * inner + tr]
    if title is not None:
        for tline in wrap(title, inner - 2):
            out.append(v + " " + pad(tline, inner - 1) + v)
        out.append(ml + h * inner + mr)
    for raw in lines:
        for line in (wrap(raw, inner - 2) if display_width(raw) > inner - 2 else [raw]):
            out.append(v + " " + pad(line, inner - 1) + v)
    out.append(bl + h * inner + br)
    return "\n".join(out)


def rule(char: str = "─", width=None) -> str:
    width = width or term_width()
    if not unicode_enabled():
        char = "-"
    return char * width
