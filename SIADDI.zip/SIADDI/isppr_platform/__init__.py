"""Capa común de la plataforma ИСППР-ПД (A26.9, P5).

Nota: la carpeta se llama «isppr_platform» y no «platform» para no ocultar el
módulo estándar de Python del mismo nombre (A26.9 permite ajustar la estructura).
"""
