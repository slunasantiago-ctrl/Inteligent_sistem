"""Registro de subsistemas: el único lugar que sabe qué subsistemas existen (A26.9, P4).

Cada entrada indica el módulo a cargar de forma diferida. Añadir un subsistema solo
requiere añadir una entrada aquí (y su nombre en branding.py).
"""
from __future__ import annotations

import importlib

import branding

from .subsystem import ReservedSubsystem

# identificador interno -> "paquete:Clase" (None = reservado, A26.10)
_ENTRY_POINTS = {
    "conceptual_design": "subsystems.conceptual_design.subsystem:ConceptualDesignSubsystem",
    "quality_management": "subsystems.quality_management.subsystem:QualityManagementSubsystem",
    # P4: el identificador se conserva; el código vive en form_synthesis/
    "standardization": "subsystems.form_synthesis.subsystem:FormSynthesisSubsystem",
}

_EXTRA = {}  # registro dinámico (pruebas: subsistemas ficticios, P12)


def register(sid: str, name: str, entry_point=None) -> None:
    _EXTRA[sid] = (name, entry_point)


def unregister(sid: str) -> None:
    _EXTRA.pop(sid, None)


def entries():
    """Lista ordenada (id, nombre visible) para el menú."""
    items = list(branding.SUBSYSTEMS)
    for sid, (name, _ep) in _EXTRA.items():
        items.append((sid, name))
    return items


def get(sid: str):
    if sid in _EXTRA:
        name, ep = _EXTRA[sid]
        return _load(ep, sid, name) if ep else ReservedSubsystem(sid, name)
    name = dict(branding.SUBSYSTEMS).get(sid)
    if name is None:
        return None
    return _load(_ENTRY_POINTS.get(sid), sid, name)


def _load(entry_point, sid, name):
    if not entry_point:
        return ReservedSubsystem(sid, name)
    module_name, cls_name = entry_point.split(":")
    module = importlib.import_module(module_name)
    obj = getattr(module, cls_name)()
    obj.id = sid
    obj.name = name
    return obj


def folder_for(sid: str) -> str:
    return branding.SUBSYSTEM_FOLDERS.get(sid, sid)
