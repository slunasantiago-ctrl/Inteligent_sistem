"""Normalización de texto multilingüe para los motores de interpretación (A26.11.6, B13, C13).

Minúsculas, sin acentos (salvo la «й» rusa), «ё» -> «е», tokenización y
coincidencia por raíz (prefijo), que cubre las formas de caso del ruso.
"""
from __future__ import annotations

import re
import unicodedata

_WORD = re.compile(r"[0-9a-zа-я]+", re.IGNORECASE)


def strip_accents(text: str) -> str:
    out = []
    for ch in unicodedata.normalize("NFD", text):
        if unicodedata.combining(ch):
            # conservar la breve de «й» (и + U+0306)
            if ch == "̆" and out and out[-1] in ("и", "И"):
                out[-1] = "й" if out[-1] == "и" else "Й"
            continue
        out.append(ch)
    return unicodedata.normalize("NFC", "".join(out))


def normalize(text: str) -> str:
    text = strip_accents((text or "").lower()).replace("ё", "е")
    return text


def tokens(text: str):
    return _WORD.findall(normalize(text))


def stem_match(token: str, stem: str) -> bool:
    stem = normalize(stem)
    if " " in stem:
        return False
    return token.startswith(stem)


def find_phrase(norm_text: str, phrase: str):
    """Posición de una frase (palabras completas) en un texto normalizado, o -1."""
    phrase = normalize(phrase).strip()
    if not phrase:
        return -1
    m = re.search(r"(?<![0-9a-zа-я])" + re.escape(phrase) + r"(?![0-9a-zа-я])", norm_text)
    return m.start() if m else -1


def token_spans(text: str):
    """[(token, start)] sobre el texto normalizado."""
    norm = normalize(text)
    return [(m.group(0), m.start()) for m in _WORD.finditer(norm)], norm


def match_stems(text: str, stems_by_lang: dict, langs=None):
    """Lista de (palabra, raíz, posición) para las raíces dadas en cualquiera de los idiomas."""
    spans, norm = token_spans(text)
    found = []
    langs = langs or list(stems_by_lang.keys())
    for lang in langs:
        for stem in stems_by_lang.get(lang) or []:
            nstem = normalize(stem)
            if " " in nstem:
                pos = find_phrase(norm, nstem)
                if pos >= 0:
                    found.append((nstem, nstem, pos))
                continue
            for tok, pos in spans:
                if tok.startswith(nstem):
                    found.append((tok, nstem, pos))
    # quitar duplicados por posición
    seen = set()
    uniq = []
    for item in sorted(found, key=lambda x: (x[2], -len(x[1]))):
        if item[2] in seen:
            continue
        seen.add(item[2])
        uniq.append(item)
    return uniq
