"""Clase base de los subsistemas (A26.9, A26.10)."""
from __future__ import annotations

RESULT_MENU = "menu"
RESULT_EXIT = "exit"

UNDER_DEVELOPMENT = "En desarrollo / Under development / В разработке"


class ReturnToMenu(Exception):
    """El estudiante eligió [m] volver al menú principal."""


class Subsystem:
    id = "base"
    name = ""
    status = "active"   # "active" | "reserved"

    def run(self, session, io) -> str:
        raise NotImplementedError


class ReservedSubsystem(Subsystem):
    """Mecanismo de A26.10, conservado para futuros subsistemas (P3.4)."""

    status = "reserved"

    def __init__(self, sid: str, name: str):
        self.id = sid
        self.name = name

    def run(self, session, io) -> str:
        io.say("")
        io.say(f"  {self.name}: {UNDER_DEVELOPMENT}")
        io.say("")
        return RESULT_MENU
