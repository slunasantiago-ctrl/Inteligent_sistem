"""Pantalla de selección de idioma compartida (A1.1, B1.1, C1.1, P6).

Cada subsistema aporta su propia cabecera; el mecanismo es común.
"""
from __future__ import annotations

from . import terminal

PROMPT = "Seleccione el idioma / Select language / Выберите язык:"
INVALID = "Opción no válida / Invalid option / Неверный вариант"
BACK = "[m] Menú principal / Main menu / Главное меню"
OPTIONS = (("1", "es", "Español"), ("2", "en", "English"), ("3", "ru", "Русский"))


def render(header_lines) -> str:
    bar = "=" * 41
    lines = [bar] + list(header_lines) + [bar, "", PROMPT, ""]
    for key, _code, label in OPTIONS:
        lines.append(f"[{terminal.style(key, 'accent')}] {label}")
    lines.append("")
    lines.append(BACK)
    return "\n".join(lines)


def select_language(io, header_lines) -> str:
    """Devuelve el código de idioma. «m» vuelve al menú principal (ReturnToMenu)."""
    from .subsystem import ReturnToMenu
    io.say(render(header_lines))
    while True:
        answer = io.ask("> ").strip()
        if answer.lower() == "m":
            raise ReturnToMenu()
        for key, code, _label in OPTIONS:
            if answer in (key, code):
                return code
        io.say(INVALID)


def change_language(io) -> str:
    """Opción [0] Cambiar idioma: [1] Español [2] English [3] Русский (A1.3)."""
    io.say("")
    io.say("  ".join(f"[{k}] {label}" for k, _c, label in OPTIONS))
    while True:
        answer = io.ask("> ").strip()
        for key, code, _label in OPTIONS:
            if answer in (key, code):
                return code
        io.say(INVALID)
