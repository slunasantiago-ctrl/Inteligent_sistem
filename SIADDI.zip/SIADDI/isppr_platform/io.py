"""Entrada/salida desacoplada de la consola, para poder probar los flujos (A19, P12)."""
from __future__ import annotations

import sys

from . import terminal


class EndOfInput(Exception):
    """El usuario cerró la entrada (Ctrl-D) o se agotó el guion de prueba."""


class ConsoleIO:
    def __init__(self):
        try:  # edición de línea en macOS/Linux si está disponible
            import readline  # noqa: F401
        except Exception:
            pass

    def say(self, text: str = "") -> None:
        if terminal.detect_level() == terminal.LEVEL_ASCII:
            text = terminal.to_ascii(text)
        try:
            print(text)
        except UnicodeEncodeError:
            print(terminal.to_ascii(text).encode("ascii", "replace").decode("ascii"))

    def ask(self, prompt: str = "> ") -> str:
        try:
            return input(prompt)
        except EOFError:
            raise EndOfInput()
        except KeyboardInterrupt:
            print()
            raise EndOfInput()


class ScriptedIO:
    """IO de prueba: entradas predefinidas y salida acumulada."""

    def __init__(self, inputs=None):
        self.inputs = list(inputs or [])
        self.output = []

    def say(self, text: str = "") -> None:
        self.output.append(str(text))

    def ask(self, prompt: str = "> ") -> str:
        self.output.append(prompt)
        if not self.inputs:
            raise EndOfInput()
        return self.inputs.pop(0)

    @property
    def text(self) -> str:
        return terminal.strip_ansi("\n".join(self.output))


def is_interactive() -> bool:
    try:
        return sys.stdin.isatty()
    except Exception:
        return False
