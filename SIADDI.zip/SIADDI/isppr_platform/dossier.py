"""Expediente integrado del proyecto (P11).

Agrupa y enumera lo que cada subsistema registró; no reinterpreta ni recalcula nada.
"""
from __future__ import annotations

import json
import os
import shutil

from . import exchange

PROJECTS_DIR = os.path.join(exchange.ROOT, "projects")


def build(project_id: str, exchange_dir: str = None, projects_dir: str = None) -> dict:
    exchange_dir = exchange_dir or exchange.EXCHANGE_DIR
    projects_dir = projects_dir or PROJECTS_DIR
    target = os.path.join(projects_dir, project_id)
    os.makedirs(target, exist_ok=True)
    entries = []
    for path in exchange.list_files(directory=exchange_dir):
        try:
            data = exchange.read_envelope(path, demo_mode=True)
        except exchange.EnvelopeError:
            continue
        payload = data["payload"]
        if payload.get("project_id") != project_id:
            continue
        shutil.copy2(path, os.path.join(target, os.path.basename(path)))
        entries.append({
            "file": os.path.basename(path),
            "origin": data["origin"],
            "created_at": data["created_at"],
            "demo": bool(payload.get("demo")),
            "decision": payload.get("decision") or payload.get("decisions"),
            "standards": [s.get("designation") for s in payload.get("standards_marked", [])],
            "editions": sorted({str(s.get("edition")) for s in payload.get("standards_marked", [])}),
            "principles": payload.get("useful_principles") or payload.get("matrix_principles"),
            "adopted_alternatives": payload.get("adopted_alternatives"),
            "sources": payload.get("sources"),
        })
    entries.sort(key=lambda e: e["created_at"])
    index = {"project_id": project_id, "entries": entries,
             "subsystems": sorted({e["origin"] for e in entries})}
    with open(os.path.join(target, "index.json"), "w", encoding="utf-8") as fh:
        json.dump(index, fh, ensure_ascii=False, indent=2)
    lines = [f"Expediente / Dossier / Досье: {project_id}", ""]
    for e in entries:
        lines.append(f"- {e['created_at']}  {e['origin']}  {e['file']}" + ("  [DEMO]" if e["demo"] else ""))
        if e["principles"]:
            lines.append(f"    TRIZ: {e['principles']}")
        if e["standards"]:
            lines.append(f"    Normas / Standards: {', '.join(x for x in e['standards'] if x)}  ed. {', '.join(e['editions'])}")
        if e["adopted_alternatives"]:
            for alt in e["adopted_alternatives"]:
                lines.append(f"    Alternativa / Alternative: {alt.get('alternative_id')}  Cpk prev. min: {alt.get('min_cpk_estimate')}")
        if e["decision"]:
            lines.append(f"    Decisión / Decision: {json.dumps(e['decision'], ensure_ascii=False)[:200]}")
    if not entries:
        lines.append("(sin archivos de intercambio / no exchange files / нет файлов обмена)")
    with open(os.path.join(target, "index.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    index["text"] = "\n".join(lines)
    index["path"] = target
    return index
