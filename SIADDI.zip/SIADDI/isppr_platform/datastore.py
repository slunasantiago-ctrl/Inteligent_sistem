"""Carga de datos con las reglas comunes de integridad (A17, B17, C17, P9).

Modos:
  normal -> data/ ; solo se usa lo aprobado (o datos de referencia, rotulados)
  draft  -> data/ ; además lo que está en borrador, rotulado BORRADOR
  demo   -> data/demo/ ; todo rotulado DEMO, nunca se mezcla con lo real
"""
from __future__ import annotations

import json
import os

USABLE_STATUSES = ("approved", "verified", "reference")
DRAFT_STATUSES = ("draft", "provisional")


class DataMode:
    def __init__(self, demo: bool = False, draft: bool = False):
        self.demo = demo
        self.draft = draft

    @property
    def name(self) -> str:
        return "demo" if self.demo else ("draft" if self.draft else "normal")

    def data_dir(self, subsystem_root: str) -> str:
        base = os.path.join(subsystem_root, "data")
        return os.path.join(base, "demo") if self.demo else base

    def visible(self, item) -> bool:
        if self.demo:
            return True
        status = (item or {}).get("status", "approved")
        if status in USABLE_STATUSES:
            return True
        return self.draft and status in DRAFT_STATUSES

    def label(self, item=None):
        if self.demo:
            return "DEMO"
        status = (item or {}).get("status")
        if status in DRAFT_STATUSES:
            return "draft"
        if status == "reference":
            return "reference"
        return None


def load_json(path: str, default=None):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except FileNotFoundError:
        return default
    except json.JSONDecodeError as exc:
        raise ValueError(f"{os.path.basename(path)}: JSON inválido ({exc.msg}, línea {exc.lineno})")


def save_json(path: str, data) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, path)
