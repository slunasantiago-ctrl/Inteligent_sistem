"""Evaluación multicriterio determinista y transparente (B11, C30.4).

Método declarado: suma ponderada con normalización explícita.
  - pesos: w_i / Σ w (se normalizan a suma 1)
  - puntuación normalizada a [0, 1] según la escala; los criterios a minimizar se invierten
  - total = Σ w_i · q_i
Sin idioma: recibe identificadores y números y devuelve identificadores y números.
"""
from __future__ import annotations


def normalize_weights(weights: dict) -> dict:
    total = sum(max(0.0, float(w)) for w in weights.values())
    if total <= 0:
        raise ValueError("weights_sum_zero")
    return {k: max(0.0, float(w)) / total for k, w in weights.items()}


def normalize_score(value: float, lo: float, hi: float, sense: str = "max") -> float:
    if hi == lo:
        raise ValueError("scale_degenerate")
    if value < lo or value > hi:
        raise ValueError("score_out_of_scale")
    q = (float(value) - lo) / (hi - lo)
    return 1.0 - q if sense == "min" else q


def weighted_sum(criteria: dict, weights: dict, scores: dict, lo: float = 1, hi: float = 5):
    """criteria: {cid: sense}; scores: {alt: {cid: value}}. Devuelve ({alt: total}, pasos)."""
    if not criteria:
        raise ValueError("no_criteria")
    if not scores:
        raise ValueError("no_alternatives")
    w = normalize_weights({c: weights.get(c, 0) for c in criteria})
    totals, steps = {}, {}
    for alt, row in scores.items():
        total, detail = 0.0, []
        for cid, sense in criteria.items():
            if cid not in row:
                raise ValueError(f"missing_score:{alt}:{cid}")
            q = normalize_score(row[cid], lo, hi, sense)
            total += w[cid] * q
            detail.append((cid, row[cid], round(q, 4), round(w[cid], 4), round(w[cid] * q, 4)))
        totals[alt] = round(total, 6)
        steps[alt] = detail
    return totals, steps


def ranking(totals: dict):
    return [alt for alt, _ in sorted(totals.items(), key=lambda kv: (-kv[1], str(kv[0])))]


def sensitivity(criteria: dict, weights: dict, scores: dict, margin: float = 0.2, lo: float = 1, hi: float = 5):
    """Varía cada peso ±margin (relativo), renormaliza y comprueba si cambia el orden."""
    base_totals, _ = weighted_sum(criteria, weights, scores, lo, hi)
    base_rank = ranking(base_totals)
    changes = []
    for cid in criteria:
        for factor in (1 - margin, 1 + margin):
            w2 = dict(weights)
            w2[cid] = max(0.0, float(weights.get(cid, 0)) * factor)
            if sum(w2.values()) <= 0:
                continue
            t2, _ = weighted_sum(criteria, w2, scores, lo, hi)
            r2 = ranking(t2)
            if r2 != base_rank:
                changes.append({"criterion": cid, "factor": round(factor, 3), "ranking": r2})
    return {"base_ranking": base_rank, "stable": not changes, "changes": changes}


def weighted_index(values: dict, weights: dict):
    """Índice integral K = Σ w_i q_i (C30.4) con q_i ya normalizados en [0, 1].

    Si falta algún valor devuelve (K parcial, faltantes) sin renormalizar; la
    renormalización solo se aplica si el usuario la acepta (renormalize=True en partial_index).
    """
    w = normalize_weights(weights)
    missing = [k for k in w if values.get(k) is None]
    k = sum(w[i] * values[i] for i in w if values.get(i) is not None)
    return round(k, 6), missing


def partial_index(values: dict, weights: dict, renormalize: bool):
    available = {i: wt for i, wt in weights.items() if values.get(i) is not None and wt > 0}
    if not available:
        return None
    if renormalize:
        w = normalize_weights(available)
    else:
        w = {i: wt / sum(weights.values()) for i, wt in available.items()}
    return round(sum(w[i] * values[i] for i in w), 6)


def pareto_front(points: dict, senses: dict):
    """points: {alt: {crit: value}}; senses: {crit: 'max'|'min'}. Devuelve alternativas no dominadas."""
    def better_or_equal(a, b, c):
        return a >= b if senses[c] == "max" else a <= b

    def strictly_better(a, b, c):
        return a > b if senses[c] == "max" else a < b

    front = []
    for i, pi in points.items():
        dominated = False
        for j, pj in points.items():
            if i == j:
                continue
            if all(better_or_equal(pj[c], pi[c], c) for c in senses) and any(strictly_better(pj[c], pi[c], c) for c in senses):
                dominated = True
                break
        if not dominated:
            front.append(i)
    return sorted(front, key=str)


# ------------------------------------------------------------------ AHP y Kendall
def ahp_weights(matrix, iterations: int = 100):
    """Vector propio principal por el método de potencias. matrix: lista de listas recíproca."""
    n = len(matrix)
    for i in range(n):
        if len(matrix[i]) != n:
            raise ValueError("ahp_not_square")
        for j in range(n):
            if matrix[i][j] <= 0:
                raise ValueError("ahp_non_positive")
    v = [1.0 / n] * n
    lam = 0.0
    for _ in range(iterations):
        w = [sum(matrix[i][j] * v[j] for j in range(n)) for i in range(n)]
        s = sum(w)
        w = [x / s for x in w]
        lam = sum(sum(matrix[i][j] * w[j] for j in range(n)) / w[i] for i in range(n)) / n
        if max(abs(a - b) for a, b in zip(w, v)) < 1e-12:
            v = w
            break
        v = w
    ci = (lam - n) / (n - 1) if n > 1 else 0.0
    return v, lam, ci


def ahp_consistency_ratio(ci: float, n: int, random_index: dict):
    """CR = CI / RI(n). RI se carga desde datos con su fuente; sin RI devuelve None."""
    ri = (random_index or {}).get(str(n))
    if ri in (None, 0):
        return None
    return ci / float(ri)


def kendall_w(rankings):
    """Coeficiente de concordancia de Kendall sin corrección por empates.

    rankings: lista de m listas, cada una con los rangos (1..n) que un experto asigna a n objetos.
    Devuelve (W, chi2, gl, p_valor).
    """
    m = len(rankings)
    if m < 2:
        raise ValueError("kendall_needs_two_experts")
    n = len(rankings[0])
    if n < 2 or any(len(r) != n for r in rankings):
        raise ValueError("kendall_bad_shape")
    sums = [sum(r[j] for r in rankings) for j in range(n)]
    mean = sum(sums) / n
    s = sum((x - mean) ** 2 for x in sums)
    w = 12 * s / (m ** 2 * (n ** 3 - n))
    chi2 = m * (n - 1) * w
    df = n - 1
    return w, chi2, df, chi2_sf(chi2, df)


def weights_from_mean_ranks(rankings):
    """Pesos declarados a partir de rangos medios: w_j ∝ (n − R̄_j + 1)."""
    m, n = len(rankings), len(rankings[0])
    mean = [sum(r[j] for r in rankings) / m for j in range(n)]
    raw = [n - mr + 1 for mr in mean]
    s = sum(raw)
    return [x / s for x in raw]


def chi2_sf(x: float, k: int) -> float:
    """Función de supervivencia de χ² (gamma incompleta regularizada), solo biblioteca estándar."""
    import math
    if x <= 0:
        return 1.0
    a, xx = k / 2.0, x / 2.0
    if xx < a + 1:  # serie para P(a, x)
        term = 1.0 / a
        total = term
        for n in range(1, 500):
            term *= xx / (a + n)
            total += term
            if abs(term) < abs(total) * 1e-14:
                break
        p = total * math.exp(-xx + a * math.log(xx) - math.lgamma(a))
        return max(0.0, 1.0 - p)
    # fracción continua para Q(a, x)
    tiny = 1e-300
    b = xx + 1 - a
    c = 1 / tiny
    d = 1 / b
    h = d
    for i in range(1, 500):
        an = -i * (i - a)
        b += 2
        d = an * d + b
        d = tiny if abs(d) < tiny else d
        c = b + an / c
        c = tiny if abs(c) < tiny else c
        d = 1 / d
        delta = d * c
        h *= delta
        if abs(delta - 1) < 1e-14:
            break
    return max(0.0, min(1.0, math.exp(-xx + a * math.log(xx) - math.lgamma(a)) * h))
