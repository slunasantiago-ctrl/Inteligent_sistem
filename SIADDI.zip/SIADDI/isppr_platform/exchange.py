"""Sobre común de intercambio entre subsistemas (C26.2, P7).

Los subsistemas no se importan entre sí: se comunican con archivos JSON validados.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import re

HANDOFF_VERSION = "1"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXCHANGE_DIR = os.path.join(ROOT, "exchange")

ORIGINS = ("conceptual_design", "quality_management", "standardization", "form_synthesis")


def now_iso() -> str:
    return _dt.datetime.now().replace(microsecond=0).isoformat()


def make_envelope(origin: str, language: str, payload: dict) -> dict:
    return {
        "handoff_version": HANDOFF_VERSION,
        "origin": origin,
        "created_at": now_iso(),
        "language": language or "es",
        "payload": payload,
    }


def _safe(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", text or "sin_proyecto")[:40]


def write_envelope(origin: str, language: str, payload: dict, directory: str = None) -> str:
    directory = directory or EXCHANGE_DIR
    os.makedirs(directory, exist_ok=True)
    stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    name = f"{origin}_{_safe(payload.get('project_id'))}_{stamp}.json"
    path = os.path.join(directory, name)
    n = 1
    while os.path.exists(path):
        path = os.path.join(directory, name.replace(".json", f"_{n}.json"))
        n += 1
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(make_envelope(origin, language, payload), fh, ensure_ascii=False, indent=2)
    return path


class EnvelopeError(ValueError):
    pass


def validate_envelope(data, allowed_origins=None, demo_mode=False) -> dict:
    """Valida el sobre común. Lanza EnvelopeError con el motivo (P7.7)."""
    if not isinstance(data, dict):
        raise EnvelopeError("not_an_object")
    for key in ("handoff_version", "origin", "created_at", "language", "payload"):
        if key not in data:
            raise EnvelopeError(f"missing_field:{key}")
    if str(data["handoff_version"]) != HANDOFF_VERSION:
        raise EnvelopeError(f"unsupported_version:{data['handoff_version']}")
    if data["origin"] not in ORIGINS:
        raise EnvelopeError(f"unknown_origin:{data['origin']}")
    if allowed_origins and data["origin"] not in allowed_origins:
        raise EnvelopeError(f"origin_not_allowed:{data['origin']}")
    if data["language"] not in ("es", "en", "ru"):
        raise EnvelopeError(f"bad_language:{data['language']}")
    if not isinstance(data["payload"], dict):
        raise EnvelopeError("payload_not_object")
    if data["payload"].get("demo") and not demo_mode:
        raise EnvelopeError("demo_file_outside_demo_mode")
    return data


def read_envelope(path: str, allowed_origins=None, demo_mode=False) -> dict:
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
    except FileNotFoundError:
        raise EnvelopeError("file_not_found")
    except json.JSONDecodeError as exc:
        raise EnvelopeError(f"invalid_json:{exc.msg}")
    return validate_envelope(data, allowed_origins, demo_mode)


def list_files(origin=None, directory: str = None):
    directory = directory or EXCHANGE_DIR
    if not os.path.isdir(directory):
        return []
    files = []
    for name in sorted(os.listdir(directory), reverse=True):
        if not name.endswith(".json"):
            continue
        if origin and not name.startswith(origin + "_"):
            continue
        files.append(os.path.join(directory, name))
    return files
