"""Sesión compartida de la plataforma (A26.9, P6)."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class PlatformSession:
    language: str = None            # "es" | "en" | "ru"; lo fija el primer subsistema
    active_subsystem: str = None    # identificador interno
    demo: bool = False              # --demo (A26.11.2, P9)
    draft: bool = False             # --draft: muestra contenidos en borrador rotulados
    project_id: str = None          # P11
    banner_shown: bool = False      # A26.2: una sola vez por ejecución
    subsystem_states: dict = field(default_factory=dict)  # estado propio de cada subsistema

    def state_for(self, subsystem_id: str, factory):
        if subsystem_id not in self.subsystem_states:
            self.subsystem_states[subsystem_id] = factory()
        return self.subsystem_states[subsystem_id]
