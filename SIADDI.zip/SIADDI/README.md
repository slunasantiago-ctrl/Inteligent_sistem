# ИСППР-ПД версия 0.0.1

**Sistema Inteligente de Apoyo a Decisiones Estratégicas en Diseño Industrial**
Programa de terminal (CLI) en Python para macOS (también funciona en Linux y Windows).
Pasaporte de especialidad 2.5.22 — Управление качеством продукции. Стандартизация. Организация производства.

| Opción del menú | Subsistema | Qué hace |
|---|---|---|
| [1] Diseño conceptual (TRIZ) | **SIADDI** | Interpreta el problema de diseño, identifica la contradicción técnica (39 parámetros), consulta la matriz de contradicciones y explica los 40 principios inventivos. |
| [2] Управление качеством продукции | **SIADEC** | Perfil del producto, normas ISO aplicables (N1–N4), cláusulas ISO 9001, consejos, plan de calidad, brechas, decisión multicriterio con sensibilidad. |
| [3] Стандартизация | **SIADEF** | Gramática de formas paramétrica: genera alternativas de forma, las dimensiona, aplica números preferidos y tolerancias, y predice el **Cpk** con Monte Carlo (la forma como característica de calidad). |

---

## 1. Requisitos

* macOS 11 o posterior (o cualquier sistema con **Python 3.9+**).
* **No necesita instalar ninguna biblioteca.** Todo (geometría, Monte Carlo, AHP, Kendall, SVG, ZIP) está escrito con la biblioteca estándar de Python, así que funciona sin Internet y da los mismos resultados en cualquier Mac.
* Opcional: `cairosvg` para ver las formas como imagen dentro de la terminal (iTerm2, WezTerm, kitty).

¿Tiene Python? Abra **Terminal** (Aplicaciones → Utilidades → Terminal) y escriba:

```bash
python3 --version
```

Si macOS le ofrece instalar las «herramientas de línea de comandos», acepte (eso instala `python3`).
También puede instalarlo desde <https://www.python.org/downloads/macos/> o con `brew install python`.

## 2. Instalación

1. Descomprima `SIADDI.zip` (doble clic en Finder). Aparece la carpeta `SIADDI`.
2. En Terminal:

```bash
cd ~/Downloads/SIADDI        # o la carpeta donde lo descomprimió
bash install.sh              # comprueba Python, da permisos y ejecuta las 65 pruebas
```

`bash install.sh --optional` además intenta instalar `cairosvg`.

## 3. Uso

```bash
./run.sh                 # inicio normal
./run.sh --demo          # con datos de demostración (rotulados DEMO)
./run.sh --draft         # muestra también contenidos en borrador (rotulados BORRADOR)
./run.sh --lang en       # idioma inicial: es | en | ru
./run.sh --ascii         # marcos ASCII simples (terminales antiguas)
./run.sh --no-color      # sin colores (también respeta la variable NO_COLOR)
./run.sh --project P01   # identificador de proyecto para las exportaciones
./run.sh --dossier P01   # genera el expediente integrado del proyecto y sale
./run.sh --version
```

O bien: **doble clic en `ISPPR-PD.command`** en Finder (abre Terminal automáticamente).
Si macOS dice que «no se puede abrir», haga clic derecho → Abrir, o ejecute antes `bash install.sh`.

> **Recomendación para empezar:** `./run.sh --demo`. Sin `--demo`, el sistema funciona pero
> muestra solo datos aprobados; la mayoría de las bases de conocimiento están vacías o en
> borrador a la espera de los documentos fuente (ver § 6).

### Teclas globales (en cualquier pregunta)

| Tecla | Acción |
|---|---|
| `0` | cambiar de idioma sin perder los datos (en preguntas numéricas que admiten el 0, el 0 es un valor) |
| `m` | volver al menú principal |
| `?` | ¿por qué? — ver el razonamiento del sistema |
| Intro | aceptar el valor por defecto que se muestra entre corchetes |

### Recorrido rápido de cada subsistema

**SIADDI (1)** — escriba la idea del proyecto y el problema («debe ser resistente pero ligera»).
El sistema propone qué parámetro mejora y cuál empeora, con su confianza y el porqué; usted confirma,
intercambia o elige a mano. Luego ve los principios de la matriz (en demo: celda 14×2 → 1, 10, 35),
genera ideas, las desarrolla y exporta.

**SIADEC (2)** — describa el producto y la organización. El sistema extrae el perfil (categoría,
sector, rol, proveedores críticos…), recomienda normas con tres veredictos (*aplica / posible / no aplica*),
muestra las cláusulas, los consejos, el plan de calidad y las brechas, y resuelve la decisión con suma
ponderada y análisis de sensibilidad.

**SIADEF (3)** — etapas 1–6:
1. idea y contexto de fabricación (material y proceso);
2. requisitos de forma (importables desde SIADDI y SIADEC);
3. interpretación sobre la gramática (familias de reglas, forma inicial, guardas);
4. problema de síntesis (semilla, profundidad, número de alternativas, serie R5/R10/R20/R40);
5. galería de alternativas (SVG + hoja de contactos + vista ASCII; variaciones, ajustes, comparación);
6. por alternativa: dimensionar en mm → cotas críticas (CTQ) y cadenas → tolerancias →
   **Cpk previsto por Monte Carlo** (con IC 95 % de Wilson y contribución de cada cota) → índice
   integral K, AHP, Pareto, sensibilidad → encuesta del consumidor (Kendall W) → decisión →
   registro, exportación y paquete académico ZIP.

Las formas se guardan en `subsystems/form_synthesis/output/…/A01.svg` y se abren con Vista Previa
(orden `open` de macOS).

## 4. Intercambio entre subsistemas y expediente

Cada subsistema exporta a `exchange/` un sobre JSON común
(`handoff_version`, `origin`, `created_at`, `language`, `payload`).
SIADEF importa de SIADDI (contradicción y principios) y de SIADEC (normas y restricciones).
`./run.sh --dossier P01` reúne en `projects/P01/` todos los archivos del proyecto P01.

## 5. Carga de datos reales

Toda la información normativa se carga desde archivos con su **fuente** obligatoria; si la validación
falla no se escribe nada.

```bash
python3 setup_data.py all status                       # estado de las tres bases

# SIADDI
python3 setup_data.py conceptual_design import-matrix matriz.csv --source "Altshuller, 1971 …"
python3 setup_data.py conceptual_design import-principles principios.json --source "…"
python3 setup_data.py conceptual_design import-parameters parametros.json --source "…"

# SIADEC
python3 setup_data.py quality_management import-lines | import-catalog | import-advice | import-iso9001 | import-concepts | import-glossary archivo.json --source "…"
python3 setup_data.py quality_management status
python3 setup_data.py quality_management --help     # argumentos exactos de cada orden

# SIADEF
python3 setup_data.py form_synthesis import-rules reglas.json --source "…"
python3 setup_data.py form_synthesis import-guards guardas.json --source "…"
python3 setup_data.py form_synthesis import-shapes formas.json --source "…"
python3 setup_data.py form_synthesis import-triz-map mapa.json --source "…"
python3 setup_data.py form_synthesis import-preferred-numbers series.json --standard "ISO 3" --edition "1973" --source "…"
python3 setup_data.py form_synthesis import-tolerances tablas.json --standard "ISO 2768-1" --edition "1989" --source "…"
python3 setup_data.py form_synthesis import-capability capacidad.csv --source "Estudio de capacidad, planta X"
python3 setup_data.py form_synthesis import-indicators | import-scales | import-concepts | import-glossary archivo.json --source "…"
```

La matriz de contradicciones es una cuadrícula CSV de 39×39 (filas = parámetro que mejora,
columnas = que empeora; separador `;` `,` o tabulador; celdas como `1 10 35`; se admiten filas y
columnas de encabezado y celdas vacías).

El CSV de capacidad tiene las columnas:
`capability_id,process_id,material_id,feature_type,range_min_mm,range_max_mm,sigma_mm,mean_shift_mm,distribution,data_quality,sample_size,derivation_note`
(`data_quality` ∈ `A_measured`, `B_literature`, `C_derived_from_IT_grade`; el nivel C exige `derivation_note`).

## 6. Integridad de los datos (lo que el programa NO inventa)

Siguiendo A17 / B17 / C17 del prompt maestro:

* **Modo normal:** solo datos *aprobados / verificados / de referencia*.
* **`--draft`:** añade los contenidos en borrador, rotulados **BORRADOR**.
* **`--demo`:** usa `data/demo/` de cada subsistema, rotulado **DEMO** en cada pantalla
  (matriz parcial, reglas y σ ilustrativas, tabla de tolerancias que *no es una norma*).
* Sin σ del proceso **no se calcula el Cpk**: se muestra la brecha. El índice heurístico de riesgo se
  rotula siempre «NO es un Cpk». El Cpk se rotula «previsto (estimación)».

Pendiente de documentos fuente (`setup_data.py all status` lo detalla):

* SIADDI: celdas de la matriz 39×39; descripciones, sinónimos y ejemplos de los 39 parámetros;
  6 de las 9 secciones de cada principio.
* SIADEC: aprobación del catálogo de normas y de los 16 consejos (hoy borrador); normas técnicas N4
  por categoría; verificación de la edición ISO 9001:2026; traducciones al inglés de la matriz B.1.
* SIADEF: reglas, familias y formas aprobadas (hoy 15 reglas en borrador); filas TRIZ→familias de
  25 principios; series de números preferidos y tablas de tolerancias normativas con licencia;
  base de capacidad de procesos real; escalas semánticas y formas de referencia.

## 7. Pruebas

```bash
python3 run_tests.py      # 65 pruebas: plataforma, banner, intercambio, i18n, MCDA, AHP, Kendall,
                          # Pareto, interpretación trilingüe, matriz, catálogo, geometría, guardas
                          # (seguridad), derivación determinista y reproducción, Monte Carlo,
                          # números preferidos, importaciones y recorridos completos de los 3 subsistemas
python3 tools/check_locales.py   # todas las claves de texto existen en es / en / ru
```

Probado con Python 3.9 (el de macOS) y 3.13.

## 8. Estructura

```
SIADDI/
├── main.py                 punto de entrada (banner, menú, argumentos)
├── branding.py             nombre, versión y nombres de subsistemas (constantes)
├── setup_data.py           carga de datos: setup_data.py <subsistema> <orden>
├── run.sh · install.sh · ISPPR-PD.command · run_tests.py · requirements.txt
├── interface/              banner y menú principal
├── isppr_platform/         núcleo común: terminal, E/S, i18n, sesión, registro, intercambio,
│                           diálogo, expediente, datos, normalización de texto, MCDA
├── subsystems/
│   ├── conceptual_design/  SIADDI (triz/, core/, interface/, data/, locales/, tests/)
│   ├── quality_management/ SIADEC (standardization/, core/, interface/, data/, locales/, tests/)
│   └── form_synthesis/     SIADEF = opción [3] «standardization»
│                           (grammar/, quality/, render/, core/, interface/, data/, locales/, tests/)
├── exchange/  projects/  tests/  tools/
```

### Desviaciones estructurales respecto al prompt (justificadas)

* La carpeta común se llama `isppr_platform/` y no `platform/`: `platform` es un módulo de la
  biblioteca estándar de Python y una carpeta con ese nombre lo ocultaría y rompería el programa.
* El identificador de la opción [3] sigue siendo `standardization` (P4); su código vive en
  `subsystems/form_synthesis/`.
* Geometría y estadística en Python puro (sin shapely / numpy) para que funcione en cualquier Mac sin
  instalar nada y con resultados reproducibles por semilla.

## 9. Problemas frecuentes

| Problema | Solución |
|---|---|
| `permission denied: ./run.sh` | `chmod +x run.sh ISPPR-PD.command` o `bash run.sh` |
| «No se puede abrir porque es de un desarrollador no identificado» | clic derecho → Abrir, o `xattr -dr com.apple.quarantine .` |
| Caracteres raros en el marco | `./run.sh --ascii` |
| Colores ilegibles | `./run.sh --no-color` |
| Ver el error técnico completo | `ISPPR_DEBUG=1 ./run.sh` |
