"""Menú principal de subsistemas (A26.7). Encabezado trilingüe; nombres constantes."""
from __future__ import annotations

from isppr_platform import registry, terminal

HEADER = "Seleccione módulo / Select module / Выберите модуль:"
EXIT_LABEL = "Salir / Exit / Выход"
INVALID = "Opción no válida / Invalid option / Неверный вариант"
DEMO_LABEL = "MODO DEMO — datos de ejemplo / DEMO MODE — sample data / ДЕМО-РЕЖИМ — примерные данные"
DRAFT_LABEL = "MODO BORRADOR — contenidos pendientes de aprobación / DRAFT MODE / РЕЖИМ ЧЕРНОВИКА"


def options():
    return [(str(i + 1), sid, name) for i, (sid, name) in enumerate(registry.entries())]


def build_menu(level=None, width=None) -> str:
    lvl = level if level is not None else terminal.detect_level()
    width = width or terminal.term_width()
    lines = [""]
    for key, _sid, name in options():
        lines.append(f" [{terminal.style(key, 'accent', level=lvl)}]  {name}")
    lines.append("")
    lines.append(f" [{terminal.style('0', 'accent', level=lvl)}]  {EXIT_LABEL}")
    lines.append("")
    return terminal.frame(lines, width=width, title=HEADER, level=lvl)


def render_main_menu(io, session) -> None:
    io.say("")
    if session.demo:
        io.say(terminal.style(DEMO_LABEL, "warn"))
    elif session.draft:
        io.say(terminal.style(DRAFT_LABEL, "warn"))
    io.say(build_menu())
    io.say("")


def read_choice(io):
    """Devuelve el identificador del subsistema, 'exit' o vuelve a pedir (A26.7)."""
    opts = {key: sid for key, sid, _ in options()}
    while True:
        answer = io.ask("> ").strip()
        if answer == "0":
            return "exit"
        if answer in opts:
            return opts[answer]
        io.say(INVALID)
