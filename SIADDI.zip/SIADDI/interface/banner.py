"""Banner de identidad (A26.1, A26.1.1, A26.3, A26.5). No depende del idioma."""
from __future__ import annotations

import branding
from isppr_platform import terminal


def build_banner(level=None, width=None) -> str:
    lvl = level if level is not None else terminal.detect_level()
    width = width or terminal.term_width()
    inner = width - 2
    text = branding.banner_text()
    if lvl == terminal.LEVEL_ASCII:
        top = "+" + "=" * inner + "+"
        deco = "|" + " " + "#" * (inner - 2) + " " + "|"
        empty = "|" + " " * inner + "|"
        bottom = "+" + "=" * inner + "+"
        title = "|" + _center(text, inner) + "|"
        return "\n".join([top, deco, empty, title, empty, deco, bottom])

    def s(txt, *names):
        return terminal.style(txt, *names, level=lvl)

    fill = inner - 2 - 6
    deco_inner = "░▒▓" + "█" * fill + "▓▒░"
    gem = "╡ ◆ ◆ ◆ ╞"
    left = (inner - len(gem)) // 2
    right = inner - len(gem) - left
    lines = [
        s("╔" + "═" * inner + "╗", "muted"),
        s("║", "muted") + " " + s(deco_inner, "muted") + " " + s("║", "muted"),
        s("║", "muted") + " " * inner + s("║", "muted"),
        s("║", "muted") + _center_styled(text, inner, s(text, "title")) + s("║", "muted"),
        s("║", "muted") + " " * inner + s("║", "muted"),
        s("║", "muted") + " " + s(deco_inner, "muted") + " " + s("║", "muted"),
        s("╚" + "═" * left, "muted") + s(gem, "accent2") + s("═" * right + "╝", "muted"),
    ]
    return "\n".join(lines)


def _center(text: str, width: int) -> str:
    total = width - terminal.display_width(text)
    left = total // 2
    return " " * left + text + " " * (total - left)


def _center_styled(plain: str, width: int, styled: str) -> str:
    total = width - terminal.display_width(plain)
    left = total // 2
    return " " * left + styled + " " * (total - left)


def render_banner(io, session) -> None:
    """Muestra el banner una sola vez por ejecución (A26.2)."""
    if session.banner_shown:
        return
    try:
        io.say(build_banner())
    except Exception:  # A26.5: nunca falla por la terminal
        io.say(branding.banner_text())
    session.banner_shown = True
